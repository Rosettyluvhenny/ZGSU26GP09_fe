sap.ui.define(["sap/ui/core/UIComponent", "sap/ui/Device", "sap/ui/core/Core", "./services/SessionStorage", "./services/AuthenticationService", "./services/DetailService", "./services/ErrorHandler", "./services/JobService", "./services/LogService", "./services/RegistryService", "./services/VersionService", "./model/models"], function (UIComponent, sap_ui_Device, Core, ___services_SessionStorage, __AuthenticationService, __DetailService, __ErrorHandler, __JobService, __LogService, __RegistryService, __VersionService, __models) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const support = sap_ui_Device["support"]; // UI5 1.108 has no sap/ui/core/Theming or sap/ui/core/Messaging — those modules arrived with
  // the ~1.118 core split. The Core singleton carries applyTheme/getConfiguration/
  // getMessageManager instead, and is what the launchpad's 1.108.33 runtime provides.
  const readThemePreference = ___services_SessionStorage["readThemePreference"];
  const AuthenticationService = _interopRequireDefault(__AuthenticationService);
  const DetailService = _interopRequireDefault(__DetailService);
  const ErrorHandler = _interopRequireDefault(__ErrorHandler);
  const JobService = _interopRequireDefault(__JobService);
  const LogService = _interopRequireDefault(__LogService);
  const RegistryService = _interopRequireDefault(__RegistryService);
  const VersionService = _interopRequireDefault(__VersionService);
  const models = _interopRequireDefault(__models);
  /**
   * @namespace com.zgp9.fe
   */
  const Component = UIComponent.extend("com.zgp9.fe.Component", {
    constructor: function constructor() {
      UIComponent.prototype.constructor.apply(this, arguments);
      this.authenticationService = new AuthenticationService();
      this.detailService = new DetailService();
      this.registryService = new RegistryService();
      this.versionService = new VersionService(this.detailService);
      this.jobService = new JobService();
      this.logService = new LogService();
    },
    metadata: {
      manifest: 'json',
      interfaces: ['sap.ui.core.IAsyncContentCreation']
    },
    init: function _init() {
      UIComponent.prototype.init.call(this);
      this.applyStoredTheme();
      this.setModel(models.createDeviceModel(), 'device');
      this.setModel(models.createSessionModel(), 'session');
      this.setModel(models.createUiModel(), 'ui');
      // ui5lint-disable-next-line no-deprecated-api -- sap/ui/core/Messaging, the non-deprecated replacement, does not exist on the launchpad's UI5 1.108.33
      this.setModel(Core.getMessageManager().getMessageModel(), 'message');
      this.injectAppStylesheet();
      this.errorHandler = new ErrorHandler(this.getRouter());
      this.registerViewportWidthTracking();
      this.getRouter().initialize();
    },
    // Keep a viewport-width flag on the ui model so layouts (e.g. the split-view
    // Splitters) can switch to a stacked orientation on narrow screens. Unlike
    // device>/system/phone, this reacts to desktop window resizing and browser zoom.
    registerViewportWidthTracking: function _registerViewportWidthTracking() {
      const ui = this.getModel('ui');
      // matchMedia reflects the CSS viewport width, so it fires reliably on window
      // resize and also when the user zooms the browser (unlike Device.resize, which
      // is throttled and can miss programmatic/emulated resizes).
      // isPhoneWidth (<600px) drives the shell nav overlay; isNarrowWidth (<1024px)
      // drives the split-view panes (tree ‖ XML) so they stack vertically whenever
      // there isn't enough room to show them side by side comfortably.
      const phoneMql = window.matchMedia('(max-width: 599px)');
      const narrowMql = window.matchMedia('(max-width: 1023px)');
      const update = () => {
        ui.setProperty('/isPhoneWidth', phoneMql.matches);
        ui.setProperty('/isNarrowWidth', narrowMql.matches);
      };
      update();
      phoneMql.addEventListener('change', update);
      narrowMql.addEventListener('change', update);
      window.addEventListener('resize', update);
    },
    applyStoredTheme: function _applyStoredTheme() {
      const storedTheme = readThemePreference();
      // ui5lint-disable-next-line no-deprecated-api -- sap/ui/core/Theming does not exist on the launchpad's UI5 1.108.33
      if (storedTheme && storedTheme !== Core.getConfiguration().getTheme()) {
        // ui5lint-disable-next-line no-deprecated-api -- as above; Theming.setTheme is unavailable on 1.108.33
        Core.applyTheme(storedTheme);
      }
    },
    injectAppStylesheet: function _injectAppStylesheet() {
      if (document.head.querySelector('link[data-app-stylesheet="true"]')) {
        return;
      }
      const link = document.createElement('link');
      link.rel = 'stylesheet';
      // sap.ui.require.toUrl, not new URL(…, document.baseURI): embedded in a launchpad the
      // document *is* the launchpad's page, so baseURI points at the FLP root rather than at
      // this app, and the stylesheet 404s. The app then renders unstyled rather than visibly
      // broken, which is a slow failure to recognise. toUrl resolves through the resource
      // root registered for com.zgp9.fe, which is correct on FLP, BTP, the ABAP standalone
      // URL and local dev alike. See FLP_MIGRATION.md 3.5.
      link.href = sap.ui.require.toUrl('com/zgp9/fe/css/style.css');
      link.setAttribute('data-app-stylesheet', 'true');
      document.head.appendChild(link);
    },
    getContentDensityClass: function _getContentDensityClass() {
      if (this.contentDensityClass === undefined) {
        if (document.body.classList.contains('sapUiSizeCozy') || document.body.classList.contains('sapUiSizeCompact')) {
          this.contentDensityClass = '';
        } else if (!support.touch) {
          this.contentDensityClass = 'sapUiSizeCompact';
        } else {
          this.contentDensityClass = 'sapUiSizeCozy';
        }
      }
      return this.contentDensityClass;
    },
    getAuthenticationService: function _getAuthenticationService() {
      return this.authenticationService;
    },
    getRegistryService: function _getRegistryService() {
      return this.registryService;
    },
    getVersionService: function _getVersionService() {
      return this.versionService;
    },
    getDetailService: function _getDetailService() {
      return this.detailService;
    },
    getJobService: function _getJobService() {
      return this.jobService;
    },
    getLogService: function _getLogService() {
      return this.logService;
    },
    getErrorHandler: function _getErrorHandler() {
      return this.errorHandler;
    }
  });
  return Component;
});
//# sourceMappingURL=Component-dbg.js.map
