sap.ui.define(["sap/ui/core/UIComponent", "sap/ui/Device", "sap/ui/core/Messaging", "sap/ui/core/Theming", "./services/SessionStorage", "./services/AuthenticationService", "./services/DetailService", "./services/ErrorHandler", "./services/JobService", "./services/LogService", "./services/ODataClient", "./services/RegistryService", "./services/VersionService", "./model/models"], function (UIComponent, Device, Messaging, Theming, ___services_SessionStorage, __AuthenticationService, __DetailService, __ErrorHandler, __JobService, __LogService, __ODataClient, __RegistryService, __VersionService, __models) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const readThemePreference = ___services_SessionStorage["readThemePreference"];
  const writeSessionStorage = ___services_SessionStorage["writeSessionStorage"];
  const AuthenticationService = _interopRequireDefault(__AuthenticationService);
  const DetailService = _interopRequireDefault(__DetailService);
  const ErrorHandler = _interopRequireDefault(__ErrorHandler);
  const JobService = _interopRequireDefault(__JobService);
  const LogService = _interopRequireDefault(__LogService);
  const ODataClient = _interopRequireDefault(__ODataClient);
  const RegistryService = _interopRequireDefault(__RegistryService);
  const VersionService = _interopRequireDefault(__VersionService);
  const models = _interopRequireDefault(__models);
  /**
   * @namespace com.zgp9.fe
   */
  const Component = UIComponent.extend("com.zgp9.fe.Component", {
    constructor: function constructor() {
      UIComponent.prototype.constructor.apply(this, arguments);
      this.authenticationService = new AuthenticationService();
      this.detailService = new DetailService();
      this.registryService = new RegistryService();
      this.versionService = new VersionService(this.detailService);
      this.jobService = new JobService();
      this.logService = new LogService();
    },
    metadata: {
      manifest: 'json',
      interfaces: ['sap.ui.core.IAsyncContentCreation']
    },
    init: function _init() {
      UIComponent.prototype.init.call(this);
      this.applyStoredTheme();
      this.setModel(models.createDeviceModel(), 'device');
      this.setModel(models.createSessionModel(), 'session');
      this.setModel(models.createUiModel(), 'ui');
      this.setModel(Messaging.getMessageModel(), 'message');
      this.injectAppStylesheet();
      this.errorHandler = new ErrorHandler(this.getRouter(), this.authenticationService);
      this.setupRouteGuard();
      void this.restoreSessionOnStartup();
      this.getRouter().initialize();
    },
    applyStoredTheme: function _applyStoredTheme() {
      const storedTheme = readThemePreference();
      if (storedTheme && storedTheme !== Theming.getTheme()) {
        Theming.setTheme(storedTheme);
      }
    },
    setupRouteGuard: function _setupRouteGuard() {
      this.getRouter().attachBeforeRouteMatched(event => {
        const routeName = event.getParameter('name');
        const sessionModel = this.getModel('session');
        const session = sessionModel.getData();
        const isLoginRoute = !routeName || routeName === 'login';
        if (session.authenticated && isLoginRoute) {
          // Logged in but trying to reach login -> redirect to home
          event.preventDefault();
          this.getRouter().navTo('home', {}, undefined, true);
        } else if (!session.authenticated && !isLoginRoute) {
          // Not logged in but trying to reach protected page -> redirect to login
          event.preventDefault();
          this.getRouter().navTo('', {}, undefined, true);
        }
      });
    },
    injectAppStylesheet: function _injectAppStylesheet() {
      if (document.head.querySelector('link[data-app-stylesheet="true"]')) {
        return;
      }
      const link = document.createElement('link');
      link.rel = 'stylesheet';
      link.href = new URL('css/style.css', document.baseURI).toString();
      link.setAttribute('data-app-stylesheet', 'true');
      document.head.appendChild(link);
    },
    restoreSessionOnStartup: async function _restoreSessionOnStartup() {
      const sessionModel = this.getModel('session');
      const session = sessionModel.getData();

      // Case 1: a session is already stored locally -> validate it against the backend.
      if (session.authenticated) {
        try {
          await this.registryService.getPermissions();
          this.navigateAfterAutoLogin();
          return;
        } catch {
          // Stored session is stale; fall through to a fresh backend probe below.
        }
      }

      // Case 2: no valid local session. When the app is served from the authenticated
      // SAP system (deployed), the browser already holds a valid session cookie, so this
      // probe succeeds and we can skip the custom login form. Running standalone/locally
      // it fails with 401 and the login form is shown as usual.
      try {
        await ODataClient.checkAuthAndFetchCsrf();
        const restored = {
          authenticated: true,
          userName: await this.resolveCurrentUser(),
          csrfToken: '',
          loginAt: new Date().toISOString()
        };
        sessionModel.setData(restored);
        writeSessionStorage(restored);
        this.navigateAfterAutoLogin();
      } catch {
        // Not authenticated at the server -> keep the custom login form.
        sessionModel.setData({
          authenticated: false,
          userName: '',
          csrfToken: '',
          loginAt: null
        });
      }
    },
    navigateAfterAutoLogin: function _navigateAfterAutoLogin() {
      const currentHash = window.location.hash.replace(/^#/, '');
      if (!currentHash || currentHash === 'login') {
        this.getRouter().navTo('home', {}, true);
      }
    },
    resolveCurrentUser: async function _resolveCurrentUser() {
      // After a cookie/SSO/basic-auth (popup) login there is no typed user name and
      // our OData service does not echo it back, so we have to ask the SAP system.

      // 1) The SAP session cookie often carries the logon user, e.g.
      //    "sap-usercontext=sap-user=DEV-173&sap-client=324". No round-trip needed.
      const cookieUser = this.readUserFromCookie();
      if (cookieUser) {
        return cookieUser;
      }

      // 2) The /UI2/ start_up service exposes the user profile when available.
      try {
        const response = await fetch('/sap/bc/ui2/start_up?sap-client=324', {
          method: 'GET',
          credentials: 'include',
          headers: {
            Accept: 'application/json'
          }
        });
        if (response.ok) {
          const data = await response.json();
          const user = this.extractUserName(data);
          if (user) {
            return user;
          }
        }
      } catch {
        // Ignore and fall back to a generic label.
      }
      return 'SAP User';
    },
    readUserFromCookie: function _readUserFromCookie() {
      if (typeof document === 'undefined') {
        return '';
      }
      const match = /sap-user=([^;&]+)/i.exec(document.cookie);
      return match ? decodeURIComponent(match[1]).trim() : '';
    },
    extractUserName: function _extractUserName(data) {
      // start_up shapes vary by system; the profile may be nested under "user".
      const source = data.user ?? data;
      const candidateKeys = ['fullName', 'displayName', 'id', 'CURRENT_USER', 'currentUser', 'name', 'userName'];
      for (const key of candidateKeys) {
        const value = source[key];
        if (typeof value === 'string' && value.trim()) {
          return value.trim();
        }
      }
      const firstName = typeof source.firstName === 'string' ? source.firstName.trim() : '';
      const lastName = typeof source.lastName === 'string' ? source.lastName.trim() : '';
      const combined = `${firstName} ${lastName}`.trim();
      return combined;
    },
    getContentDensityClass: function _getContentDensityClass() {
      if (this.contentDensityClass === undefined) {
        if (document.body.classList.contains('sapUiSizeCozy') || document.body.classList.contains('sapUiSizeCompact')) {
          this.contentDensityClass = '';
        } else if (!Device.support.touch) {
          this.contentDensityClass = 'sapUiSizeCompact';
        } else {
          this.contentDensityClass = 'sapUiSizeCozy';
        }
      }
      return this.contentDensityClass;
    },
    getAuthenticationService: function _getAuthenticationService() {
      return this.authenticationService;
    },
    getRegistryService: function _getRegistryService() {
      return this.registryService;
    },
    getVersionService: function _getVersionService() {
      return this.versionService;
    },
    getDetailService: function _getDetailService() {
      return this.detailService;
    },
    getJobService: function _getJobService() {
      return this.jobService;
    },
    getLogService: function _getLogService() {
      return this.logService;
    },
    getErrorHandler: function _getErrorHandler() {
      return this.errorHandler;
    },
    getMessageManager: function _getMessageManager() {
      return Messaging;
    }
  });
  return Component;
});
//# sourceMappingURL=Component-dbg.js.map
