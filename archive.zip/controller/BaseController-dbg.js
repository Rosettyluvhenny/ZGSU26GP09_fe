sap.ui.define(["sap/ui/core/mvc/Controller", "sap/ui/core/UIComponent", "sap/ui/model/json/JSONModel", "sap/ui/core/routing/History", "sap/ui/core/Fragment", "sap/m/MessageToast", "../services/AiChatService", "../services/XmlNodeUtils"], function (Controller, UIComponent, JSONModel, History, Fragment, MessageToast, __AiChatService, ___services_XmlNodeUtils) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const AiChatService = _interopRequireDefault(__AiChatService);
  const AI_MODEL_AUTO = __AiChatService["AI_MODEL_AUTO"];
  const highlightXmlLine = ___services_XmlNodeUtils["highlightXmlLine"];
  // Only the most recent turns are sent to the model to stay within free-tier limits.
  const AI_CHAT_HISTORY_LIMIT = 12;
  const DEFAULT_AI_SUGGESTIONS = ['Summarize this XML', 'List entity types and keys', 'Spot potential issues'];

  /**
   * @namespace com.zgp9.fe.controller
   */
  const BaseController = Controller.extend("com.zgp9.fe.controller.BaseController", {
    constructor: function constructor() {
      Controller.prototype.constructor.apply(this, arguments);
      this.aiChatService = new AiChatService();
      this.aiChatDialogPromise = null;
      this.aiChatDialog = null;
      this.aiChatStorageKey = null;
    },
    getOwnerComponent: function _getOwnerComponent() {
      return Controller.prototype.getOwnerComponent.call(this);
    },
    getAppComponent: function _getAppComponent() {
      return this.getOwnerComponent();
    },
    getRouter: function _getRouter() {
      return UIComponent.getRouterFor(this);
    },
    getResourceBundle: function _getResourceBundle() {
      const model = this.getOwnerComponent().getModel('i18n');
      return model.getResourceBundle();
    },
    getModel: function _getModel(sName) {
      return this.getView().getModel(sName);
    },
    setModel: function _setModel(oModel, sName) {
      this.getView().setModel(oModel, sName);
      return this;
    },
    getUiModel: function _getUiModel() {
      return this.getOwnerComponent().getModel('ui');
    },
    getSessionModel: function _getSessionModel() {
      return this.getOwnerComponent().getModel('session');
    },
    navTo: function _navTo(sName, oParameters, bReplace) {
      this.getRouter().navTo(sName, oParameters, undefined, bReplace);
    },
    handleServiceError: async function _handleServiceError(error) {
      await this.getOwnerComponent().getErrorHandler().handle(error);
    },
    formatXmlLine: function _formatXmlLine(text) {
      return highlightXmlLine(text ?? '');
    },
    formatDateTime: function _formatDateTime(value) {
      if (!value) {
        return '';
      }
      return new Intl.DateTimeFormat('en', {
        dateStyle: 'medium',
        timeStyle: 'short'
      }).format(new Date(value));
    },
    formatDuration: function _formatDuration(durationMs) {
      if (durationMs === null || durationMs === undefined) {
        return '';
      }
      const totalSeconds = Math.max(0, Math.round(durationMs / 1000));
      const minutes = Math.floor(totalSeconds / 60);
      const seconds = totalSeconds % 60;
      return `${minutes}m ${seconds}s`;
    },
    formatStatusState: function _formatStatusState(status) {
      switch (status) {
        case 'Published':
        case 'Completed':
          return 'Success';
        case 'Unpublished':
        case 'Queued':
          return 'Warning';
        case 'Archive':
        case 'Failed':
          return 'Error';
        case 'Running':
          return 'Information';
        default:
          return 'None';
      }
    },
    // ── AI Chat ──────────────────────────────────────────────────────────────
    /**
     * Controllers that offer the AI chat override this to provide the XML context
     * (e.g. the selected detail's metadata XML) the assistant should analyze.
     */
    getAiChatContext: function _getAiChatContext() {
      return null;
    },
    onOpenAiChat: function _onOpenAiChat() {
      const context = this.getAiChatContext();
      let model = this.getModel('aiChat');
      if (!model) {
        model = new JSONModel({
          messages: [],
          input: '',
          busy: false,
          thinking: false,
          contextLabel: '',
          suggestions: [],
          models: [],
          selectedModel: AI_MODEL_AUTO
        });
        this.setModel(model, 'aiChat');
      }
      model.setProperty('/models', this.aiChatService.getModelOptions());
      model.setProperty('/selectedModel', this.aiChatService.getPreferredModel());
      model.setProperty('/contextLabel', context?.label ?? '');
      model.setProperty('/suggestions', (context?.suggestions ?? DEFAULT_AI_SUGGESTIONS).map(text => ({
        text
      })));

      // Restore the conversation persisted for this context (per browser tab).
      this.aiChatStorageKey = context?.storageKey ?? null;
      const storedMessages = this.aiChatStorageKey ? this.aiChatService.loadChatHistory(this.aiChatStorageKey) : [];
      model.setProperty('/messages', storedMessages);
      if (storedMessages.length > 0) {
        this.scrollAiChatToBottom();
      }
      if (this.aiChatDialogPromise === null) {
        this.aiChatDialogPromise = Fragment.load({
          id: this.getView().getId(),
          name: 'com.zgp9.fe.view.fragments.AiChatDialog',
          controller: this
        });
      }
      void this.aiChatDialogPromise.then(dialog => {
        this.aiChatDialog = dialog;
        if (!dialog.getParent()) {
          this.getView().addDependent(dialog);
        }
        dialog.open();
      }, error => {
        // Without this the rejected promise stays cached, so every later click is a
        // no-op too and the button just looks dead — which is how a 1.108-only
        // fragment error went unnoticed until it reached the launchpad.
        this.aiChatDialogPromise = null;
        MessageToast.show('The AI assistant could not be opened.');
        throw error;
      });
    },
    onAiChatClose: function _onAiChatClose() {
      this.aiChatDialog?.close();
    },
    onAiChatAfterOpen: function _onAiChatAfterOpen() {
      this.focusAiChatInput();
    },
    focusAiChatInput: function _focusAiChatInput() {
      setTimeout(() => {
        this.byId('aiChatInput')?.focus?.();
      }, 100);
    },
    onAiChatClear: function _onAiChatClear() {
      const model = this.getModel('aiChat');
      model.setProperty('/messages', []);
      model.setProperty('/input', '');
      this.persistAiChat([]);
    },
    persistAiChat: function _persistAiChat(messages) {
      if (this.aiChatStorageKey) {
        this.aiChatService.saveChatHistory(this.aiChatStorageKey, messages);
      }
    },
    onAiModelChange: function _onAiModelChange() {
      const model = this.getModel('aiChat');
      const selected = model.getProperty('/selectedModel') || AI_MODEL_AUTO;
      this.aiChatService.setPreferredModel(selected);
    },
    onAiSuggestedPrompt: function _onAiSuggestedPrompt(event) {
      const model = this.getModel('aiChat');
      model.setProperty('/input', event.getSource().getText());
      void this.onAiChatSend();
    },
    onAiChatSend: async function _onAiChatSend() {
      const model = this.getModel('aiChat');
      const input = (model.getProperty('/input') ?? '').trim();
      if (!input || model.getProperty('/busy')) {
        return;
      }
      const messages = [...model.getProperty('/messages')];
      messages.push({
        role: 'user',
        text: input,
        html: this.markdownToHtml(input)
      });

      // History is captured before the placeholder below so the empty
      // assistant message is never sent to the model.
      const history = messages.filter(message => message.role !== 'error').slice(-AI_CHAT_HISTORY_LIMIT).map(message => ({
        role: message.role === 'user' ? 'user' : 'assistant',
        content: message.text
      }));

      // Placeholder bubble that fills up as the answer streams in.
      messages.push({
        role: 'assistant',
        text: '',
        html: ''
      });
      const assistantIndex = messages.length - 1;
      model.setProperty('/messages', messages);
      model.setProperty('/input', '');
      model.setProperty('/busy', true);
      model.setProperty('/thinking', true);
      this.scrollAiChatToBottom();
      let partialText = '';
      let lastRender = 0;
      try {
        const context = this.getAiChatContext();
        const systemPrompt = this.aiChatService.buildSystemPrompt(context?.label ?? 'No XML loaded', context?.xml ?? '');
        const answer = await this.aiChatService.askStream([{
          role: 'system',
          content: systemPrompt
        }, ...history], fullText => {
          partialText = fullText;
          model.setProperty('/thinking', false);
          // Re-rendering markdown on every token is wasteful; ~10 fps is plenty.
          const now = Date.now();
          if (now - lastRender < 100) {
            return;
          }
          lastRender = now;
          model.setProperty(`/messages/${assistantIndex}/html`, this.markdownToHtml(fullText));
          this.scrollAiChatToBottom(true);
        }, model.getProperty('/selectedModel') || AI_MODEL_AUTO);
        messages[assistantIndex] = {
          role: 'assistant',
          text: answer,
          html: this.markdownToHtml(answer)
        };
      } catch (error) {
        const message = error instanceof Error ? error.message : JSON.stringify(error);
        const errorMessage = {
          role: 'error',
          text: message,
          html: this.markdownToHtml(message)
        };
        if (partialText) {
          // Keep whatever streamed before the failure and append the error.
          messages[assistantIndex] = {
            role: 'assistant',
            text: partialText,
            html: this.markdownToHtml(partialText)
          };
          messages.push(errorMessage);
        } else {
          messages[assistantIndex] = errorMessage;
        }
      } finally {
        model.setProperty('/messages', [...messages]);
        model.setProperty('/busy', false);
        model.setProperty('/thinking', false);
        this.persistAiChat(messages);
        this.scrollAiChatToBottom();
        this.focusAiChatInput();
      }
    },
    scrollAiChatToBottom: function _scrollAiChatToBottom(immediate = false) {
      const doScroll = () => {
        const scroll = this.byId('aiChatScroll');
        scroll?.scrollTo(0, 999999, immediate ? 0 : 200);
      };
      if (immediate) {
        doScroll();
      } else {
        setTimeout(doScroll, 100);
      }
    },
    /**
     * Minimal markdown -> HTML converter restricted to tags supported by
     * sap.m.FormattedText. Input is escaped first, so model output cannot inject markup.
     */
    markdownToHtml: function _markdownToHtml(markdown) {
      const escaped = markdown.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

      // Fenced code blocks
      let html = escaped.replace(/```[a-zA-Z]*\n([\s\S]*?)```/g, (_match, code) => `<pre><code>${code.replace(/\n$/, '')}</code></pre>`);

      // Inline code, bold, italic
      html = html.replace(/`([^`\n]+)`/g, '<code>$1</code>').replace(/\*\*([^*\n]+)\*\*/g, '<strong>$1</strong>').replace(/(^|[^*])\*([^*\n]+)\*/g, '$1<em>$2</em>');

      // Bullet / numbered lists and tables (line based, outside of <pre> blocks)
      const lines = html.split('\n');
      const output = [];
      let listTag = null;
      let inPre = false;
      const tableBuffer = [];
      const closeList = () => {
        if (listTag) {
          output.push(`</${listTag}>`);
          listTag = null;
        }
      };
      const flushTable = () => {
        if (tableBuffer.length > 0) {
          output.push(this.renderMarkdownTable(tableBuffer));
          tableBuffer.length = 0;
        }
      };
      for (const line of lines) {
        if (line.includes('<pre>')) {
          inPre = true;
        }
        if (inPre) {
          flushTable();
          closeList();
          output.push(line);
          if (line.includes('</pre>')) {
            inPre = false;
          }
          continue;
        }

        // FormattedText cannot render <table>, so pipe tables become aligned monospace blocks.
        if (/^\s*\|.*\|\s*$/.test(line)) {
          closeList();
          tableBuffer.push(line);
          continue;
        }
        flushTable();
        const bulletMatch = /^\s*[-*]\s+(.*)$/.exec(line);
        const numberMatch = /^\s*\d+[.)]\s+(.*)$/.exec(line);
        if (bulletMatch || numberMatch) {
          const desiredTag = bulletMatch ? 'ul' : 'ol';
          if (listTag !== desiredTag) {
            closeList();
            output.push(`<${desiredTag}>`);
            listTag = desiredTag;
          }
          output.push(`<li>${(bulletMatch ?? numberMatch)[1]}</li>`);
        } else {
          closeList();
          output.push(line.length > 0 ? `${line}<br>` : '');
        }
      }
      flushTable();
      closeList();
      return output.join('\n');
    },
    /**
     * Renders a markdown pipe table as a column-aligned monospace block,
     * since sap.m.FormattedText does not support <table> markup.
     */
    renderMarkdownTable: function _renderMarkdownTable(lines) {
      // Visible length: HTML entities from the earlier escaping count as one character.
      const visibleLength = cell => cell.replace(/&(amp|lt|gt|quot);/g, 'x').length;
      const rows = lines.map(line => line.trim().replace(/^\|/, '').replace(/\|$/, '').split('|').map(cell => cell.trim())).filter(cells => !(cells.length > 0 && cells.every(cell => /^:?-{2,}:?$/.test(cell))));
      if (rows.length === 0) {
        return '';
      }
      const columnWidths = [];
      for (const row of rows) {
        row.forEach((cell, index) => {
          columnWidths[index] = Math.max(columnWidths[index] ?? 0, visibleLength(cell));
        });
      }
      const rendered = rows.map(row => row.map((cell, index) => cell + ' '.repeat(columnWidths[index] - visibleLength(cell))).join('  ').trimEnd()).join('\n');
      return `<pre><code>${rendered}</code></pre>`;
    },
    // ─────────────────────────────────────────────────────────────────────────
    onNavBack: function _onNavBack() {
      const previousHash = History.getInstance().getPreviousHash();
      // If previous hash is undefined (direct link)
      if (previousHash !== undefined && previousHash !== '') {
        window.history.go(-1);
      } else {
        this.getRouter().navTo('home', {}, undefined, true);
      }
    }
  });
  return BaseController;
});
//# sourceMappingURL=BaseController-dbg.js.map
