sap.ui.define(["sap/ui/core/mvc/Controller", "sap/ui/core/UIComponent", "sap/ui/core/routing/History"], function (Controller, UIComponent, History) {
  "use strict";

  /**
   * @namespace com.zgp9.fe.controller
   */
  const BaseController = Controller.extend("com.zgp9.fe.controller.BaseController", {
    getOwnerComponent: function _getOwnerComponent() {
      return Controller.prototype.getOwnerComponent.call(this);
    },
    getAppComponent: function _getAppComponent() {
      return this.getOwnerComponent();
    },
    getRouter: function _getRouter() {
      return UIComponent.getRouterFor(this);
    },
    getResourceBundle: function _getResourceBundle() {
      const model = this.getOwnerComponent().getModel('i18n');
      return model.getResourceBundle();
    },
    getModel: function _getModel(sName) {
      return this.getView().getModel(sName);
    },
    setModel: function _setModel(oModel, sName) {
      this.getView().setModel(oModel, sName);
      return this;
    },
    getUiModel: function _getUiModel() {
      return this.getOwnerComponent().getModel('ui');
    },
    getSessionModel: function _getSessionModel() {
      return this.getOwnerComponent().getModel('session');
    },
    navTo: function _navTo(sName, oParameters, bReplace) {
      this.getRouter().navTo(sName, oParameters, undefined, bReplace);
    },
    handleServiceError: async function _handleServiceError(error) {
      await this.getOwnerComponent().getErrorHandler().handle(error);
    },
    formatDateTime: function _formatDateTime(value) {
      if (!value) {
        return '';
      }
      return new Intl.DateTimeFormat('en', {
        dateStyle: 'medium',
        timeStyle: 'short'
      }).format(new Date(value));
    },
    formatDuration: function _formatDuration(durationMs) {
      if (durationMs === null || durationMs === undefined) {
        return '';
      }
      const totalSeconds = Math.max(0, Math.round(durationMs / 1000));
      const minutes = Math.floor(totalSeconds / 60);
      const seconds = totalSeconds % 60;
      return `${minutes}m ${seconds}s`;
    },
    formatStatusState: function _formatStatusState(status) {
      switch (status) {
        case 'Published':
        case 'Completed':
          return 'Success';
        case 'Unpublished':
        case 'Queued':
          return 'Warning';
        case 'Archive':
        case 'Failed':
          return 'Error';
        case 'Running':
          return 'Information';
        default:
          return 'None';
      }
    },
    onNavBack: function _onNavBack() {
      const previousHash = History.getInstance().getPreviousHash();
      // If previous hash is undefined (direct link) or empty (login page)
      if (previousHash !== undefined && previousHash !== '') {
        window.history.go(-1);
      } else {
        const session = this.getSessionModel().getData();
        if (session?.authenticated) {
          this.getRouter().navTo('home', {}, undefined, true);
        } else {
          this.getRouter().navTo('login', {}, undefined, true);
        }
      }
    }
  });
  return BaseController;
});
//# sourceMappingURL=BaseController-dbg.js.map
