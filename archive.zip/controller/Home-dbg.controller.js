sap.ui.define(["sap/ui/model/json/JSONModel", "./BaseController"], function (JSONModel, __BaseController) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const BaseController = _interopRequireDefault(__BaseController);
  /** A single row in the merged Recent Activity feed (scan jobs + audit logs). */
  /** Registry enriched with a change summary derived from its two most recent versions. */
  /** Metadata categories diffed to build a change summary; entityTypes/entitySets are merged separately into "entity". */
  const DIFF_CATEGORIES = [{
    key: 'properties',
    noun: 'property'
  }, {
    key: 'navigationProperties',
    noun: 'navigation property'
  }, {
    key: 'functionImports',
    noun: 'function import'
  }, {
    key: 'actions',
    noun: 'action'
  }, {
    key: 'complexTypes',
    noun: 'complex type'
  }];
  const RECENT_LIMIT = 5;
  const STALE_THRESHOLD_MS = 7 * 24 * 60 * 60 * 1000;
  const ACTIVITY_LIMIT = 8;
  const ACTIVITY_LOG_FETCH = 15;
  const SCAN_TREND_DAYS = 14;
  const AUTO_REFRESH_MS = 60_000;
  const DAY_MS = 24 * 60 * 60 * 1000;

  /**
   * @namespace com.zgp9.fe.controller
   */
  const Home = BaseController.extend("com.zgp9.fe.controller.Home", {
    constructor: function constructor() {
      BaseController.prototype.constructor.apply(this, arguments);
      this.refreshTimer = null;
      this.onVisibilityChange = () => {
        // Refresh immediately when the tab becomes visible again so the user
        // never returns to stale numbers; the interval keeps it fresh after that.
        if (!document.hidden) {
          void this.refreshLight();
        }
      };
      // Arrow field so it stays bound when attached/detached from the router.
      this.onAnyRouteMatched = event => {
        if (event.getParameter('name') !== 'home') {
          this.stopAutoRefresh();
        }
      };
      /** Cached change summaries keyed by registry id, so the 60s poll only re-diffs registries that actually changed. */
      this.summaryCache = new Map();
    },
    onInit: function _onInit() {
      this.setModel(new JSONModel({
        busy: false,
        registryStats: {
          total: 0,
          published: 0,
          unpublished: 0,
          archive: 0
        },
        kpiDelta: {
          totalNew: 0,
          publishedChanged: 0,
          unpublishedChanged: 0,
          archiveChanged: 0
        },
        recentRegistries: [],
        activity: [],
        scanTrend: [],
        scanSummary: {
          total: 0,
          peakValue: 0,
          peakLabel: '',
          startLabel: '',
          endLabel: ''
        },
        attentionItems: [],
        attentionCount: 0,
        lastUpdated: null
      }), 'home');
      this.getRouter().getRoute('home').attachPatternMatched(() => {
        void this.loadDashboard();
        this.startAutoRefresh();
      });

      // The Home view is cached in the FlexibleColumnLayout, so onExit does not
      // fire on navigation — stop polling as soon as any other route matches.
      this.getRouter().attachRouteMatched(this.onAnyRouteMatched, this);
      document.addEventListener('visibilitychange', this.onVisibilityChange);
    },
    onExit: function _onExit() {
      this.stopAutoRefresh();
      this.getRouter().detachRouteMatched(this.onAnyRouteMatched, this);
      document.removeEventListener('visibilitychange', this.onVisibilityChange);
    },
    startAutoRefresh: function _startAutoRefresh() {
      if (this.refreshTimer !== null) {
        return;
      }
      this.refreshTimer = window.setInterval(() => {
        // Skip hidden tabs — no point polling the backend nobody is watching.
        if (!document.hidden) {
          void this.refreshLight();
        }
      }, AUTO_REFRESH_MS);
    },
    stopAutoRefresh: function _stopAutoRefresh() {
      if (this.refreshTimer !== null) {
        window.clearInterval(this.refreshTimer);
        this.refreshTimer = null;
      }
    },
    onNavigateRegistries: function _onNavigateRegistries(event) {
      const source = event?.getSource();
      const status = source?.data?.('status');
      this.navTo('registryList', status ? {
        query: {
          status
        }
      } : {});
    },
    onNavigateJobs: function _onNavigateJobs() {
      this.navTo('jobList');
    },
    onRegistryPress: function _onRegistryPress(event) {
      const registry = this.getEntityFromEvent(event);
      if (!registry) {
        return;
      }
      this.navTo('registryDetail', {
        registryId: registry.id
      });
    },
    onAttentionItemPress: function _onAttentionItemPress(event) {
      const item = this.getEntityFromEvent(event);
      if (!item) {
        return;
      }
      if (item.action === 'jobs') {
        this.onNavigateJobs();
      } else {
        this.onNavigateRegistries();
      }
    },
    formatRelativeTime: function _formatRelativeTime(value) {
      if (!value) {
        return '';
      }
      const then = new Date(value).getTime();
      if (Number.isNaN(then)) {
        return '';
      }
      const diffMs = Date.now() - then;
      const minutes = Math.floor(diffMs / 60000);
      if (minutes < 1) {
        return 'just now';
      }
      if (minutes < 60) {
        return `${minutes} min ago`;
      }
      const hours = Math.floor(minutes / 60);
      if (hours < 24) {
        return `${hours} hour${hours === 1 ? '' : 's'} ago`;
      }
      const days = Math.floor(hours / 24);
      if (days < 30) {
        return `${days} day${days === 1 ? '' : 's'} ago`;
      }
      return this.formatDateTime(value);
    },
    formatJobTitle: function _formatJobTitle(job) {
      if (!job) {
        return '';
      }
      return `${this.formatTriggerLabel(job)} scan`;
    },
    formatJobSubtitle: function _formatJobSubtitle(job) {
      if (!job) {
        return '';
      }
      const registriesLabel = `${job.totalRegistry} registr${job.totalRegistry === 1 ? 'y' : 'ies'}`;
      const completionPhrase = this.formatCompletionPhrase(job);
      const changesLabel = this.formatChangesLabel(job);
      const relativeTime = this.formatRelativeTime(job.startedAt);
      const errorSuffix = job.status === 'Failed' && job.errorMessage ? ` — ${job.errorMessage}` : '';
      return `${registriesLabel} · ${completionPhrase} · ${changesLabel} · ${relativeTime}${errorSuffix}`;
    },
    formatTriggerLabel: function _formatTriggerLabel(job) {
      switch ((job.triggerType || '').toUpperCase()) {
        case 'SCHEDULE':
        case 'SCHEDULED':
          return 'Scheduled';
        case 'MANUAL':
          return 'Manual';
        case 'API':
          return 'API';
        default:
          return job.triggerText || 'Scan';
      }
    },
    formatCompletionPhrase: function _formatCompletionPhrase(job) {
      const duration = this.formatDuration(job.durationMs);
      switch (job.status) {
        case 'Running':
          return 'In progress';
        case 'Queued':
          return 'Queued';
        case 'Failed':
          return duration ? `Failed after ${duration}` : 'Failed';
        default:
          return duration ? `Completed in ${duration}` : 'Completed';
      }
    },
    formatChangesLabel: function _formatChangesLabel(job) {
      if (job.changeCount <= 0 && job.newVersionCount <= 0) {
        return 'No changes detected';
      }
      const parts = [];
      if (job.changeCount > 0) {
        parts.push(`${job.changeCount} change${job.changeCount === 1 ? '' : 's'}`);
      }
      if (job.newVersionCount > 0) {
        parts.push(`${job.newVersionCount} new version${job.newVersionCount === 1 ? '' : 's'}`);
      }
      return parts.join(', ');
    },
    onManualRefresh: async function _onManualRefresh() {
      await this.fetchAndApply(true);
    },
    /** Full load with a busy spinner — used on entry and manual refresh. */loadDashboard: async function _loadDashboard() {
      await this.fetchAndApply(true);
    },
    /** Silent 60s poll — no spinner, no error dialogs; reuses cached change summaries. */refreshLight: async function _refreshLight() {
      await this.fetchAndApply(false);
    },
    fetchAndApply: async function _fetchAndApply(showBusy) {
      const model = this.getModel('home');
      if (showBusy) {
        model.setProperty('/busy', true);
      }
      try {
        const component = this.getOwnerComponent();
        const [registries, jobs, logs] = await Promise.all([component.getRegistryService().getRegistries({
          search: '',
          searchField: 'all',
          status: 'All',
          groupType: 'All',
          registryName: '',
          createdBy: ''
        }), component.getJobService().getJobs(), this.loadRecentLogs()]);
        const recentRegistries = this.sortByDateDesc(registries, registry => registry.lastChangedAt).slice(0, RECENT_LIMIT);
        const recentRegistryCards = await this.attachChangeSummaries(recentRegistries);
        const attentionItems = this.computeAttentionItems(registries, jobs);
        model.setProperty('/registryStats', this.computeRegistryStats(registries));
        model.setProperty('/kpiDelta', this.computeKpiDelta(registries));
        model.setProperty('/recentRegistries', recentRegistryCards);
        model.setProperty('/activity', this.buildActivity(jobs, logs));
        const scanActivity = this.bucketScanTrend(jobs);
        model.setProperty('/scanTrend', scanActivity.points);
        model.setProperty('/scanSummary', scanActivity.summary);
        model.setProperty('/attentionItems', attentionItems);
        model.setProperty('/attentionCount', attentionItems.length);
        model.setProperty('/lastUpdated', new Date().toISOString());
      } catch (error) {
        // The silent poll must not pop error dialogs for transient failures.
        if (showBusy) {
          await this.handleServiceError(error);
        }
      } finally {
        if (showBusy) {
          model.setProperty('/busy', false);
        }
      }
    },
    /** Logs are supplementary — a failure here must not blank out the whole dashboard. */loadRecentLogs: async function _loadRecentLogs() {
      try {
        const page = await this.getOwnerComponent().getLogService().getLogs({
          top: ACTIVITY_LOG_FETCH
        });
        return page.items;
      } catch {
        return [];
      }
    },
    computeKpiDelta: function _computeKpiDelta(registries) {
      const now = Date.now();
      const withinWindow = value => {
        const time = new Date(value).getTime();
        return Number.isFinite(time) && now - time <= STALE_THRESHOLD_MS;
      };
      return registries.reduce((delta, registry) => {
        if (withinWindow(registry.createdAt)) {
          delta.totalNew += 1;
        }
        if (withinWindow(registry.lastChangedAt)) {
          if (registry.status === 'Published') {
            delta.publishedChanged += 1;
          } else if (registry.status === 'Unpublished') {
            delta.unpublishedChanged += 1;
          } else if (registry.status === 'Archive') {
            delta.archiveChanged += 1;
          }
        }
        return delta;
      }, {
        totalNew: 0,
        publishedChanged: 0,
        unpublishedChanged: 0,
        archiveChanged: 0
      });
    },
    /** Merges scan jobs and audit logs into one time-ordered feed, de-duping scan-job log rows. */buildActivity: function _buildActivity(jobs, logs) {
      const rows = [];
      const jobIds = new Set();
      for (const job of jobs) {
        jobIds.add(this.normalizeId(job.id));
        rows.push({
          ts: new Date(job.startedAt).getTime(),
          item: {
            icon: 'sap-icon://activity-items',
            title: this.formatJobTitle(job),
            subtitle: this.formatJobSubtitle(job),
            timeAgo: this.formatRelativeTime(job.startedAt),
            state: this.formatStatusState(job.status),
            kind: 'job',
            objectIdType: 'SCANJOB',
            objectId: job.id
          }
        });
      }
      for (const log of logs) {
        // Skip scan-job log rows already shown as a richer job row above.
        if ((log.objectIdType || '').toUpperCase() === 'SCANJOB' && jobIds.has(this.normalizeId(log.objectId))) {
          continue;
        }
        rows.push({
          ts: new Date(log.actionAt).getTime(),
          item: {
            icon: this.activityLogIcon(log.objectIdType),
            title: log.actionText || log.actionType || 'Activity',
            subtitle: this.buildLogSubtitle(log),
            timeAgo: this.formatRelativeTime(log.actionAt),
            state: this.logResultState(log.logResult),
            kind: 'log',
            objectIdType: log.objectIdType,
            objectId: log.objectId
          }
        });
      }
      return rows.filter(row => Number.isFinite(row.ts)).sort((left, right) => right.ts - left.ts).slice(0, ACTIVITY_LIMIT).map(row => row.item);
    },
    onActivityPress: function _onActivityPress(event) {
      const item = this.getEntityFromEvent(event);
      if (!item) {
        return;
      }
      void this.navigateToActivity(item);
    },
    /** Routes an activity row to its object, mirroring Logs.onNavigateToObject. */navigateToActivity: async function _navigateToActivity(item) {
      const type = (item.objectIdType || '').toUpperCase();
      const objectId = item.objectId;
      if (item.kind === 'job' || type === 'SCANJOB') {
        if (objectId) {
          this.navTo('jobDetail', {
            jobId: objectId
          });
        }
        return;
      }
      if (!objectId) {
        return;
      }
      if (type === 'REGISTRY') {
        this.navTo('registryDetail', {
          registryId: objectId
        });
        return;
      }
      try {
        if (type === 'VERSION') {
          const version = await this.getOwnerComponent().getVersionService().getVersion(objectId);
          if (version.groupId) {
            this.navTo('versionDetail', {
              registryId: version.groupId,
              versionId: objectId
            });
          }
          return;
        }
        if (type === 'DETAIL') {
          const detail = await this.getOwnerComponent().getDetailService().getDetail(objectId);
          if (detail.groupId && detail.versionId) {
            this.navTo('versionDetail', {
              registryId: detail.groupId,
              versionId: detail.versionId,
              query: {
                detailId: objectId
              }
            });
          }
        }
      } catch (error) {
        await this.handleServiceError(error);
      }
    },
    /** 14 daily buckets (oldest → newest) of scan-job counts, plus summary stats, for the activity chart. */bucketScanTrend: function _bucketScanTrend(jobs) {
      const now = new Date();
      const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
      const counts = new Array(SCAN_TREND_DAYS).fill(0);
      for (const job of jobs) {
        const time = new Date(job.startedAt).getTime();
        if (!Number.isFinite(time)) {
          continue;
        }
        const jobDate = new Date(time);
        const jobDayStart = new Date(jobDate.getFullYear(), jobDate.getMonth(), jobDate.getDate()).getTime();
        const dayOffset = Math.round((startOfToday - jobDayStart) / DAY_MS);
        if (dayOffset >= 0 && dayOffset < SCAN_TREND_DAYS) {
          counts[dayOffset] += 1;
        }
      }
      const maxValue = Math.max(1, ...counts);
      const dateFormat = new Intl.DateTimeFormat('en', {
        month: 'short',
        day: 'numeric'
      });
      const fullFormat = new Intl.DateTimeFormat('en', {
        weekday: 'short',
        month: 'short',
        day: 'numeric'
      });
      const points = [];
      let total = 0;
      let peakValue = 0;
      let peakOffset = 0;
      for (let offset = SCAN_TREND_DAYS - 1; offset >= 0; offset--) {
        const value = counts[offset];
        const dayStart = startOfToday - offset * DAY_MS;
        total += value;
        if (value > peakValue) {
          peakValue = value;
          peakOffset = offset;
        }
        const isToday = offset === 0;
        const state = value === 0 ? 'empty' : isToday ? 'today' : 'normal';
        // Non-zero bars keep a legible minimum height; empty days show a faint baseline stub.
        const heightPct = value === 0 ? 6 : Math.max(14, Math.round(value / maxValue * 100));
        const scanWord = value === 1 ? 'scan' : 'scans';
        const dayName = isToday ? 'Today' : fullFormat.format(new Date(dayStart));
        points.push({
          label: dateFormat.format(new Date(dayStart)),
          value,
          heightPct,
          state,
          tooltip: `${dayName} — ${value} ${scanWord}`
        });
      }
      const summary = {
        total,
        peakValue,
        peakLabel: peakValue > 0 ? dateFormat.format(new Date(startOfToday - peakOffset * DAY_MS)) : '',
        startLabel: dateFormat.format(new Date(startOfToday - (SCAN_TREND_DAYS - 1) * DAY_MS)),
        endLabel: 'Today'
      };
      return {
        points,
        summary
      };
    },
    normalizeId: function _normalizeId(value) {
      return (value || '').replace(/[{}]/g, '').trim().toLowerCase();
    },
    buildLogSubtitle: function _buildLogSubtitle(log) {
      const actor = log.actor || 'system';
      const scope = (log.objectIdType || '').trim();
      const base = scope ? `${actor} · ${this.capitalize(scope.toLowerCase())}` : actor;
      const remarks = (log.remarks || '').trim();
      return remarks ? `${base} · ${remarks}` : base;
    },
    activityLogIcon: function _activityLogIcon(objectIdType) {
      switch ((objectIdType || '').toUpperCase()) {
        case 'REGISTRY':
          return 'sap-icon://database';
        case 'VERSION':
          return 'sap-icon://history';
        case 'DETAIL':
          return 'sap-icon://document';
        case 'SCANJOB':
          return 'sap-icon://activity-items';
        default:
          return 'sap-icon://bell';
      }
    },
    logResultState: function _logResultState(result) {
      const normalized = (result || '').toUpperCase();
      if (normalized === 'S' || normalized === 'SUCCESS') {
        return 'Success';
      }
      if (normalized === 'F' || normalized === 'E' || normalized === 'ERROR' || normalized.startsWith('FAIL')) {
        return 'Error';
      }
      return 'None';
    },
    computeRegistryStats: function _computeRegistryStats(registries) {
      return registries.reduce((stats, registry) => {
        stats.total += 1;
        if (registry.status === 'Published') {
          stats.published += 1;
        } else if (registry.status === 'Unpublished') {
          stats.unpublished += 1;
        } else if (registry.status === 'Archive') {
          stats.archive += 1;
        }
        return stats;
      }, {
        total: 0,
        published: 0,
        unpublished: 0,
        archive: 0
      });
    },
    computeAttentionItems: function _computeAttentionItems(registries, jobs) {
      const items = [];
      const now = Date.now();
      const staleRegistries = registries.filter(registry => {
        if (registry.status === 'Archive') {
          return false;
        }
        const lastChanged = new Date(registry.lastChangedAt).getTime();
        return Number.isFinite(lastChanged) && now - lastChanged > STALE_THRESHOLD_MS;
      });
      if (staleRegistries.length > 0) {
        const count = staleRegistries.length;
        items.push({
          icon: 'sap-icon://history',
          text: `${count} metadata source${count === 1 ? '' : 's'} ${count === 1 ? 'has' : 'have'} not been updated in over 7 days`,
          state: 'Warning',
          action: 'registries'
        });
      }
      const undocumentedRegistries = registries.filter(registry => registry.status !== 'Archive' && !(registry.description ?? '').trim());
      if (undocumentedRegistries.length > 0) {
        const count = undocumentedRegistries.length;
        items.push({
          icon: 'sap-icon://documents',
          text: count === 1 ? '1 registry is missing a description' : `${count} registries are missing a description`,
          state: 'Warning',
          action: 'registries'
        });
      }
      const recentFailedJobs = jobs.filter(job => {
        if (job.status !== 'Failed') {
          return false;
        }
        const startedAt = new Date(job.startedAt).getTime();
        return Number.isFinite(startedAt) && now - startedAt <= STALE_THRESHOLD_MS;
      });
      if (recentFailedJobs.length > 0) {
        const count = recentFailedJobs.length;
        items.push({
          icon: 'sap-icon://alert',
          text: `${count} scan job${count === 1 ? '' : 's'} failed in the last 7 days`,
          state: 'Error',
          action: 'jobs'
        });
      }
      return items;
    },
    /**
     * Attaches a change summary to each registry. To keep the 60s poll cheap, a
     * cached summary is reused whenever the registry's lastChangedAt is unchanged;
     * only genuinely-changed registries trigger a fresh getVersions call.
     */
    attachChangeSummaries: async function _attachChangeSummaries(registries) {
      const versionService = this.getOwnerComponent().getVersionService();
      const cards = await Promise.all(registries.map(async registry => {
        const cached = this.summaryCache.get(registry.id);
        if (cached && cached.lastChangedAt === registry.lastChangedAt) {
          return {
            ...registry,
            changeSummary: cached.summary
          };
        }
        try {
          const versions = await versionService.getVersions(registry.id);
          const summary = this.buildChangeSummary(versions);
          this.summaryCache.set(registry.id, {
            lastChangedAt: registry.lastChangedAt,
            summary
          });
          return {
            ...registry,
            changeSummary: summary
          };
        } catch {
          return {
            ...registry,
            changeSummary: this.emptyChangeSummary()
          };
        }
      }));

      // Bound cache memory to the registries currently on screen.
      const visibleIds = new Set(registries.map(registry => registry.id));
      for (const id of [...this.summaryCache.keys()]) {
        if (!visibleIds.has(id)) {
          this.summaryCache.delete(id);
        }
      }
      return cards;
    },
    emptyChangeSummary: function _emptyChangeSummary() {
      return {
        headline: 'Change history unavailable',
        breaking: false,
        hasBaseline: false,
        details: []
      };
    },
    /** Diffs the two most recent versions' metadata (name-level only — no type/annotation detail is captured here). */buildChangeSummary: function _buildChangeSummary(versions) {
      const sorted = [...versions].sort((left, right) => new Date(right.createdAt).getTime() - new Date(left.createdAt).getTime());
      const [latest, previous] = sorted;
      if (!latest || !previous) {
        return {
          headline: 'No prior version to compare yet',
          breaking: false,
          hasBaseline: false,
          details: []
        };
      }
      const details = [];
      const groups = [];
      const entitiesBefore = new Set([...previous.metadata.entityTypes, ...previous.metadata.entitySets]);
      const entitiesAfter = new Set([...latest.metadata.entityTypes, ...latest.metadata.entitySets]);
      this.diffCategory(entitiesBefore, entitiesAfter, 'entity', details, groups);
      for (const {
        key,
        noun
      } of DIFF_CATEGORIES) {
        const before = new Set(previous.metadata[key]);
        const after = new Set(latest.metadata[key]);
        this.diffCategory(before, after, noun, details, groups);
      }
      const breaking = details.some(detail => detail.severity === 'Breaking');
      const headline = groups.length === 0 ? 'No structural changes since last scan' : [...groups].sort((left, right) => right.count - left.count).slice(0, 3).map(group => `${group.count} ${this.pluralizeNoun(group.noun, group.count)} ${group.verb}`).join(' · ');
      return {
        headline,
        breaking,
        hasBaseline: true,
        details
      };
    },
    diffCategory: function _diffCategory(before, after, noun, details, groups) {
      const added = [...after].filter(value => !before.has(value));
      const removed = [...before].filter(value => !after.has(value));
      if (added.length > 0) {
        groups.push({
          noun,
          verb: 'added',
          count: added.length
        });
        for (const name of added) {
          details.push({
            text: `${this.capitalize(noun)} added: ${name}`,
            severity: 'Compatible'
          });
        }
      }
      if (removed.length > 0) {
        groups.push({
          noun,
          verb: 'removed',
          count: removed.length
        });
        for (const name of removed) {
          details.push({
            text: `${this.capitalize(noun)} removed: ${name}`,
            severity: 'Breaking'
          });
        }
      }
    },
    pluralizeNoun: function _pluralizeNoun(noun, count) {
      if (count === 1) {
        return noun;
      }
      if (/[^aeiou]y$/.test(noun)) {
        return `${noun.slice(0, -1)}ies`;
      }
      if (/(s|x|z|ch|sh)$/.test(noun)) {
        return `${noun}es`;
      }
      return `${noun}s`;
    },
    capitalize: function _capitalize(text) {
      return text.charAt(0).toUpperCase() + text.slice(1);
    },
    sortByDateDesc: function _sortByDateDesc(items, getDate) {
      return [...items].sort((left, right) => new Date(getDate(right)).getTime() - new Date(getDate(left)).getTime());
    },
    getEntityFromEvent: function _getEntityFromEvent(event) {
      const source = event.getSource();
      const context = source.getBindingContext('home');
      return context?.getObject() ?? null;
    }
  });
  return Home;
});
//# sourceMappingURL=Home-dbg.controller.js.map
