sap.ui.define(["sap/ui/model/json/JSONModel", "./BaseController"], function (JSONModel, __BaseController) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const BaseController = _interopRequireDefault(__BaseController);
  const RECENT_LIMIT = 5;

  /**
   * @namespace com.zgp9.fe.controller
   */
  const Home = BaseController.extend("com.zgp9.fe.controller.Home", {
    onInit: function _onInit() {
      this.setModel(new JSONModel({
        busy: false,
        registryStats: {
          total: 0,
          published: 0,
          unpublished: 0,
          archive: 0
        },
        recentRegistries: [],
        recentJobs: []
      }), 'home');
      this.getRouter().getRoute('home').attachPatternMatched(() => {
        void this.loadDashboard();
      });
    },
    onNavigateRegistries: function _onNavigateRegistries() {
      this.navTo('registryList');
    },
    onNavigateJobs: function _onNavigateJobs() {
      this.navTo('jobList');
    },
    onRegistryPress: function _onRegistryPress(event) {
      const registry = this.getEntityFromEvent(event);
      if (!registry) {
        return;
      }
      this.navTo('registryDetail', {
        registryId: registry.id
      });
    },
    onJobPress: function _onJobPress(event) {
      const job = this.getEntityFromEvent(event);
      if (!job) {
        return;
      }
      this.navTo('jobDetail', {
        jobId: job.id
      });
    },
    formatRelativeTime: function _formatRelativeTime(value) {
      if (!value) {
        return '';
      }
      const then = new Date(value).getTime();
      if (Number.isNaN(then)) {
        return '';
      }
      const diffMs = Date.now() - then;
      const minutes = Math.floor(diffMs / 60000);
      if (minutes < 1) {
        return 'just now';
      }
      if (minutes < 60) {
        return `${minutes} min ago`;
      }
      const hours = Math.floor(minutes / 60);
      if (hours < 24) {
        return `${hours} hour${hours === 1 ? '' : 's'} ago`;
      }
      const days = Math.floor(hours / 24);
      if (days < 30) {
        return `${days} day${days === 1 ? '' : 's'} ago`;
      }
      return this.formatDateTime(value);
    },
    loadDashboard: async function _loadDashboard() {
      const model = this.getModel('home');
      model.setProperty('/busy', true);
      try {
        const [registries, jobs] = await Promise.all([this.getOwnerComponent().getRegistryService().getRegistries({
          search: '',
          searchField: 'all',
          status: 'All',
          groupType: 'All',
          registryName: '',
          createdBy: ''
        }), this.getOwnerComponent().getJobService().getJobs()]);
        model.setProperty('/registryStats', this.computeRegistryStats(registries));
        model.setProperty('/recentRegistries', this.sortByDateDesc(registries, registry => registry.lastChangedAt).slice(0, RECENT_LIMIT));
        model.setProperty('/recentJobs', jobs.slice(0, RECENT_LIMIT));
      } catch (error) {
        await this.handleServiceError(error);
      } finally {
        model.setProperty('/busy', false);
      }
    },
    computeRegistryStats: function _computeRegistryStats(registries) {
      return registries.reduce((stats, registry) => {
        stats.total += 1;
        if (registry.status === 'Published') {
          stats.published += 1;
        } else if (registry.status === 'Unpublished') {
          stats.unpublished += 1;
        } else if (registry.status === 'Archive') {
          stats.archive += 1;
        }
        return stats;
      }, {
        total: 0,
        published: 0,
        unpublished: 0,
        archive: 0
      });
    },
    sortByDateDesc: function _sortByDateDesc(items, getDate) {
      return [...items].sort((left, right) => new Date(getDate(right)).getTime() - new Date(getDate(left)).getTime());
    },
    getEntityFromEvent: function _getEntityFromEvent(event) {
      const source = event.getSource();
      const context = source.getBindingContext('home');
      return context?.getObject() ?? null;
    }
  });
  return Home;
});
//# sourceMappingURL=Home-dbg.controller.js.map
