sap.ui.define(["sap/ui/model/json/JSONModel", "sap/ui/core/BusyIndicator", "./BaseController"], function (JSONModel, BusyIndicator, __BaseController) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const BaseController = _interopRequireDefault(__BaseController);
  /**
   * @namespace com.zgp9.fe.controller
   */
  const JobDetail = BaseController.extend("com.zgp9.fe.controller.JobDetail", {
    constructor: function constructor() {
      BaseController.prototype.constructor.apply(this, arguments);
      this.jobId = null;
    },
    onInit: function _onInit() {
      this.setModel(new JSONModel({
        busy: false,
        job: null
      }), 'jobDetail');
      this.getRouter().getRoute("jobDetail").attachPatternMatched(event => {
        void this.onRouteMatched(event);
      });
    },
    onRouteMatched: async function _onRouteMatched(event) {
      const args = event.getParameter('arguments');
      this.jobId = args.jobId ?? null;
      if (!this.jobId) {
        return;
      }
      await this.loadJob();
    },
    loadJob: async function _loadJob() {
      if (!this.jobId) {
        return;
      }
      const model = this.getModel('jobDetail');
      model.setProperty('/busy', true);
      BusyIndicator.show(0);
      try {
        const job = await this.getOwnerComponent().getJobService().getJob(this.jobId);
        model.setProperty('/job', job);
      } catch (error) {
        await this.handleServiceError(error);
      } finally {
        model.setProperty('/busy', false);
        BusyIndicator.hide();
      }
    }
  });
  return JobDetail;
});
//# sourceMappingURL=JobDetail-dbg.controller.js.map
