sap.ui.define(["sap/ui/model/json/JSONModel", "sap/ui/core/BusyIndicator", "sap/m/MessageToast", "sap/ui/core/Fragment", "./BaseController"], function (JSONModel, BusyIndicator, MessageToast, Fragment, __BaseController) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const BaseController = _interopRequireDefault(__BaseController);
  /**
   * @namespace com.zgp9.fe.controller
   */
  const JobList = BaseController.extend("com.zgp9.fe.controller.JobList", {
    constructor: function constructor() {
      BaseController.prototype.constructor.apply(this, arguments);
      this._jobDetailDialog = null;
    },
    onInit: function _onInit() {
      this.setModel(new JSONModel({
        items: [],
        busy: false,
        search: '',
        selectedJob: null
      }), 'jobList');
      this.getRouter().getRoute("jobList").attachPatternMatched(() => {
        void this.onRouteMatched();
      });
    },
    onRouteMatched: async function _onRouteMatched() {
      if (!this.getUiModel().getProperty("/canExecuteScanJob")) {
        MessageToast.show("Access denied.");
        this.getRouter().navTo("home", {}, undefined, true);
        return;
      }
      this.getModel('jobList').setProperty('/selectedJob', null);
      await this.loadJobs();
    },
    loadJobs: async function _loadJobs() {
      const model = this.getModel('jobList');
      model.setProperty('/busy', true);
      try {
        const jobs = await this.getOwnerComponent().getJobService().getJobs(model.getProperty('/search'));
        model.setProperty('/items', jobs);
      } catch (error) {
        await this.handleServiceError(error);
      } finally {
        model.setProperty('/busy', false);
      }
    },
    onRefresh: async function _onRefresh() {
      await this.loadJobs();
    },
    onSearchLiveChange: async function _onSearchLiveChange(event) {
      const source = event.getSource();
      const model = this.getModel('jobList');
      model.setProperty('/search', source.getValue());
      await this.loadJobs();
    },
    onRowPress: function _onRowPress(event) {
      const source = event.getSource();
      const job = source.getBindingContext('jobList')?.getObject();
      if (!job) {
        return;
      }
      this.getModel('jobList').setProperty('/selectedJob', job);
      void this.openJobDetailDialog();
    },
    onViewJobLogs: function _onViewJobLogs() {
      const job = this.getModel('jobList').getProperty('/selectedJob');
      if (!job) {
        return;
      }
      this._jobDetailDialog?.close();
      this.getRouter().navTo('logs', {
        '?query': {
          jobId: job.id
        }
      });
    },
    onCloseJobDialog: function _onCloseJobDialog() {
      this._jobDetailDialog?.close();
    },
    onRunScanJob: async function _onRunScanJob() {
      BusyIndicator.show(0);
      try {
        await this.getOwnerComponent().getJobService().runScanJob();
        MessageToast.show('Scan job started.');
        await this.loadJobs();
      } catch (error) {
        await this.handleServiceError(error);
      } finally {
        BusyIndicator.hide();
      }
    },
    openJobDetailDialog: async function _openJobDetailDialog() {
      if (!this._jobDetailDialog) {
        this._jobDetailDialog = await Fragment.load({
          id: this.getView().getId(),
          name: 'com.zgp9.fe.view.fragments.JobDetailDialog',
          controller: this
        });
        this.getView().addDependent(this._jobDetailDialog);
      }
      this._jobDetailDialog.open();
    }
  });
  return JobList;
});
//# sourceMappingURL=JobList-dbg.controller.js.map
