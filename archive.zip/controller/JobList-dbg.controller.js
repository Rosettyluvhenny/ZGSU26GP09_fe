sap.ui.define(["sap/ui/model/json/JSONModel", "sap/ui/core/BusyIndicator", "sap/m/MessageToast", "./BaseController"], function (JSONModel, BusyIndicator, MessageToast, __BaseController) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const BaseController = _interopRequireDefault(__BaseController);
  /**
   * @namespace com.zgp9.fe.controller
   */
  const JobList = BaseController.extend("com.zgp9.fe.controller.JobList", {
    onInit: function _onInit() {
      this.setModel(new JSONModel({
        items: [],
        busy: false,
        search: ''
      }), 'jobList');
      this.getRouter().getRoute("jobList").attachPatternMatched(event => {
        void this.onRouteMatched();
      });
    },
    onRouteMatched: async function _onRouteMatched() {
      try {
        const permissions = await this.getOwnerComponent().getRegistryService().getPermissions();
        if (!permissions.includes("ScanJob.Execute")) {
          MessageToast.show("Access denied.");
          this.getRouter().navTo("home", {}, true);
          return;
        }
      } catch (error) {
        await this.handleServiceError(error);
        return;
      }
      await this.loadJobs();
    },
    loadJobs: async function _loadJobs() {
      const model = this.getModel('jobList');
      model.setProperty('/busy', true);
      try {
        const jobs = await this.getOwnerComponent().getJobService().getJobs(model.getProperty('/search'));
        model.setProperty('/items', jobs);
        console.log('Job scan list fetched successfully', {
          count: jobs.length,
          search: model.getProperty('/search')
        });
      } catch (error) {
        await this.handleServiceError(error);
      } finally {
        model.setProperty('/busy', false);
      }
    },
    onRefresh: async function _onRefresh() {
      await this.loadJobs();
    },
    onSearchLiveChange: async function _onSearchLiveChange(event) {
      const source = event.getSource();
      const model = this.getModel('jobList');
      model.setProperty('/search', source.getValue());
      await this.loadJobs();
    },
    onRowPress: function _onRowPress(event) {
      const source = event.getSource();
      const context = source.getBindingContext('jobList');
      const job = context?.getObject();
      if (!job) {
        return;
      }
      this.navTo('jobDetail', {
        jobId: job.id
      });
    },
    onRunScanJob: async function _onRunScanJob() {
      BusyIndicator.show(0);
      try {
        await this.getOwnerComponent().getJobService().runScanJob();
        MessageToast.show('Scan job started.');
        await this.loadJobs();
      } catch (error) {
        await this.handleServiceError(error);
      } finally {
        BusyIndicator.hide();
      }
    }
  });
  return JobList;
});
//# sourceMappingURL=JobList-dbg.controller.js.map
