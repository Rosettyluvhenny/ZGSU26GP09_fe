sap.ui.define(["sap/ui/model/json/JSONModel", "sap/m/MessageBox", "sap/m/MessageToast", "./BaseController"], function (JSONModel, MessageBox, MessageToast, __BaseController) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const BaseController = _interopRequireDefault(__BaseController);
  /**
   * @namespace com.zgp9.fe.controller
   */
  const Login = BaseController.extend("com.zgp9.fe.controller.Login", {
    onInit: function _onInit() {
      const model = new JSONModel({
        userName: '',
        password: ''
      });
      this.setModel(model, 'login');
    },
    onLogin: async function _onLogin() {
      const uiModel = this.getUiModel();
      const loginModel = this.getModel('login');
      const {
        userName,
        password
      } = loginModel.getData();
      if (!userName?.trim() || !password?.trim()) {
        MessageBox.error('Username and password are required.');
        return;
      }
      uiModel.setProperty('/loginBusy', true);
      try {
        const auth = this.getOwnerComponent().getAuthenticationService();
        const session = await auth.login(userName.trim(), password);
        this.getSessionModel().setData(session);
        loginModel.setData({
          userName: '',
          password: ''
        });
        MessageToast.show(`Welcome, ${session.userName}`);
        this.getRouter().navTo('home', {}, true);
      } catch (error) {
        await this.handleServiceError(error);
      } finally {
        uiModel.setProperty('/loginBusy', false);
      }
    }
  });
  return Login;
});
//# sourceMappingURL=Login-dbg.controller.js.map
