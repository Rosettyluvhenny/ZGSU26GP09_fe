sap.ui.define(["sap/ui/model/json/JSONModel", "sap/ui/core/Fragment", "./BaseController"], function (JSONModel, Fragment, __BaseController) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const BaseController = _interopRequireDefault(__BaseController);
  /**
   * @namespace com.zgp9.fe.controller
   */
  const Logs = BaseController.extend("com.zgp9.fe.controller.Logs", {
    constructor: function constructor() {
      BaseController.prototype.constructor.apply(this, arguments);
      this.allLogs = [];
      this.dateFrom = null;
      this.dateTo = null;
    },
    onInit: function _onInit() {
      this.setModel(new JSONModel({
        items: [],
        busy: false,
        search: '',
        actionType: 'All',
        logResult: 'All',
        objectIdType: 'All',
        actionTypeOptions: [],
        logResultOptions: [],
        objectIdTypeOptions: [],
        selectedLog: null
      }), 'logList');
      this.getRouter().getRoute('logs').attachPatternMatched(() => {
        void this.loadLogs();
      });
    },
    onRefresh: async function _onRefresh() {
      await this.loadLogs();
    },
    onSearchLiveChange: function _onSearchLiveChange(event) {
      const source = event.getSource();
      this.getModel('logList').setProperty('/search', source.getValue());
      this.applyFilters();
    },
    onFilterChange: function _onFilterChange() {
      this.applyFilters();
    },
    onDateRangeChange: function _onDateRangeChange(event) {
      const source = event.getSource();
      this.dateFrom = source.getDateValue();
      this.dateTo = source.getSecondDateValue();
      this.applyFilters();
    },
    onRowPress: function _onRowPress(event) {
      const source = event.getSource();
      const log = source.getBindingContext('logList')?.getObject();
      if (!log) {
        return;
      }
      void this.openDetailDialog(log);
    },
    onNavigateToObject: function _onNavigateToObject() {
      const log = this.getModel('logList').getProperty('/selectedLog');
      if (!log || !log.objectId) {
        return;
      }
      this.closeDetailDialog();
      if (log.objectIdType === 'REGISTRY') {
        this.navTo('registryDetail', {
          registryId: log.objectId
        });
      }
    },
    onCloseDetailDialog: function _onCloseDetailDialog() {
      this.closeDetailDialog();
    },
    formatLogResultState: function _formatLogResultState(result) {
      const normalized = (result || '').toUpperCase();
      if (normalized === 'SUCCESS') {
        return 'Success';
      }
      if (normalized === 'FAILURE' || normalized === 'ERROR') {
        return 'Error';
      }
      return 'None';
    },
    loadLogs: async function _loadLogs() {
      const model = this.getModel('logList');
      model.setProperty('/busy', true);
      try {
        this.allLogs = await this.getOwnerComponent().getLogService().getLogs();
        this.buildFilterOptions();
        this.applyFilters();
      } catch (error) {
        await this.handleServiceError(error);
      } finally {
        model.setProperty('/busy', false);
      }
    },
    applyFilters: function _applyFilters() {
      const model = this.getModel('logList');
      const search = model.getProperty('/search').trim().toLowerCase();
      const actionType = model.getProperty('/actionType');
      const logResult = model.getProperty('/logResult');
      const objectIdType = model.getProperty('/objectIdType');
      const filtered = this.allLogs.filter(log => {
        if (actionType !== 'All' && log.actionType !== actionType) {
          return false;
        }
        if (logResult !== 'All' && log.logResult !== logResult) {
          return false;
        }
        if (objectIdType !== 'All' && log.objectIdType !== objectIdType) {
          return false;
        }
        if (this.dateFrom || this.dateTo) {
          const actionAt = new Date(log.actionAt).getTime();
          if (Number.isNaN(actionAt)) {
            return false;
          }
          if (this.dateFrom && actionAt < this.startOfDay(this.dateFrom).getTime()) {
            return false;
          }
          if (this.dateTo && actionAt > this.endOfDay(this.dateTo).getTime()) {
            return false;
          }
        }
        if (search) {
          const haystack = [log.id, log.actionType, log.actor, log.remarks, log.logResult, log.objectIdType, log.ipAddress].join(' ').toLowerCase();
          if (!haystack.includes(search)) {
            return false;
          }
        }
        return true;
      });
      model.setProperty('/items', filtered);
    },
    startOfDay: function _startOfDay(date) {
      const result = new Date(date);
      result.setHours(0, 0, 0, 0);
      return result;
    },
    endOfDay: function _endOfDay(date) {
      const result = new Date(date);
      result.setHours(23, 59, 59, 999);
      return result;
    },
    buildFilterOptions: function _buildFilterOptions() {
      const model = this.getModel('logList');
      model.setProperty('/actionTypeOptions', this.distinctOptions(log => log.actionType));
      model.setProperty('/logResultOptions', this.distinctOptions(log => log.logResult));
      model.setProperty('/objectIdTypeOptions', this.distinctOptions(log => log.objectIdType));
    },
    distinctOptions: function _distinctOptions(selector) {
      const values = Array.from(new Set(this.allLogs.map(selector).filter(value => Boolean(value)))).sort();
      return [{
        key: 'All',
        text: 'All'
      }, ...values.map(value => ({
        key: value,
        text: value
      }))];
    },
    openDetailDialog: async function _openDetailDialog(log) {
      this.getModel('logList').setProperty('/selectedLog', log);
      if (!this.detailDialog) {
        this.detailDialog = await Fragment.load({
          id: this.getView().getId(),
          name: 'com.zgp9.fe.view.fragments.LogDetailDialog',
          controller: this
        });
        this.getView().addDependent(this.detailDialog);
      }
      this.detailDialog.open();
    },
    closeDetailDialog: function _closeDetailDialog() {
      this.detailDialog?.close();
    }
  });
  return Logs;
});
//# sourceMappingURL=Logs-dbg.controller.js.map
