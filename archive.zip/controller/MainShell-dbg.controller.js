sap.ui.define(["sap/ui/core/Theming", "./BaseController", "../services/SessionStorage"], function (Theming, __BaseController, ___services_SessionStorage) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const BaseController = _interopRequireDefault(__BaseController);
  const writeThemePreference = ___services_SessionStorage["writeThemePreference"];
  const LIGHT_THEME = "sap_horizon";
  const DARK_THEME = "sap_horizon_dark";

  /**
   * @namespace com.zgp9.fe.controller
   */
  const MainShell = BaseController.extend("com.zgp9.fe.controller.MainShell", {
    constructor: function constructor() {
      BaseController.prototype.constructor.apply(this, arguments);
      this.pendingRoute = null;
      this.permissionsPromise = null;
    },
    onInit: function _onInit() {
      this.getRouter().attachRouteMatched(this.onGlobalRouteMatched, this);
      this.getView().addEventDelegate({
        onAfterRendering: () => this.flushPendingNavigation()
      });
    },
    loadGlobalPermissions: async function _loadGlobalPermissions() {
      try {
        const permissions = await this.getOwnerComponent().getRegistryService().getPermissions();
        this.getUiModel().setProperty("/canExecuteScanJob", permissions.includes("ScanJob.Execute"));
      } catch {
        this.getUiModel().setProperty("/canExecuteScanJob", false);
      }
    },
    onGlobalRouteMatched: async function _onGlobalRouteMatched(event) {
      const routeName = event.getParameter("name");
      if (routeName === "login") {
        return;
      }
      const session = this.getSessionModel().getData();
      if (!session?.authenticated) {
        return;
      }
      if (routeName.startsWith("registry") || routeName.startsWith("version") || routeName.startsWith("detailCompare")) {
        this.getUiModel().setProperty("/currentSection", "registries");
      } else if (routeName.startsWith("job")) {
        this.getUiModel().setProperty("/currentSection", "jobs");
      } else if (routeName === "home") {
        this.getUiModel().setProperty("/currentSection", "home");
      } else if (routeName === "logs") {
        this.getUiModel().setProperty("/currentSection", "logs");
      }
      if (!this.permissionsPromise) {
        this.permissionsPromise = this.loadGlobalPermissions();
      }
      await this.permissionsPromise;
      if (routeName.startsWith("job") && !this.getUiModel().getProperty("/canExecuteScanJob")) {
        this.getUiModel().setProperty("/currentSection", "home");
        this.navTo("home", {}, true);
      }
    },
    onNavigateHome: function _onNavigateHome() {
      this.getUiModel().setProperty("/currentSection", "home");
      this.navigateWhenReady("home");
    },
    onNavigateRegistries: function _onNavigateRegistries() {
      this.getUiModel().setProperty("/currentSection", "registries");
      this.navigateWhenReady("registryList");
    },
    onNavigateJobs: function _onNavigateJobs() {
      this.getUiModel().setProperty("/currentSection", "jobs");
      this.navigateWhenReady("jobList");
    },
    onNavigateLogs: function _onNavigateLogs() {
      this.getUiModel().setProperty("/currentSection", "logs");
      this.navigateWhenReady("logs");
    },
    onToggleTheme: function _onToggleTheme() {
      const nextIsDark = !this.getUiModel().getProperty("/isDarkTheme");
      const nextTheme = nextIsDark ? DARK_THEME : LIGHT_THEME;
      Theming.setTheme(nextTheme);
      writeThemePreference(nextTheme);
      this.getUiModel().setProperty("/isDarkTheme", nextIsDark);
    },
    onLogout: async function _onLogout() {
      const auth = this.getOwnerComponent().getAuthenticationService();
      await auth.logout();
      this.getSessionModel().setData({
        authenticated: false,
        userName: "",
        csrfToken: "",
        loginAt: null
      });
      this.permissionsPromise = null;
      this.getUiModel().setProperty("/canExecuteScanJob", false);
      this.navTo("login", {}, true);
    },
    navigateWhenReady: function _navigateWhenReady(route) {
      this.pendingRoute = route;
      this.flushPendingNavigation();
    },
    flushPendingNavigation: function _flushPendingNavigation() {
      if (!this.pendingRoute) {
        return;
      }
      if (!this.byId("shellFcl")) {
        console.log("shellFcl not found yet, waiting...");
        return;
      }
      const route = this.pendingRoute;
      this.pendingRoute = null;
      const fcl = this.byId("shellFcl");
      console.log("id:", fcl?.getId());
      console.log("class:", fcl?.getMetadata().getName());
      console.log("is FCL:", fcl?.isA("sap.f.FlexibleColumnLayout"));
      this.navTo(route, {}, true);
    },
    getCurrentHash: function _getCurrentHash() {
      return window.location.hash.replace(/^#/, "");
    }
  });
  return MainShell;
});
//# sourceMappingURL=MainShell-dbg.controller.js.map
