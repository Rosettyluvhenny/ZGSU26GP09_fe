sap.ui.define(["sap/ui/core/Theming", "./BaseController", "../services/ODataClient", "../services/SessionStorage"], function (Theming, __BaseController, __ODataClient, ___services_SessionStorage) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const BaseController = _interopRequireDefault(__BaseController);
  const ODataClient = _interopRequireDefault(__ODataClient);
  const readSideNavPreference = ___services_SessionStorage["readSideNavPreference"];
  const writeSideNavPreference = ___services_SessionStorage["writeSideNavPreference"];
  const writeThemePreference = ___services_SessionStorage["writeThemePreference"];
  const LIGHT_THEME = "sap_horizon";
  const DARK_THEME = "sap_horizon_dark";

  /**
   * @namespace com.zgp9.fe.controller
   */
  const MainShell = BaseController.extend("com.zgp9.fe.controller.MainShell", {
    constructor: function constructor() {
      BaseController.prototype.constructor.apply(this, arguments);
      this.pendingRoute = null;
    },
    onInit: function _onInit() {
      this.getRouter().attachRouteMatched(event => {
        void this.onGlobalRouteMatched(event);
      });
      this.getView().addEventDelegate({
        onAfterRendering: () => this.flushPendingNavigation()
      });
      const sideNavVisible = readSideNavPreference();
      this.getUiModel().setProperty("/sideNavVisible", sideNavVisible);
      this.applySideNavVisibility(sideNavVisible);

      // Load permissions once on page load — drives nav bar and button visibility
      void this.loadGlobalPermissions();
    },
    onToggleSideNav: function _onToggleSideNav() {
      const visible = !this.getUiModel().getProperty("/sideNavVisible");
      this.getUiModel().setProperty("/sideNavVisible", visible);
      this.applySideNavVisibility(visible);
      writeSideNavPreference(visible);
    },
    applySideNavVisibility: function _applySideNavVisibility(visible) {
      // sideExpanded=false alone leaves an icon-only rail; this class hides the
      // side area completely so the main content takes the full width (see style.css).
      this.byId("shellPage")?.toggleStyleClass("shellSideNavHidden", !visible);
    },
    loadGlobalPermissions: async function _loadGlobalPermissions() {
      try {
        const permissions = await this.getOwnerComponent().getRegistryService().getPermissions();
        const ui = this.getUiModel();
        ui.setProperty("/canExecuteScanJob", permissions.includes("ScanJob.Execute"));
        ui.setProperty("/canCreate", permissions.includes("Registry.Create"));
        ui.setProperty("/canUpdate", permissions.includes("Registry.Update"));
      } catch {
        const ui = this.getUiModel();
        ui.setProperty("/canExecuteScanJob", false);
        ui.setProperty("/canCreate", false);
        ui.setProperty("/canUpdate", false);
      } finally {
        this.getUiModel().setProperty("/permissionsLoaded", true);
      }
    },
    onGlobalRouteMatched: async function _onGlobalRouteMatched(event) {
      const routeName = event.getParameter("name");
      if (routeName.startsWith("registry") || routeName.startsWith("version") || routeName.startsWith("detailCompare")) {
        this.getUiModel().setProperty("/currentSection", "registries");
      } else if (routeName.startsWith("job")) {
        this.getUiModel().setProperty("/currentSection", "jobs");
      } else if (routeName === "home") {
        this.getUiModel().setProperty("/currentSection", "home");
      } else if (routeName === "logs") {
        this.getUiModel().setProperty("/currentSection", "logs");
      }

      // Guard: redirect away from job routes if user lacks permission
      if (routeName.startsWith("job") && !this.getUiModel().getProperty("/canExecuteScanJob")) {
        this.getUiModel().setProperty("/currentSection", "home");
        this.navTo("home", {}, true);
      }
    },
    onNavigateHome: function _onNavigateHome() {
      this.getUiModel().setProperty("/currentSection", "home");
      this.navigateWhenReady("home");
    },
    onNavigateRegistries: function _onNavigateRegistries() {
      this.getUiModel().setProperty("/currentSection", "registries");
      this.navigateWhenReady("registryList");
    },
    onNavigateJobs: function _onNavigateJobs() {
      this.getUiModel().setProperty("/currentSection", "jobs");
      this.navigateWhenReady("jobList");
    },
    onNavigateLogs: function _onNavigateLogs() {
      this.getUiModel().setProperty("/currentSection", "logs");
      this.navigateWhenReady("logs");
    },
    onToggleTheme: function _onToggleTheme() {
      const nextIsDark = !this.getUiModel().getProperty("/isDarkTheme");
      const nextTheme = nextIsDark ? DARK_THEME : LIGHT_THEME;
      Theming.setTheme(nextTheme);
      writeThemePreference(nextTheme);
      this.getUiModel().setProperty("/isDarkTheme", nextIsDark);
    },
    onLogout: async function _onLogout() {
      ODataClient.clearSecurityState();
      this.getSessionModel().setData({
        userName: "",
        csrfToken: "",
        loginAt: null
      });
      this.getUiModel().setProperty("/canExecuteScanJob", false);
      window.location.reload();
    },
    navigateWhenReady: function _navigateWhenReady(route) {
      this.pendingRoute = route;
      this.flushPendingNavigation();
    },
    flushPendingNavigation: function _flushPendingNavigation() {
      if (!this.pendingRoute) {
        return;
      }
      if (!this.byId("shellFcl")) {
        console.log("shellFcl not found yet, waiting...");
        return;
      }
      const route = this.pendingRoute;
      this.pendingRoute = null;
      const fcl = this.byId("shellFcl");
      console.log("id:", fcl?.getId());
      console.log("class:", fcl?.getMetadata().getName());
      console.log("is FCL:", fcl?.isA("sap.f.FlexibleColumnLayout"));
      this.navTo(route, {}, true);
    },
    getCurrentHash: function _getCurrentHash() {
      return window.location.hash.replace(/^#/, "");
    }
  });
  return MainShell;
});
//# sourceMappingURL=MainShell-dbg.controller.js.map
