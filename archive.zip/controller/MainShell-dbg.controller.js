sap.ui.define(["sap/ui/core/Core", "./BaseController", "../services/ODataClient", "../services/SessionStorage"], function (Core, __BaseController, __ODataClient, ___services_SessionStorage) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const BaseController = _interopRequireDefault(__BaseController);
  const ODataClient = _interopRequireDefault(__ODataClient);
  const readSideNavPreference = ___services_SessionStorage["readSideNavPreference"];
  const writeThemePreference = ___services_SessionStorage["writeThemePreference"];
  const LIGHT_THEME = "sap_horizon";
  const DARK_THEME = "sap_horizon_dark";

  /**
   * @namespace com.zgp9.fe.controller
   */
  const MainShell = BaseController.extend("com.zgp9.fe.controller.MainShell", {
    constructor: function constructor() {
      BaseController.prototype.constructor.apply(this, arguments);
      this.pendingRoute = null;
    },
    onInit: function _onInit() {
      this.getRouter().attachRouteMatched(event => {
        this.onGlobalRouteMatched(event);
      });
      this.getView().addEventDelegate({
        onAfterRendering: () => this.flushPendingNavigation()
      });

      // On phone-width screens the side navigation renders as a full-screen overlay,
      // so default it collapsed and let the user open it via the menu button — the
      // stored preference only drives the desktop/tablet experience.
      const isPhoneWidth = window.matchMedia("(max-width: 599px)").matches;
      const sideNavVisible = isPhoneWidth ? false : readSideNavPreference();
      this.getUiModel().setProperty("/sideNavVisible", sideNavVisible);
      this.applySideNavVisibility(sideNavVisible);

      // The toggle button lives in the routed pages' title bars now, so the press is
      // handled by whichever page controller is showing (BaseController.onToggleSideNav)
      // and never reaches this controller. Watch the model instead of a click, so the
      // shell's CSS class follows /sideNavVisible whoever wrote it.
      //
      // A standalone binding, not `attachPropertyChange`: on 1.108 JSONModel.setProperty
      // runs checkUpdate over the model's registered bindings but does **not** fire the
      // model-level propertyChange event, so the obvious-looking handler never runs. The
      // `addBinding` call is what registers this one — `bindProperty` alone does not.
      const sideNavBinding = this.getUiModel().bindProperty("/sideNavVisible");
      this.getUiModel().addBinding(sideNavBinding);
      sideNavBinding.attachChange(() => {
        this.applySideNavVisibility(sideNavBinding.getValue());
      });

      // Load permissions once on page load — drives nav bar and button visibility
      void this.loadGlobalPermissions();
    },
    applySideNavVisibility: function _applySideNavVisibility(visible) {
      // sideExpanded=false alone leaves an icon-only rail; this class hides the
      // side area completely so the main content takes the full width (see style.css).
      this.byId("shellPage")?.toggleStyleClass("shellSideNavHidden", !visible);
    },
    loadGlobalPermissions: async function _loadGlobalPermissions() {
      try {
        const permissions = await this.getOwnerComponent().getRegistryService().getPermissions();
        const ui = this.getUiModel();
        ui.setProperty("/canExecuteScanJob", permissions.includes("ScanJob.Execute"));
        ui.setProperty("/canCreate", permissions.includes("Registry.Create"));
        ui.setProperty("/canUpdate", permissions.includes("Registry.Update"));
      } catch {
        const ui = this.getUiModel();
        ui.setProperty("/canExecuteScanJob", false);
        ui.setProperty("/canCreate", false);
        ui.setProperty("/canUpdate", false);
      } finally {
        this.getUiModel().setProperty("/permissionsLoaded", true);
      }
    },
    onGlobalRouteMatched: function _onGlobalRouteMatched(event) {
      const routeName = event.getParameter("name");
      if (routeName.startsWith("registry") || routeName.startsWith("version") || routeName.startsWith("detailCompare")) {
        this.getUiModel().setProperty("/currentSection", "registries");
      } else if (routeName.startsWith("job")) {
        this.getUiModel().setProperty("/currentSection", "jobs");
      } else if (routeName === "home") {
        this.getUiModel().setProperty("/currentSection", "home");
      } else if (routeName === "logs") {
        this.getUiModel().setProperty("/currentSection", "logs");
      }

      // Guard: redirect away from job routes if user lacks permission
      if (routeName.startsWith("job") && !this.getUiModel().getProperty("/canExecuteScanJob")) {
        this.getUiModel().setProperty("/currentSection", "home");
        this.navTo("home", {}, true);
      }
    },
    onNavigateHome: function _onNavigateHome() {
      this.getUiModel().setProperty("/currentSection", "home");
      this.navigateWhenReady("home");
    },
    onNavigateRegistries: function _onNavigateRegistries() {
      this.getUiModel().setProperty("/currentSection", "registries");
      this.navigateWhenReady("registryList");
    },
    onNavigateJobs: function _onNavigateJobs() {
      this.getUiModel().setProperty("/currentSection", "jobs");
      this.navigateWhenReady("jobList");
    },
    onNavigateLogs: function _onNavigateLogs() {
      this.getUiModel().setProperty("/currentSection", "logs");
      this.navigateWhenReady("logs");
    },
    onToggleTheme: function _onToggleTheme() {
      const nextIsDark = !this.getUiModel().getProperty("/isDarkTheme");
      const nextTheme = nextIsDark ? DARK_THEME : LIGHT_THEME;
      // ui5lint-disable-next-line no-deprecated-api -- sap/ui/core/Theming does not exist on the launchpad's UI5 1.108.33
      Core.applyTheme(nextTheme);
      writeThemePreference(nextTheme);
      this.getUiModel().setProperty("/isDarkTheme", nextIsDark);
    },
    onLogout: function _onLogout() {
      ODataClient.clearSecurityState();
      this.getSessionModel().setData({
        userName: "",
        csrfToken: "",
        loginAt: null
      });
      this.getUiModel().setProperty("/canExecuteScanJob", false);
      this.redirectToLogout();
    },
    /**
     * Ends the session the way the standalone host expects.
     *
     * There is deliberately no launchpad branch here. Embedded, the FLP owns the session and
     * logout happens through the shell bar's avatar menu; the app's own Logout button — the
     * only caller of this method — is hidden when embedded (FLP_MIGRATION.md 3.3), so an
     * `isInLaunchpad()` branch was unreachable code and was deleted. See 3.4.
     *
     * Known gap, unchanged by that deletion: on the **ABAP standalone** URL "/logout" does not
     * exist — it is an approuter endpoint — so that host has been 404ing on logout all along.
     *
     * Standalone on BTP, "/logout" is the approuter's central logout endpoint: it clears the
     * approuter session cookie and the XSUAA session, then redirects to the configured
     * logoutPage. A plain reload cannot do this — the session cookie survives it, so the
     * approuter re-serves the app and the user appears stuck logged in.
     *
     * The live logoutPage is "/logout.html", from approuter/xs-app.json. Note the root
     * xs-app.json still says "/" — it is bundled into the app zip but is not what the
     * standalone approuter reads (FLP_MIGRATION.md deferred finding A). Locally
     * ui5-middleware-sap-proxy mirrors /logout as a redirect to /logout.html, so this branch
     * is exercisable with npm start.
     *
     * Isolated for unit tests so the QUnit page is not navigated under the runner.
     */
    redirectToLogout: function _redirectToLogout() {
      window.location.assign("/logout");
    },
    navigateWhenReady: function _navigateWhenReady(route) {
      // On phone the nav is a full-screen overlay; close it so it doesn't cover the
      // page the user just navigated to.
      // The onInit listener above turns this into the CSS class, so only the model is set.
      if (window.matchMedia("(max-width: 599px)").matches && this.getUiModel().getProperty("/sideNavVisible")) {
        this.getUiModel().setProperty("/sideNavVisible", false);
      }
      this.pendingRoute = route;
      this.flushPendingNavigation();
    },
    flushPendingNavigation: function _flushPendingNavigation() {
      if (!this.pendingRoute) {
        return;
      }
      if (!this.byId("shellFcl")) {
        return;
      }
      const route = this.pendingRoute;
      this.pendingRoute = null;
      this.navTo(route, {}, true);
    }
  });
  return MainShell;
});
//# sourceMappingURL=MainShell-dbg.controller.js.map
