sap.ui.define(["sap/ui/core/routing/History", "sap/ui/core/BusyIndicator", "sap/ui/model/json/JSONModel", "sap/m/MessageToast", "./BaseController", "../services/ODataParsers"], function (History, BusyIndicator, JSONModel, MessageToast, __BaseController, ___services_ODataParsers) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const BaseController = _interopRequireDefault(__BaseController);
  const mapRegistryEntity = ___services_ODataParsers["mapRegistryEntity"];
  /**
   * @namespace com.zgp9.fe.controller
   */
  const RegistryDetail = BaseController.extend("com.zgp9.fe.controller.RegistryDetail", {
    constructor: function constructor() {
      BaseController.prototype.constructor.apply(this, arguments);
      this.registryId = null;
    },
    onInit: function _onInit() {
      this.setModel(new JSONModel({
        busy: false,
        registry: null,
        versions: [],
        selectedVersionIds: [],
        selectionCountLabel: '0/2',
        canCompare: false,
        generateBusy: false
      }), 'registryDetail');
      this.getRouter().getRoute("registryDetail").attachPatternMatched(event => {
        void this.onRouteMatched(event);
      });
    },
    onRouteMatched: async function _onRouteMatched(event) {
      const args = event.getParameter('arguments');
      this.registryId = args.registryId ?? null;
      if (!this.registryId) {
        return;
      }
      await this.loadRegistry();
    },
    onNavBack: function _onNavBack() {
      // Prefer browser history so Logs → Registry Detail → Back returns to Logs
      // (not always Registry List). Deep links still fall back to the list.
      const previousHash = History.getInstance().getPreviousHash();
      if (previousHash !== undefined && previousHash !== '') {
        window.history.go(-1);
        return;
      }
      this.navTo('registryList', {}, true);
    },
    onRefresh: async function _onRefresh() {
      await this.loadRegistry();
    },
    onGenerateVersion: async function _onGenerateVersion() {
      if (!this.registryId) {
        return;
      }
      const model = this.getModel('registryDetail');
      const registry = model.getProperty('/registry');
      model.setProperty('/generateBusy', true);
      BusyIndicator.show(0);
      try {
        const response = await this.getOwnerComponent().getRegistryService().generateVersion(this.registryId, registry?.etag);
        MessageToast.show('Created successfully');
        if (response) {
          const responseRecord = response;
          // Remove @odata.etag before merging so we don't update it
          delete responseRecord['@odata.etag'];
          const mappedResponse = mapRegistryEntity(responseRecord);
          // Update registry with all information except etag (which was removed)
          const updatedRegistry = {
            ...registry
          };
          Object.keys(mappedResponse).forEach(key => {
            if (mappedResponse[key] !== undefined && mappedResponse[key] !== '') {
              // @ts-expect-error – dynamic key assignment across typed Registry fields
              updatedRegistry[key] = mappedResponse[key];
            }
          });
          model.setProperty('/registry', updatedRegistry);

          // We also need to reload just the versions list
          const versions = await this.getOwnerComponent().getVersionService().getVersions(this.registryId);
          model.setProperty('/versions', versions);
        } else {
          await this.loadRegistry();
        }
      } catch (error) {
        await this.handleServiceError(error);
      } finally {
        model.setProperty('/generateBusy', false);
        BusyIndicator.hide();
      }
    },
    onVersionSelectionChange: function _onVersionSelectionChange(event) {
      const table = event.getSource();
      const model = this.getModel('registryDetail');
      const selectedItems = table.getSelectedItems();
      if (selectedItems.length > 2) {
        const changedItem = event.getParameter('listItem');
        if (changedItem) {
          table.setSelectedItem(changedItem, false);
        }
      }
      const selectedVersionIds = table.getSelectedItems().slice(0, 2).map(item => {
        const context = item.getBindingContext('registryDetail');
        return context?.getObject()?.id ?? '';
      }).filter(Boolean);
      model.setProperty('/selectedVersionIds', selectedVersionIds);
      model.setProperty('/selectionCountLabel', `${selectedVersionIds.length}/2`);
      model.setProperty('/canCompare', selectedVersionIds.length === 2);
    },
    onComparePress: function _onComparePress() {
      if (!this.registryId) {
        return;
      }
      const model = this.getModel('registryDetail');
      const selectedVersionIds = model.getProperty('/selectedVersionIds') ?? [];
      if (selectedVersionIds.length !== 2) {
        return;
      }

      // Sort versions by createdAt ascending so that the OLDER version is always
      // on the LEFT (Base) and the NEWER version is on the RIGHT (Compare).
      // This follows the standard diff convention: left = before, right = after.
      const allVersions = model.getProperty('/versions') ?? [];
      const selected = selectedVersionIds.map(id => allVersions.find(v => v.id === id)).filter(v => !!v);
      selected.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
      this.navTo('versionCompare', {
        registryId: this.registryId,
        leftVersionId: selected[0]?.id ?? selectedVersionIds[0],
        // older → Base (left)
        rightVersionId: selected[1]?.id ?? selectedVersionIds[1] // newer → Compare (right)
      });
    },
    onVersionPress: function _onVersionPress(event) {
      const version = this.getVersionFromEvent(event);
      if (!version || !this.registryId) {
        return;
      }
      this.navTo('versionDetail', {
        registryId: this.registryId,
        versionId: version.id
      });
    },
    loadRegistry: async function _loadRegistry() {
      if (!this.registryId) {
        return;
      }
      const model = this.getModel('registryDetail');
      model.setProperty('/busy', true);
      BusyIndicator.show(0);
      try {
        const [registry, versions] = await Promise.all([this.getOwnerComponent().getRegistryService().getRegistry(this.registryId), this.getOwnerComponent().getVersionService().getVersions(this.registryId)]);
        model.setData({
          busy: false,
          registry,
          versions,
          selectedVersionIds: [],
          selectionCountLabel: '0/2',
          canCompare: false,
          generateBusy: false
        });
        // Clear table's internal selection state so checkboxes don't linger after back-navigation
        this.byId('versionsTable')?.removeSelections(true);
      } catch (error) {
        await this.handleServiceError(error);
      } finally {
        model.setProperty('/busy', false);
        BusyIndicator.hide();
      }
    },
    getVersionFromEvent: function _getVersionFromEvent(event) {
      const source = event.getSource();
      const context = source.getBindingContext('registryDetail');
      return context?.getObject() ?? null;
    }
  });
  return RegistryDetail;
});
//# sourceMappingURL=RegistryDetail-dbg.controller.js.map
