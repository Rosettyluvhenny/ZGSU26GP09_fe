sap.ui.define(["sap/ui/model/json/JSONModel", "sap/ui/core/routing/History", "./BaseController"], function (JSONModel, History, __BaseController) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const BaseController = _interopRequireDefault(__BaseController);
  /**
   * @namespace com.zgp9.fe.controller
   */
  const VersionCompare = BaseController.extend("com.zgp9.fe.controller.VersionCompare", {
    constructor: function constructor() {
      BaseController.prototype.constructor.apply(this, arguments);
      this.registryId = null;
      this.leftVersionId = null;
      this.rightVersionId = null;
    },
    onInit: function _onInit() {
      const model = new JSONModel({
        busy: false,
        result: null,
        change: [],
        differ: [],
        unchange: [],
        changeCount: 0,
        differCount: 0,
        unchangeCount: 0,
        baseDetail: null,
        compareDetail: null,
        baseTree: [],
        compareTree: [],
        baseXml: '',
        compareXml: '',
        baseLineStarts: [],
        compareLineStarts: [],
        selectedCompareEntry: null
      });
      // Growing tables are still capped by JSONModel sizeLimit (default 100).
      model.setSizeLimit(5000);
      this.setModel(model, 'versionCompare');
      this.getRouter().getRoute("versionCompare").attachPatternMatched(event => {
        void this.onRouteMatched(event);
      });
    },
    onRouteMatched: async function _onRouteMatched(event) {
      const args = event.getParameter('arguments');
      this.registryId = args.registryId ?? null;
      this.leftVersionId = args.leftVersionId ?? null;
      this.rightVersionId = args.rightVersionId ?? null;
      if (!this.registryId || !this.leftVersionId || !this.rightVersionId) {
        return;
      }
      await this.loadComparison();
    },
    onNavBack: function _onNavBack() {
      // Prefer browser history (same as RegistryDetail) so Back returns to the real
      // previous screen instead of replace-nav stacking VersionCompare in history.
      const previousHash = History.getInstance().getPreviousHash();
      if (previousHash !== undefined && previousHash !== '') {
        window.history.go(-1);
        return;
      }
      if (this.registryId) {
        this.navTo('registryDetail', {
          registryId: this.registryId
        }, true);
      } else {
        this.navTo('registryList', {}, true);
      }
    },
    onViewDetail: function _onViewDetail(event) {
      const entry = this.getCompareEntryFromEvent(event);
      if (!entry || !this.registryId || !this.leftVersionId || !this.rightVersionId) {
        return;
      }
      if (!this.isValidDetailId(entry.baseDetailId) || !this.isValidDetailId(entry.compareDetailId)) {
        return;
      }
      this.getRouter().navTo('detailCompare', {
        registryId: this.registryId,
        leftVersionId: this.leftVersionId,
        rightVersionId: this.rightVersionId,
        baseDetailId: entry.baseDetailId,
        compareDetailId: entry.compareDetailId
      });
    },
    onViewDifferentDetail: function _onViewDifferentDetail(event) {
      const entry = this.getCompareEntryFromEvent(event);
      if (!entry || !this.registryId) {
        return;
      }
      const isBaseValid = this.isValidDetailId(entry.baseDetailId);
      const validDetailId = isBaseValid ? entry.baseDetailId : entry.compareDetailId;
      const targetVersionId = isBaseValid ? this.leftVersionId : this.rightVersionId;
      if (!this.isValidDetailId(validDetailId) || !targetVersionId) {
        return;
      }
      this.getRouter().navTo('versionDetail', {
        registryId: this.registryId,
        versionId: targetVersionId,
        query: {
          detailId: validDetailId
        }
      });
    },
    // Tree selection and scrolling logic removed as it belongs to DetailCompare
    isValidDetailId: function _isValidDetailId(detailId) {
      if (!detailId || !detailId.trim()) {
        return false;
      }
      const normalized = detailId.replace(/[{}]/g, '').trim().toLowerCase();
      return normalized !== '00000000-0000-0000-0000-000000000000';
    },
    loadComparison: async function _loadComparison() {
      if (!this.registryId || !this.leftVersionId || !this.rightVersionId) {
        return;
      }
      const model = this.getModel('versionCompare');
      model.setProperty('/busy', true);
      try {
        const result = await this.getOwnerComponent().getVersionService().compareVersions(this.leftVersionId, this.rightVersionId);
        model.setProperty('/result', result);
        model.setProperty('/change', result.change);
        model.setProperty('/differ', result.differ);
        model.setProperty('/unchange', result.unchange);
        model.setProperty('/changeCount', result.change.length);
        model.setProperty('/differCount', result.differ.length);
        model.setProperty('/unchangeCount', result.unchange.length);
      } catch (error) {
        await this.handleServiceError(error);
      } finally {
        model.setProperty('/busy', false);
      }
    },
    getCompareEntryFromEvent: function _getCompareEntryFromEvent(event) {
      const source = event.getSource();
      const context = source.getBindingContext('versionCompare');
      return context?.getObject() ?? null;
    }
  });
  return VersionCompare;
});
//# sourceMappingURL=VersionCompare-dbg.controller.js.map
