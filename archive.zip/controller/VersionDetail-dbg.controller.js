sap.ui.define(["sap/ui/model/json/JSONModel", "sap/m/MessageToast", "./BaseController", "../services/XmlNodeUtils"], function (JSONModel, MessageToast, __BaseController, ___services_XmlNodeUtils) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const BaseController = _interopRequireDefault(__BaseController);
  const buildNodeTree = ___services_XmlNodeUtils["buildNodeTree"];
  const filterNodeTree = ___services_XmlNodeUtils["filterNodeTree"];
  const flattenNodeTree = ___services_XmlNodeUtils["flattenNodeTree"];
  const offsetToLine = ___services_XmlNodeUtils["offsetToLine"];
  const prettyPrintXml = ___services_XmlNodeUtils["prettyPrintXml"];
  /**
   * @namespace com.zgp9.fe.controller
   */
  const VersionDetail = BaseController.extend("com.zgp9.fe.controller.VersionDetail", {
    constructor: function constructor() {
      BaseController.prototype.constructor.apply(this, arguments);
      this.registryId = null;
      this.versionId = null;
      this.fullTree = [];
    },
    onInit: function _onInit() {
      this.setModel(new JSONModel({
        busy: false,
        version: null,
        details: [],
        selectedDetail: null,
        selectedDetailXml: '',
        selectedDetailBusy: false,
        selectedNodeLine: 1,
        selectedDetailLineStarts: [],
        selectedDetailLines: [],
        treeSearch: '',
        treeSearchMatchCount: 0
      }), 'versionDetail');
      this.setModel(new JSONModel([]), 'treeModel');
      this.getRouter().getRoute("versionDetail").attachPatternMatched(event => {
        void this.onRouteMatched(event);
      });
    },
    onRouteMatched: async function _onRouteMatched(event) {
      const args = event.getParameter('arguments');
      this.registryId = args.registryId ?? null;
      this.versionId = args.versionId ?? null;
      const queryDetailId = args['?query']?.detailId ?? null;
      if (!this.registryId || !this.versionId) {
        return;
      }
      await this.loadVersion(queryDetailId);
    },
    onRefresh: async function _onRefresh() {
      await this.loadVersion();
    },
    onDetailChange: async function _onDetailChange(event) {
      const source = event.getSource();
      const selectedItem = source.getSelectedItem();
      const context = selectedItem?.getBindingContext('versionDetail');
      const detail = context?.getObject();
      if (!detail) {
        return;
      }
      await this.loadDetailWorkspace(detail);
    },
    onNodeSelectionChange: function _onNodeSelectionChange(event) {
      const listItem = event.getParameter('listItem');
      const context = listItem?.getBindingContext('treeModel');
      const node = context?.getObject();
      if (!node) {
        return;
      }
      this.selectXmlLine(node.lineStart || offsetToLine(node.offsetStart, this.getModel('versionDetail').getProperty('/selectedDetailLineStarts')));
    },
    onTreeSearch: function _onTreeSearch(event) {
      const source = event.getSource();
      const query = (source.getValue() || '').trim().toLowerCase();
      const model = this.getModel('versionDetail');
      const treeModel = this.getModel('treeModel');
      if (!query) {
        model.setProperty('/treeSearchMatchCount', 0);
        treeModel.setData(this.fullTree);
        return;
      }
      const matchesQuery = node => node.nodeName.toLowerCase().includes(query) || node.nodeType.toLowerCase().includes(query);
      const filteredTree = filterNodeTree(this.fullTree, matchesQuery);
      const matchCount = flattenNodeTree(filteredTree).filter(matchesQuery).length;
      model.setProperty('/treeSearchMatchCount', matchCount);
      treeModel.setData(filteredTree);
      this.expandAllTreeNodes('versionDetailTree');
    },
    onCopyXml: async function _onCopyXml() {
      const model = this.getModel('versionDetail');
      const xml = model.getProperty('/selectedDetailXml');
      if (!xml) {
        MessageToast.show('No XML content to copy.');
        return;
      }
      const copied = await this.copyTextToClipboard(xml);
      MessageToast.show(copied ? 'XML copied to clipboard.' : 'Unable to copy XML.');
    },
    onDownloadXml: function _onDownloadXml() {
      const model = this.getModel('versionDetail');
      const xml = model.getProperty('/selectedDetailXml');
      if (!xml) {
        MessageToast.show('No XML content to download.');
        return;
      }
      const detail = model.getProperty('/selectedDetail');
      const baseName = (detail?.serviceDefinition || detail?.id || 'metadata').replace(/[^a-zA-Z0-9_.-]+/g, '_');
      this.downloadTextFile(`${baseName}.xml`, xml);
    },
    onXmlLineSelectionChange: function _onXmlLineSelectionChange(event) {
      const source = event.getSource();
      const selectedItem = source.getSelectedItem();
      const context = selectedItem?.getBindingContext('versionDetail');
      const line = context?.getObject();
      if (!line) {
        return;
      }
      const model = this.getModel('versionDetail');
      model.setProperty('/selectedNodeLine', line.lineNo);
    },
    loadVersion: async function _loadVersion(queryDetailId = null) {
      if (!this.registryId || !this.versionId) {
        return;
      }
      const model = this.getModel('versionDetail');
      model.setProperty('/busy', true);
      try {
        const [version, details] = await Promise.all([this.getOwnerComponent().getVersionService().getVersion(this.versionId), this.getOwnerComponent().getDetailService().getDetails(this.versionId)]);
        model.setData({
          busy: false,
          version,
          details,
          selectedDetail: null,
          selectedDetailXml: '',
          selectedDetailBusy: false,
          selectedNodeLine: 1,
          selectedDetailLineStarts: [],
          selectedDetailLines: [],
          treeSearch: '',
          treeSearchMatchCount: 0
        });
        this.fullTree = [];
        this.getModel('treeModel').setData([]);
        if (details.length > 0) {
          const detailToLoad = queryDetailId ? details.find(d => d.id === queryDetailId) || details[0] : details[0];
          await this.loadDetailWorkspace(detailToLoad);
        }
      } catch (error) {
        await this.handleServiceError(error);
      } finally {
        model.setProperty('/busy', false);
      }
    },
    loadDetailWorkspace: async function _loadDetailWorkspace(detail) {
      const model = this.getModel('versionDetail');
      model.setProperty('/selectedDetailBusy', true);
      model.setProperty('/selectedDetail', detail);
      model.setProperty('/selectedDetailXml', '');
      model.setProperty('/treeSearch', '');
      model.setProperty('/treeSearchMatchCount', 0);
      this.fullTree = [];
      this.getModel('treeModel').setData([]);
      model.setProperty('/selectedDetailLineStarts', []);
      model.setProperty('/selectedDetailLines', []);
      try {
        const [loadedDetail, parsedDetail, nodeTree] = await Promise.all([this.getOwnerComponent().getDetailService().getDetail(detail.id), this.getOwnerComponent().getDetailService().getParsedDetail(detail.id), this.getOwnerComponent().getDetailService().getNodeTree(detail.id)]);
        let rawXml = parsedDetail.metadataXml || loadedDetail.xml || '';
        // Filter out XML declaration because the backend offsets do not include it
        rawXml = rawXml.replace(/<\?xml[^>]*\?>\s*/gi, '');
        const {
          prettyXml,
          rawOffsets
        } = prettyPrintXml(rawXml);
        const tree = buildNodeTree(nodeTree);
        const root = tree.length > 0 ? tree : this.createFallbackNodeTree(loadedDetail);
        this.applyLineNumbers(root, rawOffsets, prettyXml);
        this.fullTree = root;
        model.setProperty('/selectedDetailXml', prettyXml);
        this.getModel('treeModel').setData(root);
        model.setProperty('/selectedDetailLineStarts', rawOffsets);
        model.setProperty('/selectedDetailLines', this.buildXmlLines(prettyXml));
        model.setProperty('/selectedNodeLine', 1);
        this.selectXmlLine(1);
      } catch (error) {
        await this.handleServiceError(error);
      } finally {
        model.setProperty('/selectedDetailBusy', false);
      }
    },
    expandAllTreeNodes: function _expandAllTreeNodes(treeId) {
      const tree = this.byId(treeId);
      if (!tree) {
        return;
      }
      tree.attachEventOnce('updateFinished', () => {
        const binding = tree.getBinding('items');
        if (!binding || typeof binding.expand !== 'function') {
          return;
        }
        let index = 0;
        let iterations = 0;
        while (index < binding.getLength() && iterations < 100000) {
          iterations += 1;
          if (typeof binding.isExpanded === 'function' && !binding.isExpanded(index)) {
            binding.expand(index);
          }
          index += 1;
        }
      });
    },
    copyTextToClipboard: async function _copyTextToClipboard(text) {
      if (navigator.clipboard && window.isSecureContext) {
        try {
          await navigator.clipboard.writeText(text);
          return true;
        } catch {
          // fall through to the legacy fallback below
        }
      }
      try {
        const textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.focus();
        textarea.select();
        const success = document.execCommand('copy');
        document.body.removeChild(textarea);
        return success;
      } catch {
        return false;
      }
    },
    downloadTextFile: function _downloadTextFile(fileName, content) {
      const blob = new Blob([content], {
        type: 'application/xml'
      });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    },
    createFallbackNodeTree: function _createFallbackNodeTree(detail) {
      return buildNodeTree([{
        nodeId: detail.id,
        semanticId: detail.serviceDefinition || detail.id,
        parentId: '',
        nodePath: '1',
        nodeType: 'Detail',
        nodeName: detail.serviceDefinition || 'Detail',
        nodeAlias: '',
        offsetStart: 0,
        offsetEnd: detail.xml.length,
        seq: 1,
        depth: 0,
        attributes: []
      }]);
    },
    applyLineNumbers: function _applyLineNumbers(nodes, lineStarts, xml) {
      for (const node of nodes) {
        node.lineStart = offsetToLine(node.offsetStart, lineStarts);
        node.lineEnd = offsetToLine(node.offsetEnd, lineStarts);
        if (node.lineStart <= 1 && xml.length > 0) {
          node.lineStart = 1;
        }
        if (node.children.length > 0) {
          this.applyLineNumbers(node.children, lineStarts, xml);
        }
      }
    },
    buildXmlLines: function _buildXmlLines(xml) {
      return xml.split('\n').map((text, index) => ({
        lineNo: index + 1,
        text,
        isWhitespace: text.trim().length === 0
      }));
    },
    selectXmlLine: function _selectXmlLine(lineNo) {
      const model = this.getModel('versionDetail');
      model.setProperty('/selectedNodeLine', lineNo);
      const table = this.byId('selectedDetailXmlTable');
      if (!table) {
        return;
      }
      const triggerGrowToLine = () => {
        const growingTable = table;
        const growingInfo = growingTable.getGrowingInfo?.();
        const currentActual = growingInfo?.actual || 0;
        if (lineNo > currentActual) {
          const delegate = growingTable._oGrowingDelegate;
          if (delegate && typeof delegate.requestNewPage === 'function') {
            const onUpdateFinished = () => {
              table.detachEvent('updateFinished', onUpdateFinished);
              triggerGrowToLine();
            };
            table.attachEvent('updateFinished', onUpdateFinished);
            delegate.requestNewPage();
            return;
          }
        }

        // Item should be rendered now, give it a tiny bit of time for DOM layout
        setTimeout(() => {
          this.scrollToItem(table, lineNo);
        }, 100);
      };
      triggerGrowToLine();
    },
    // private scrollXmlToLine(line: number): void {
    // 	this.selectXmlLine(line);
    // }
    scrollToItem: function _scrollToItem(table, lineNo) {
      // Clear previous highlights
      table.getItems().forEach(item => {
        item.removeStyleClass('versionDetailXmlHighlighted');
      });
      const item = table.getItems().find(listItem => {
        const context = listItem.getBindingContext('versionDetail');
        return context?.getObject()?.lineNo === lineNo;
      });
      if (item) {
        item.addStyleClass('versionDetailXmlHighlighted');
        item.getDomRef()?.scrollIntoView({
          block: 'center',
          inline: 'nearest'
        });
      }
    }
  });
  return VersionDetail;
});
//# sourceMappingURL=VersionDetail-dbg.controller.js.map
