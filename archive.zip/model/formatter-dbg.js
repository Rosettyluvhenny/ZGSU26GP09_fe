sap.ui.define([], function () {
  "use strict";

  var __exports = {
    formatUpperCase: value => {
      return value?.toUpperCase() ?? '';
    },
    formatDateTime: value => {
      if (!value) {
        return '';
      }
      return new Intl.DateTimeFormat('en', {
        dateStyle: 'medium',
        timeStyle: 'short'
      }).format(new Date(value));
    },
    formatDuration: durationMs => {
      if (durationMs === null || durationMs === undefined) {
        return '';
      }
      const totalSeconds = Math.max(0, Math.round(durationMs / 1000));
      const minutes = Math.floor(totalSeconds / 60);
      const seconds = totalSeconds % 60;
      return `${minutes}m ${seconds}s`;
    },
    formatRegistryStatus: status => {
      return status ?? '';
    },
    formatJobStatus: status => {
      return status ?? '';
    },
    formatStatusState: status => {
      switch (status) {
        case 'Published':
        case 'Completed':
          return 'Success';
        case 'Unpublished':
        case 'Queued':
          return 'Warning';
        case 'Archive':
          return 'None';
        case 'Failed':
          return 'Error';
        case 'Running':
          return 'Information';
        default:
          return 'None';
      }
    },
    formatXml: value => {
      return value ?? '';
    }
  };
  return __exports;
});
//# sourceMappingURL=formatter-dbg.js.map
