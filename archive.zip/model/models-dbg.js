sap.ui.define(["sap/ui/Device", "sap/ui/model/BindingMode", "sap/ui/model/json/JSONModel", "../services/Launchpad", "../services/SessionStorage"], function (Device, BindingMode, JSONModel, ___services_Launchpad, ___services_SessionStorage) {
  "use strict";

  const isInLaunchpad = ___services_Launchpad["isInLaunchpad"];
  const readSessionStorage = ___services_SessionStorage["readSessionStorage"];
  const readThemePreference = ___services_SessionStorage["readThemePreference"];
  const EMPTY_SESSION = {
    authenticated: false,
    userName: '',
    csrfToken: '',
    loginAt: null
  };
  var __exports = {
    createDeviceModel: () => {
      const model = new JSONModel(Device);
      model.setDefaultBindingMode(BindingMode.OneWay);
      return model;
    },
    createSessionModel: () => {
      return new JSONModel(readSessionStorage(EMPTY_SESSION));
    },
    createUiModel: () => {
      const model = new JSONModel({
        busy: false,
        layout: 'OneColumn',
        currentSection: 'home',
        selectedRegistryId: '',
        selectedJobId: '',
        loginBusy: false,
        searchRegistry: '',
        searchJob: '',
        selectedRegistryStatus: 'All',
        isDarkTheme: (readThemePreference() ?? 'sap_horizon').includes('dark'),
        sideNavVisible: true,
        isPhoneWidth: window.matchMedia('(max-width: 599px)').matches,
        isNarrowWidth: window.matchMedia('(max-width: 1023px)').matches,
        canExecuteScanJob: false,
        canCreate: false,
        canUpdate: false,
        permissionsLoaded: false,
        // Whether the app is embedded in a Fiori Launchpad. Read once here rather than
        // per view: the shell bootstraps before the app Component, so this cannot change
        // during the session, and a model flag keeps the views free of sap.ushell checks.
        // Drives the shell header (MainShell.view.xml) — see FLP_MIGRATION.md 3.3.
        isInLaunchpad: isInLaunchpad()
      });
      model.setDefaultBindingMode(BindingMode.TwoWay);
      return model;
    }
  };
  return __exports;
});
//# sourceMappingURL=models-dbg.js.map
