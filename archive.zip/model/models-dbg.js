sap.ui.define(["sap/ui/Device", "sap/ui/model/BindingMode", "sap/ui/model/json/JSONModel", "../services/SessionStorage"], function (Device, BindingMode, JSONModel, ___services_SessionStorage) {
  "use strict";

  const readSessionStorage = ___services_SessionStorage["readSessionStorage"];
  const readThemePreference = ___services_SessionStorage["readThemePreference"];
  const EMPTY_SESSION = {
    authenticated: false,
    userName: '',
    csrfToken: '',
    loginAt: null
  };
  var __exports = {
    createDeviceModel: () => {
      const model = new JSONModel(Device);
      model.setDefaultBindingMode(BindingMode.OneWay);
      return model;
    },
    createSessionModel: () => {
      return new JSONModel(readSessionStorage(EMPTY_SESSION));
    },
    createUiModel: () => {
      const model = new JSONModel({
        busy: false,
        layout: 'OneColumn',
        currentSection: 'home',
        selectedRegistryId: '',
        selectedJobId: '',
        loginBusy: false,
        searchRegistry: '',
        searchJob: '',
        selectedRegistryStatus: 'All',
        isDarkTheme: (readThemePreference() ?? 'sap_horizon').includes('dark'),
        sideNavVisible: true,
        canExecuteScanJob: false,
        canCreate: false,
        canUpdate: false,
        permissionsLoaded: false
      });
      model.setDefaultBindingMode(BindingMode.TwoWay);
      return model;
    }
  };
  return __exports;
});
//# sourceMappingURL=models-dbg.js.map
