sap.ui.define([], function () {
  "use strict";

  // Git-ignored — this file never leaves your machine (see .gitignore).
  // It IS included in `npm run build` / `npm run deploy`, so the deployed app has the keys.
  // Teammates: copy AiKey.example.ts to AiKey.ts and paste your own keys.
  // Groq: https://console.groq.com  |  OpenRouter: https://openrouter.ai/keys
  const GROQ_API_KEY = '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';
  const OPENROUTER_API_KEY = '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';
  var __exports = {
    __esModule: true
  };
  __exports.GROQ_API_KEY = GROQ_API_KEY;
  __exports.OPENROUTER_API_KEY = OPENROUTER_API_KEY;
  return __exports;
});
//# sourceMappingURL=AiKey-dbg.js.map
