sap.ui.define([], function () {
  "use strict";

  // Template for the git-ignored AiKey.ts.
  // Copy this file to AiKey.ts (same folder) and paste your key from https://openrouter.ai/keys
  const OPENROUTER_API_KEY = '';
  var __exports = {
    __esModule: true
  };
  __exports.OPENROUTER_API_KEY = OPENROUTER_API_KEY;
  return __exports;
});
//# sourceMappingURL=AiKey.example-dbg.js.map
