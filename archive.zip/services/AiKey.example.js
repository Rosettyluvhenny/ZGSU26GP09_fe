sap.ui.define([],function(){"use strict";const e="";var t={__esModule:true};t.OPENROUTER_API_KEY=e;return t});
//# sourceMappingURL=AiKey.example.js.map