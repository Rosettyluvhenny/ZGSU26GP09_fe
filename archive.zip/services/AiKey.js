sap.ui.define([],function(){"use strict";const e="";const t="";var n={__esModule:true};n.GROQ_API_KEY=e;n.OPENROUTER_API_KEY=t;return n});
//# sourceMappingURL=AiKey.js.map