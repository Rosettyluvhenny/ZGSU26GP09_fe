sap.ui.define(["./ServiceError", "./SessionStorage", "./ODataClient"], function (__ServiceError, ___SessionStorage, __ODataClient) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const ServiceError = _interopRequireDefault(__ServiceError);
  const readSessionStorage = ___SessionStorage["readSessionStorage"];
  const removeSessionStorage = ___SessionStorage["removeSessionStorage"];
  const writeSessionStorage = ___SessionStorage["writeSessionStorage"];
  const ODataClient = _interopRequireDefault(__ODataClient);
  const EMPTY_SESSION = {
    authenticated: false,
    userName: '',
    csrfToken: '',
    loginAt: null
  };
  const PROXY_LOGOFF_URL = '/sap/public/bc/icf/logoff?sap-client=324';
  function delay(value, ms = 250) {
    return new Promise(resolve => {
      setTimeout(() => resolve(value), ms);
    });
  }
  function clearBrowserCookies() {
    if (typeof document === 'undefined') {
      return;
    }
    const names = document.cookie.split(';').map(cookie => cookie.split('=')[0]?.trim()).filter(name => Boolean(name));
    const currentPath = window.location.pathname || '/';
    for (const name of names) {
      const encodedName = encodeURIComponent(name);
      const expires = 'Thu, 01 Jan 1970 00:00:00 GMT';
      document.cookie = `${encodedName}=; expires=${expires}; path=/`;
      document.cookie = `${encodedName}=; expires=${expires}; path=${currentPath}`;
    }
  }
  class AuthenticationService {
    async getSession() {
      return delay(readSessionStorage(EMPTY_SESSION), 50);
    }
    async login(userName, password) {
      if (!userName || !password) {
        throw new ServiceError(401, 'Username and password are required.');
      }
      const authorization = `Basic ${btoa(`${userName.trim()}:${password}`)}`;
      const response = await fetch('/sap/opu/odata4/sap/zsb_gsugp9/srvd_a2x/sap/zsr_registry/0001', {
        method: 'GET',
        headers: {
          Authorization: authorization
        }
        // ,
        // body: JSON.stringify({
        // 	userName: userName.trim()
        // })
      });
      if (!response.ok) {
        throw new ServiceError(401, 'Invalid username or password.');
      }
      const payload = await response.json();
      const session = {
        authenticated: Boolean(payload.authenticated),
        userName: payload.userName || userName.trim(),
        csrfToken: payload.csrfToken || '',
        loginAt: new Date().toISOString()
      };
      writeSessionStorage(session);
      if (payload.csrfToken) {
        ODataClient.setSecurityState(payload.csrfToken, payload.eTag);
      }
      return delay(session);
    }
    async fetchCsrfToken() {
      const session = readSessionStorage(EMPTY_SESSION);
      if (!session.authenticated) {
        throw new ServiceError(401, 'Session expired.');
      }
      return ODataClient.checkAuthAndFetchCsrf();
    }
    async logout() {
      try {
        await fetch(PROXY_LOGOFF_URL, {
          method: 'GET',
          credentials: 'include',
          redirect: 'manual',
          cache: 'no-store',
          headers: {
            Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
          }
        });
      } catch {
        // Ignore redirect/network failures and finish local cleanup.
      }
      ODataClient.clearSecurityState();
      removeSessionStorage();
      clearBrowserCookies();
      await delay(undefined, 50);
    }
  }
  return AuthenticationService;
});
//# sourceMappingURL=AuthenticationService-dbg.js.map
