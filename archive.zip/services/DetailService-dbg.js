sap.ui.define(["./ODataClient", "./ServiceError", "./ODataParsers"], function (__ODataClient, __ServiceError, ___ODataParsers) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const ODataClient = _interopRequireDefault(__ODataClient);
  const ServiceError = _interopRequireDefault(__ServiceError);
  const mapDetailEntity = ___ODataParsers["mapDetailEntity"];
  const normalizeODataCollection = ___ODataParsers["normalizeODataCollection"];
  const normalizeODataEntity = ___ODataParsers["normalizeODataEntity"];
  function delay(value, ms = 250) {
    return new Promise(resolve => {
      setTimeout(() => resolve(value), ms);
    });
  }
  function normalizeGuid(value) {
    return value.replace(/[{}]/g, '').trim();
  }
  function formatGuidLiteral(value) {
    return normalizeGuid(value);
  }
  function asString(value) {
    if (value === null || value === undefined) {
      return '';
    }
    const primitive = value;
    return String(primitive);
  }
  function asNumber(value) {
    const numeric = Number(value);
    return Number.isFinite(numeric) ? numeric : 0;
  }
  function mapNodeTreeItem(item) {
    return {
      nodeId: asString(item.NODE_ID),
      semanticId: asString(item.SEMANTIC_ID),
      parentId: asString(item.PARENT_ID),
      nodePath: asString(item.NODE_PATH),
      nodeType: asString(item.NODE_TYPE),
      nodeName: asString(item.NODE_NAME),
      nodeAlias: asString(item.NODE_ALIAS),
      offsetStart: asNumber(item.OFFSET_START),
      offsetEnd: asNumber(item.OFFSET_END),
      seq: asNumber(item.SEQ),
      depth: asNumber(item.DEPTH),
      attributes: Array.isArray(item.ATTRIBUTES) ? item.ATTRIBUTES.map(attribute => ({
        name: asString(attribute.NAME),
        value: asString(attribute.VALUE)
      })) : []
    };
  }
  function mapNodeDiffItem(item) {
    return {
      SEMANTIC_ID: asString(item.SEMANTIC_ID),
      STATUS: asString(item.STATUS),
      ATTRIBUTEDIFF: Array.isArray(item.ATTRIBUTEDIFF) ? item.ATTRIBUTEDIFF.map(attribute => ({
        SEMANTIC_ID: asString(attribute.SEMANTIC_ID),
        NAME: asString(attribute.NAME),
        STATUS: asString(attribute.STATUS),
        OLD_VALUE: asString(attribute.OLD_VALUE),
        NEW_VALUE: asString(attribute.NEW_VALUE)
      })) : []
    };
  }
  class DetailService {
    client = new ODataClient();
    async getDetails(versionId) {
      const backendDetails = await this.loadDetailsFromBackend(versionId);
      return delay(backendDetails);
    }
    async getDetail(detailId) {
      const backendDetail = await this.loadDetailFromBackend(detailId);
      if (!backendDetail) {
        throw new ServiceError(404, 'Detail not found.');
      }
      return delay(backendDetail);
    }
    async getParsedDetail(detailId) {
      const parsedDetail = await this.loadParsedMetadataFromBackend(detailId);
      if (parsedDetail) {
        return delay(parsedDetail);
      }
      const detail = await this.getDetail(detailId);
      return delay({
        detailId: detail.id,
        metadataXml: detail.xml
      });
    }
    async getNodeTree(detailId) {
      const payload = normalizeODataEntity(await this.client.postJson(`/Detail/com.sap.gateway.srvd_a2x.zsr_registry.v0001.getNodeTree`, {
        DetailId: detailId
      }, {
        headers: await this.client.ensureWriteHeaders('POST')
      }));
      if (Array.isArray(payload.NODETREE)) {
        return delay(payload.NODETREE.map(mapNodeTreeItem));
      }
      return delay([]);
    }
    async compareNodeTree(baseDetailId, compareDetailId) {
      const payload = normalizeODataEntity(await this.client.postJson('/Detail/com.sap.gateway.srvd_a2x.zsr_registry.v0001.compareNodeTree', {
        base_detail_id: baseDetailId,
        compare_detail_id: compareDetailId
      }, {
        headers: await this.client.ensureWriteHeaders('POST')
      }));
      if (Array.isArray(payload.NODEDIFF)) {
        return delay(payload.NODEDIFF.map(mapNodeDiffItem));
      }
      return delay([]);
    }
    async loadDetailsFromBackend(versionId) {
      const payload = await this.client.readJson(`/Version(VersionId=${formatGuidLiteral(versionId)})/_Detail`);
      return normalizeODataCollection(payload).map(entity => mapDetailEntity(entity));
    }
    async loadDetailFromBackend(detailId) {
      const payload = await this.client.readJson(`/Detail/${formatGuidLiteral(detailId)}`);
      const entity = normalizeODataEntity(payload);
      if (!Object.keys(entity).length) {
        return null;
      }
      return mapDetailEntity(entity);
    }
    async loadParsedMetadataFromBackend(detailId) {
      const payload = await this.client.postJson(`/Detail/com.sap.gateway.srvd_a2x.zsr_registry.v0001.getParseMetadata`, {
        DetailId: detailId
      }, {
        headers: await this.client.ensureWriteHeaders('POST')
      });
      const entity = normalizeODataEntity(payload);
      if (!Object.keys(entity).length) {
        return null;
      }
      return {
        detailId: asString(entity.DetailId) || detailId,
        metadataXml: asString(entity.MetadataXml) || asString(entity.metadataXml)
      };
    }
    async sendEmail(params) {
      const raw = await this.client.postJson('/Detail/com.sap.gateway.srvd_a2x.zsr_registry.v0001.sendEmail', {
        HtmlContent: params.htmlContent,
        Recipients: params.recipients,
        Subject: params.subject
      }, {
        headers: await this.client.ensureWriteHeaders('POST')
      });
      const entity = normalizeODataEntity(raw);
      return {
        success: entity.success === true || entity.success === 'true',
        message: asString(entity.message),
        failedRecip: asString(entity.failed_recip),
        recipientDetail: asString(entity.recipient_detail)
      };
    }
    async compareDetail(baseDetailId, compareDetailId) {
      const payload = await this.client.postJson(`Detail/com.sap.gateway.srvd_a2x.zsr_registry.v0001.compareNodeTree`, {
        base_detail_id: baseDetailId,
        compare_detail_id: compareDetailId
      }, {
        headers: await this.client.ensureWriteHeaders('POST')
      });
      const entity = normalizeODataEntity(payload);
      if (!Object.keys(entity).length || !Array.isArray(entity.NODEDIFF)) {
        return null;
      }
      return entity.NODEDIFF.map(mapNodeDiffItem);
    }
  }
  return DetailService;
});
//# sourceMappingURL=DetailService-dbg.js.map
