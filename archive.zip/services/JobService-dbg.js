sap.ui.define(["./ODataClient", "./ServiceError", "./ODataParsers"], function (__ODataClient, __ServiceError, ___ODataParsers) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const ODataClient = _interopRequireDefault(__ODataClient);
  const ServiceError = _interopRequireDefault(__ServiceError);
  const mapJobEntity = ___ODataParsers["mapJobEntity"];
  const normalizeODataCollection = ___ODataParsers["normalizeODataCollection"];
  const normalizeODataEntity = ___ODataParsers["normalizeODataEntity"];
  function delay(value, ms = 250) {
    return new Promise(resolve => {
      setTimeout(() => resolve(value), ms);
    });
  }
  class JobService {
    client = new ODataClient();
    async getJobs(search = '') {
      const backendJobs = await this.loadJobsFromBackend();
      return delay(this.filterJobs(backendJobs, search));
    }
    async getJob(jobId) {
      const backendJob = await this.loadJobFromBackend(jobId);
      if (!backendJob) {
        throw new ServiceError(404, 'Job not found.');
      }
      return delay(backendJob);
    }
    async runScanJob() {
      const headers = await this.client.ensureWriteHeaders('POST');
      const payload = await this.client.postJson('/ScanJob/com.sap.gateway.srvd_a2x.zsr_registry.v0001.runScan', undefined, {
        headers
      });
      const entity = normalizeODataEntity(payload);
      if (!Object.keys(entity).length) {
        throw new ServiceError(500, 'Invalid response from runScan action.');
      }
      return delay(mapJobEntity(entity));
    }
    filterJobs(jobs, search) {
      const normalized = search.trim().toLowerCase();
      const filtered = jobs.filter(job => {
        if (!normalized) {
          return true;
        }
        return [job.id, job.triggerType, job.status, job.executedBy, job.summary].join(' ').toLowerCase().includes(normalized);
      });
      return filtered;
    }
    async loadJobsFromBackend() {
      const payload = await this.client.readJson('/ScanJob?$orderby=StartedAt desc');
      return normalizeODataCollection(payload).map(entity => mapJobEntity(entity));
    }
    async loadJobFromBackend(jobId) {
      const payload = await this.client.readJson(`/ScanJob(${jobId})`);
      const entity = normalizeODataEntity(payload);
      if (!Object.keys(entity).length) {
        return null;
      }
      return mapJobEntity(entity);
    }
  }
  return JobService;
});
//# sourceMappingURL=JobService-dbg.js.map
