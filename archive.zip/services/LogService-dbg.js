sap.ui.define(["./ODataClient", "./ODataParsers"], function (__ODataClient, ___ODataParsers) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const ODataClient = _interopRequireDefault(__ODataClient);
  const mapLogEntity = ___ODataParsers["mapLogEntity"];
  const normalizeODataCollection = ___ODataParsers["normalizeODataCollection"];
  const LOG_PAGE_SIZE = 50;
  function delay(value, ms = 250) {
    return new Promise(resolve => {
      setTimeout(() => resolve(value), ms);
    });
  }
  function escapeODataString(value) {
    return value.replace(/'/g, "''");
  }
  function toODataDateTime(date) {
    return date.toISOString().replace(/\.\d{3}Z$/, 'Z');
  }
  function readODataCount(payload, fallback) {
    if (!payload || typeof payload !== 'object') {
      return fallback;
    }
    const record = payload;
    const raw = record['@odata.count'] ?? record['odata.count'] ?? record['__count'];
    const numeric = Number(raw);
    return Number.isFinite(numeric) ? numeric : fallback;
  }
  class LogService {
    client = new ODataClient();
    async getLogs(filter = {}) {
      const top = filter.top ?? LOG_PAGE_SIZE;
      const skip = filter.skip ?? 0;
      const payload = await this.client.readJson(this.buildLogUrl({
        ...filter,
        top,
        skip
      }));
      const items = normalizeODataCollection(payload).map(entity => mapLogEntity(entity));
      const totalCount = readODataCount(payload, skip + items.length);
      return delay({
        items,
        totalCount,
        hasMore: skip + items.length < totalCount && items.length > 0
      });
    }

    /** @deprecated Use getLogs({ jobId }) instead */
    async getLogsByJobId(jobId) {
      return this.getLogs({
        jobId
      });
    }
    buildLogUrl(filter) {
      const parts = [];
      if (filter.jobId) {
        const normalized = filter.jobId.replace(/[{}]/g, '').trim();
        parts.push(`JobId eq ${normalized}`);
      }
      if (filter.actionType && filter.actionType !== 'All') {
        parts.push(`ActionType eq '${escapeODataString(filter.actionType)}'`);
      }
      if (filter.logResult && filter.logResult !== 'All') {
        parts.push(`LogResult eq '${escapeODataString(filter.logResult)}'`);
      }
      if (filter.objectIdType && filter.objectIdType !== 'All') {
        parts.push(`objectIdType eq '${escapeODataString(filter.objectIdType)}'`);
      }
      if (filter.dateFrom) {
        const from = new Date(filter.dateFrom);
        from.setHours(0, 0, 0, 0);
        parts.push(`ActionAt ge ${toODataDateTime(from)}`);
      }
      if (filter.dateTo) {
        const to = new Date(filter.dateTo);
        to.setHours(23, 59, 59, 999);
        parts.push(`ActionAt le ${toODataDateTime(to)}`);
      }
      if (filter.search?.trim()) {
        const raw = filter.search.trim();
        const normalizedGuid = raw.replace(/[{}]/g, '');
        const looksLikeGuid = /^[0-9a-fA-F]{8}-?[0-9a-fA-F]{4}-?[0-9a-fA-F]{4}-?[0-9a-fA-F]{4}-?[0-9a-fA-F]{12}$/.test(normalizedGuid);
        const objectTypeTerm = raw.toUpperCase();
        const knownObjectTypes = ['REGISTRY', 'DETAIL', 'VERSION', 'SCANJOB'];
        if (looksLikeGuid) {
          parts.push(`ObjectId eq ${normalizedGuid}`);
        } else if (knownObjectTypes.includes(objectTypeTerm)) {
          // Avoid duplicating objectIdType filter when the dropdown already selected the same value.
          if (!filter.objectIdType || filter.objectIdType === 'All' || filter.objectIdType.toUpperCase() !== objectTypeTerm) {
            parts.push(`objectIdType eq '${escapeODataString(objectTypeTerm)}'`);
          }
        } else {
          const term = escapeODataString(raw);
          parts.push(`(contains(Remarks,'${term}') or contains(Actor,'${term}'))`);
        }
      }
      const query = [];
      if (parts.length > 0) {
        query.push(`$filter=${encodeURIComponent(parts.join(' and '))}`);
      }
      query.push('$orderby=ActionAt desc');
      query.push(`$top=${filter.top ?? LOG_PAGE_SIZE}`);
      query.push(`$skip=${filter.skip ?? 0}`);
      query.push('$count=true');
      return `/Log?${query.join('&')}`;
    }
  }
  LogService.LOG_PAGE_SIZE = LOG_PAGE_SIZE;
  return LogService;
});
//# sourceMappingURL=LogService-dbg.js.map
