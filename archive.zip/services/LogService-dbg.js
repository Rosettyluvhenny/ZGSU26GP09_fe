sap.ui.define(["./ODataClient", "./ODataParsers"], function (__ODataClient, ___ODataParsers) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const ODataClient = _interopRequireDefault(__ODataClient);
  const mapLogEntity = ___ODataParsers["mapLogEntity"];
  const normalizeODataCollection = ___ODataParsers["normalizeODataCollection"];
  function delay(value, ms = 250) {
    return new Promise(resolve => {
      setTimeout(() => resolve(value), ms);
    });
  }
  class LogService {
    client = new ODataClient();
    async getLogs(search = '') {
      const backendLogs = await this.loadLogsFromBackend();
      return delay(this.filterLogs(backendLogs, search));
    }
    filterLogs(logs, search) {
      const normalized = search.trim().toLowerCase();
      if (!normalized) {
        return logs;
      }
      return logs.filter(log => [log.id, log.actionType, log.actor, log.remarks, log.logResult, log.objectIdType, log.ipAddress].join(' ').toLowerCase().includes(normalized));
    }
    async loadLogsFromBackend() {
      const payload = await this.client.readJson('/Log?$orderby=ActionAt desc');
      return normalizeODataCollection(payload).map(entity => mapLogEntity(entity));
    }
  }
  return LogService;
});
//# sourceMappingURL=LogService-dbg.js.map
