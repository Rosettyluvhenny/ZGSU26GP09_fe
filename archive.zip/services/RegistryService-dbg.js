sap.ui.define(["./ODataClient", "./ServiceError", "./ODataParsers"], function (__ODataClient, __ServiceError, ___ODataParsers) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const ODataClient = _interopRequireDefault(__ODataClient);
  const SERVICE_ORIGIN = __ODataClient["SERVICE_ORIGIN"];
  const ServiceError = _interopRequireDefault(__ServiceError);
  const mapRegistryEntity = ___ODataParsers["mapRegistryEntity"];
  const normalizeODataCollection = ___ODataParsers["normalizeODataCollection"];
  const normalizeODataEntity = ___ODataParsers["normalizeODataEntity"];
  function delay(value, ms = 250) {
    return new Promise(resolve => {
      setTimeout(() => resolve(value), ms);
    });
  }
  function normalizeGuid(value) {
    return value.replace(/[{}]/g, '').trim();
  }
  function formatGuidLiteral(value) {
    return normalizeGuid(value);
  }

  // function isNetworkFailure(error: unknown): boolean {
  // 	return error instanceof TypeError || String(error).toLowerCase().includes('fetch');
  // }

  function asString(value) {
    if (value === null || value === undefined) {
      return '';
    }
    const primitive = value;
    return String(primitive);
  }
  function toValueHelpItems(payload, keyFields) {
    return normalizeODataCollection(payload).map(entity => {
      const key = keyFields.map(field => asString(entity[field])).find(value => Boolean(value)) ?? '';
      const text = asString(entity.Description) || asString(entity.Text) || key;
      return {
        key,
        text
      };
    }).filter(item => Boolean(item.key));
  }
  function mapPermissionNames(payload) {
    const records = normalizeODataCollection(payload);
    const values = records.map(entity => asString(entity.Permission) || asString(entity.permission) || asString(entity.Name) || asString(entity.name)).filter(value => Boolean(value));
    if (values.length > 0) {
      return values;
    }
    if (Array.isArray(payload)) {
      return payload.map(item => asString(item)).filter(value => Boolean(value));
    }
    return [];
  }
  function buildServiceUrl(path) {
    const normalizedPath = path.startsWith('http://') || path.startsWith('https://') ? path : `${SERVICE_ORIGIN}${path.startsWith('/') ? path : `/${path}`}`;
    const url = new URL(normalizedPath, window.location.origin);
    url.searchParams.set('sap-client', '324');
    return url.toString();
  }
  async function parseErrorResponse(response, context) {
    let message = `${context} failed (${response.status})`;
    const details = [];
    try {
      const text = await response.text();
      if (text) {
        try {
          const payload = JSON.parse(text);
          const error = payload.error;
          if (error) {
            message = asString(error.message) || asString(error.value) || message;
            const inner = error.details;
            if (Array.isArray(inner)) {
              details.push(...inner.map(item => asString(item.message)).filter(item => Boolean(item)));
            }
          }
          const messages = payload.SAP__Messages;
          if (Array.isArray(messages)) {
            details.push(...messages.map(item => asString(item.message)).filter(item => Boolean(item)));
          }
        } catch {
          message = text.trim() || message;
        }
      }
    } catch {
      // Ignore body parsing failures and fall back to the status-based message.
    }
    return new ServiceError(response.status, message, details);
  }
  async function readJson(path) {
    await ODataClient.ensureAuth();
    const response = await fetch(buildServiceUrl(path), {
      method: 'GET',
      credentials: 'include',
      headers: {
        Accept: 'application/json'
      }
    });
    if (!response.ok) {
      throw await parseErrorResponse(response, `GET ${path}`);
    }
    const text = await response.text();
    if (!text) {
      return {};
    }
    try {
      return JSON.parse(text);
    } catch {
      return {};
    }
  }
  async function writeJson(path, method, body, headers) {
    await ODataClient.ensureAuth();
    const response = await fetch(buildServiceUrl(path), {
      method,
      credentials: 'include',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        ...headers
      },
      body: JSON.stringify(body)
    });
    if (!response.ok) {
      throw await parseErrorResponse(response, `${method} ${path}`);
    }
    const text = await response.text();
    if (!text) {
      return {};
    }
    try {
      return JSON.parse(text);
    } catch {
      return {};
    }
  }
  class RegistryService {
    client = new ODataClient();
    async getPermissions() {
      const csrfToken = await this.client.fetchCsrfToken();
      const payload = await this.client.postJson('/Registry/com.sap.gateway.srvd_a2x.zsr_registry.v0001.getPermissions', undefined, {
        headers: {
          'X-CSRF-Token': csrfToken
        }
      });
      const permissions = mapPermissionNames(payload);
      if (permissions.length === 0) {
        throw new ServiceError(500, 'Permission response did not contain any permissions.');
      }
      return delay(permissions);
    }
    async getGroupTypes() {
      const payload = await readJson('/ZI_GRP_TYPE_VH');
      const items = toValueHelpItems(payload, ['TypeId']);
      return delay(items);
    }
    async getStatuses() {
      const payload = await readJson('/ZI_GRP_STAT_VH');
      const items = toValueHelpItems(payload, ['StatusId']);
      return delay(items);
    }
    async getRegistries(filter) {
      const backendRegistries = await this.loadRegistriesFromBackend(filter);
      return delay(this.filterRegistries(backendRegistries, filter));
    }
    async getRegistry(registryId) {
      const backendRegistry = await this.loadRegistryFromBackend(registryId);
      if (!backendRegistry) {
        throw new ServiceError(404, 'Registry not found.');
      }
      return delay(backendRegistry);
    }
    async createRegistry(input) {
      const validationMessages = this.validateCreateInput(input);
      if (validationMessages.length > 0) {
        throw new ServiceError(400, 'Registry validation failed.', validationMessages);
      }
      const headers = await this.client.ensureWriteHeaders('POST');
      const payload = {
        GroupName: input.groupName.trim(),
        GroupType: input.groupType.trim()
      };
      if (input.versionNo.trim()) {
        payload.VersionNo = input.versionNo.trim();
      }
      const entity = normalizeODataEntity(await writeJson('/Registry', 'POST', payload, headers));
      return delay(mapRegistryEntity(entity, {
        serviceDefinition: ''
      }));
    }
    async updateRegistry(registryId, input) {
      const validationMessages = this.validateUpdateInput(input);
      if (validationMessages.length > 0) {
        throw new ServiceError(400, 'Registry validation failed.', validationMessages);
      }
      const headers = await this.client.ensureWriteHeaders('PATCH');
      const entity = normalizeODataEntity(await writeJson(`/Registry(${formatGuidLiteral(registryId)})`, 'PATCH', {
        Status: input.status.trim()
      }, headers));
      return delay(mapRegistryEntity(entity, {
        serviceDefinition: ''
      }));
    }
    async deleteRegistry(registryId) {
      await this.client.ensureWriteHeaders('DELETE');
      await writeJson(`/Registry(${formatGuidLiteral(registryId)})`, 'DELETE', undefined, await this.client.ensureWriteHeaders('DELETE'));
      await delay(undefined);
    }
    async activateRegistry(registryId, changedBy = 'demo.user') {
      return this.changeStatus(registryId, 'Published', changedBy);
    }
    async deactivateRegistry(registryId, changedBy = 'demo.user') {
      return this.changeStatus(registryId, 'Unpublished', changedBy);
    }
    async generateVersion(registryId, etag) {
      const headers = await this.client.ensureWriteHeaders('POST');
      if (etag) {
        headers['If-Match'] = etag;
      }
      const payload = normalizeODataEntity(await writeJson(`/Registry/${formatGuidLiteral(registryId)}/com.sap.gateway.srvd_a2x.zsr_registry.v0001.generateVersion`, 'POST', undefined, headers));
      return delay(payload, 350);
    }
    filterRegistries(registries, filter) {
      const normalizedSearch = filter.search.trim().toLowerCase();
      return registries.filter(registry => {
        const matchesSearch = !normalizedSearch || [registry.id, registry.registryName, registry.serviceName, registry.serviceType, registry.versionNo, registry.status, registry.statusText, registry.description, registry.createdBy, registry.createdAt, registry.lastChangedBy, registry.lastChangedAt].join(' ').toLowerCase().includes(normalizedSearch);
        return matchesSearch;
      });
    }
    async loadRegistriesFromBackend(filter) {
      let url = '/Registry?$orderby=LastChangeAt desc';
      const filterParts = [];
      if (filter) {
        if (filter.status && filter.status.toLowerCase() !== 'all') {
          filterParts.push(`Status eq '${filter.status}'`);
        }
        if (filter.groupType && filter.groupType.toLowerCase() !== 'all') {
          filterParts.push(`GroupType eq '${filter.groupType}'`);
        }
        if (filter.registryName) {
          filterParts.push(`contains(GroupName,'${filter.registryName}')`);
        }
        if (filter.createdBy) {
          filterParts.push(`contains(RegisteredBy,'${filter.createdBy}')`);
        }
        if (filterParts.length > 0 || filter.search) {
          const queryParts = [...filterParts];
          if (filter.search) {
            const term = filter.search.replace(/'/g, "''");
            let globalSearchFilter = '';
            const isGuid = /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/.test(term);
            if (filter.searchField === 'registryName') {
              globalSearchFilter = `contains(GroupName,'${term}')`;
            } else if (filter.searchField === 'registryId') {
              if (isGuid) {
                globalSearchFilter = `GroupId eq ${term}`;
              } else {
                globalSearchFilter = `GroupId eq 00000000-0000-0000-0000-000000000000`;
              }
            } else {
              if (isGuid) {
                globalSearchFilter = `(contains(GroupName,'${term}') or GroupId eq ${term})`;
              } else {
                globalSearchFilter = `contains(GroupName,'${term}')`;
              }
            }
            queryParts.push(globalSearchFilter);
          }
          url += `&$filter=${encodeURIComponent(queryParts.join(' and '))}`;
        }
      }
      const payload = await readJson(url);
      const registries = normalizeODataCollection(payload);
      return registries.map(entity => mapRegistryEntity(entity, {
        serviceDefinition: ''
      }));
    }
    async loadRegistryFromBackend(registryId) {
      const payload = await readJson(`/Registry/${formatGuidLiteral(registryId)}`);
      const entity = normalizeODataEntity(payload);
      if (!Object.keys(entity).length) {
        return null;
      }
      return mapRegistryEntity(entity, {
        serviceDefinition: ''
      });
    }
    async changeStatus(registryId, status, _changedBy) {
      const headers = await this.client.ensureWriteHeaders('PATCH');
      const entity = normalizeODataEntity(await writeJson(`/Registry(${formatGuidLiteral(registryId)})`, 'PATCH', {
        Status: status
      }, headers));
      return delay(mapRegistryEntity(entity, {
        serviceDefinition: ''
      }));
    }
    validateCreateInput(input) {
      const messages = [];
      if (!input.groupName.trim()) {
        messages.push('Group Name is required.');
      }
      if (!input.groupType.trim()) {
        messages.push('Group Type is required.');
      }
      if (input.groupType.trim() === '001' && !input.versionNo.trim()) {
        messages.push('Version No is required for group type 001.');
      }
      return messages;
    }
    validateUpdateInput(input) {
      const messages = [];
      if (!input.status.trim()) {
        messages.push('Status is required.');
      }
      return messages;
    }
    statusTextFromId(statusId) {
      switch (statusId.trim().toUpperCase()) {
        case 'P':
          return 'Published';
        case 'U':
          return 'Unpublished';
        case 'A':
          return 'Archive';
        default:
          return 'Unpublished';
      }
    }
  }
  return RegistryService;
});
//# sourceMappingURL=RegistryService-dbg.js.map
