sap.ui.define([], function () {
  "use strict";

  class ServiceError extends Error {
    constructor(status, message, details = []) {
      super(message);
      this.name = "ServiceError";
      this.status = status;
      this.details = details;
    }
  }
  return ServiceError;
});
//# sourceMappingURL=ServiceError-dbg.js.map
