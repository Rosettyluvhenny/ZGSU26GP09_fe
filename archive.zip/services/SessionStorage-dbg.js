sap.ui.define([], function () {
  "use strict";

  const SESSION_KEY = 'com.zgp9.fe.session';
  const THEME_KEY = 'com.zgp9.fe.theme';
  function isBrowserStorageAvailable() {
    return typeof window !== 'undefined' && Boolean(window.localStorage);
  }
  function readSessionStorage(fallback) {
    if (!isBrowserStorageAvailable()) {
      return fallback;
    }
    const raw = window.localStorage.getItem(SESSION_KEY);
    if (!raw) {
      return fallback;
    }
    try {
      return JSON.parse(raw);
    } catch {
      return fallback;
    }
  }
  function writeSessionStorage(value) {
    if (!isBrowserStorageAvailable()) {
      return;
    }
    window.localStorage.setItem(SESSION_KEY, JSON.stringify(value));
  }
  function removeSessionStorage() {
    if (!isBrowserStorageAvailable()) {
      return;
    }
    window.localStorage.removeItem(SESSION_KEY);
  }
  function readThemePreference() {
    if (!isBrowserStorageAvailable()) {
      return null;
    }
    return window.localStorage.getItem(THEME_KEY);
  }
  function writeThemePreference(theme) {
    if (!isBrowserStorageAvailable()) {
      return;
    }
    window.localStorage.setItem(THEME_KEY, theme);
  }
  var __exports = {
    __esModule: true
  };
  __exports.readSessionStorage = readSessionStorage;
  __exports.writeSessionStorage = writeSessionStorage;
  __exports.removeSessionStorage = removeSessionStorage;
  __exports.readThemePreference = readThemePreference;
  __exports.writeThemePreference = writeThemePreference;
  return __exports;
});
//# sourceMappingURL=SessionStorage-dbg.js.map
