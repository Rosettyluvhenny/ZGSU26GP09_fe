sap.ui.define(["./ODataClient", "./ServiceError", "./ODataParsers"], function (__ODataClient, __ServiceError, ___ODataParsers) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const ODataClient = _interopRequireDefault(__ODataClient);
  const ServiceError = _interopRequireDefault(__ServiceError);
  const mapVersionEntity = ___ODataParsers["mapVersionEntity"];
  const normalizeODataCollection = ___ODataParsers["normalizeODataCollection"];
  const normalizeODataEntity = ___ODataParsers["normalizeODataEntity"];
  function delay(value, ms = 250) {
    return new Promise(resolve => {
      setTimeout(() => resolve(value), ms);
    });
  }
  function normalizeGuid(value) {
    return value.replace(/[{}]/g, '').trim();
  }
  function formatGuidLiteral(value) {
    return normalizeGuid(value);
  }
  function asString(value) {
    if (value === null || value === undefined) {
      return '';
    }
    const primitive = value;
    return String(primitive);
  }
  function mapCompareEntry(entry) {
    return {
      serviceDefId: asString(entry.SERVICEDEFID),
      baseDetailId: asString(entry.BASEDETAILID),
      compareDetailId: asString(entry.COMPAREDETAILID),
      changeType: asString(entry.CHANGETYPE).toUpperCase() || 'UNCHANGED'
    };
  }
  function mapCompareResult(payload) {
    return {
      baseVersionId: asString(payload.BASEVERSIONID),
      compareVersionId: asString(payload.COMPAREVERSIONID),
      change: Array.isArray(payload.CHANGE) ? payload.CHANGE.map(mapCompareEntry) : [],
      differ: Array.isArray(payload.DIFFER) ? payload.DIFFER.map(mapCompareEntry) : [],
      unchange: Array.isArray(payload.UNCHANGE) ? payload.UNCHANGE.map(mapCompareEntry) : []
    };
  }
  class VersionService {
    client = new ODataClient();
    constructor(detailService) {
      this.detailService = detailService;
    }
    async getVersions(registryId) {
      const backendVersions = await this.loadVersionsFromBackend(registryId);
      return delay(backendVersions);
    }
    async getVersion(versionId) {
      const backendVersion = await this.loadVersionFromBackend(versionId);
      if (!backendVersion) {
        throw new ServiceError(404, 'Version not found.');
      }
      return delay(backendVersion);
    }
    async compareVersions(leftVersionId, rightVersionId) {
      const headers = await this.client.ensureWriteHeaders('POST');
      const payload = normalizeODataEntity(await this.client.postJson('/Version/com.sap.gateway.srvd_a2x.zsr_registry.v0001.compareVersion', {
        BaseVrsId: leftVersionId,
        CompareVrsId: rightVersionId
      }, {
        headers
      }));
      return mapCompareResult(payload);
    }
    async loadVersionsFromBackend(registryId) {
      const payload = await this.client.readJson(`/Registry/${formatGuidLiteral(registryId)}/_Version?$orderby=CreatedAt desc`);
      const versions = normalizeODataCollection(payload);
      return versions.map(entity => this.loadVersionFromEntity(entity));
    }
    async loadVersionFromBackend(versionId) {
      const payload = await this.client.readJson(`/Version/${formatGuidLiteral(versionId)}`);
      const entity = normalizeODataEntity(payload);
      if (!Object.keys(entity).length) {
        return null;
      }
      return this.loadVersionFromEntity(entity);
    }
    loadVersionFromEntity(entity) {
      let parsedDetail;
      return mapVersionEntity(entity, parsedDetail);
    }
  }
  return VersionService;
});
//# sourceMappingURL=VersionService-dbg.js.map
