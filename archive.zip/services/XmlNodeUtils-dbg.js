sap.ui.define([], function () {
  "use strict";

  function asText(value) {
    return value === null || value === undefined ? '' : String(value);
  }
  function getLabelSuffix(value) {
    const lastSegment = value.split('/').filter(Boolean).pop();
    return lastSegment && lastSegment.length > 0 ? lastSegment : value;
  }
  function formatNodeLabel(item) {
    return `${item.nodeType}{${getLabelSuffix(item.semanticId)}}`;
  }
  function createAttributeNodes(item) {
    if (item.attributes.length === 0) {
      return [];
    }
    const attributeGroup = {
      nodeId: `${item.nodeId}-attrs`,
      semanticId: `${item.semanticId}/@attributes`,
      parentId: item.nodeId,
      nodePath: `${item.nodePath}/@attributes`,
      nodeType: 'Attributes',
      nodeName: 'Attributes',
      nodeAlias: '',
      offsetStart: item.offsetStart,
      offsetEnd: item.offsetEnd,
      seq: item.seq,
      depth: item.depth + 1,
      attributes: [],
      label: 'Attributes',
      children: [],
      lineStart: 0,
      lineEnd: 0,
      isAttributeGroup: true
    };
    attributeGroup.children = item.attributes.map((attribute, index) => ({
      nodeId: `${item.nodeId}-attr-${index}`,
      semanticId: `${item.semanticId}/${attribute.name}`,
      parentId: attributeGroup.nodeId,
      nodePath: `${item.nodePath}/@attributes/${index + 1}`,
      nodeType: 'Attribute',
      nodeName: attribute.name,
      nodeAlias: attribute.value,
      offsetStart: item.offsetStart,
      offsetEnd: item.offsetEnd,
      seq: index + 1,
      depth: item.depth + 2,
      attributes: [],
      label: `${attribute.name} = ${attribute.value}`,
      children: [],
      lineStart: 0,
      lineEnd: 0,
      isAttribute: true
    }));
    return [attributeGroup];
  }
  function prettyPrintXml(rawXml) {
    const xml = asText(rawXml);
    if (!xml) {
      return {
        prettyXml: '',
        rawOffsets: []
      };
    }
    const regex = /(<[^>]+>)|([^<]+)/g;
    let match;
    const lines = [];
    const rawOffsets = [];
    let indent = 0;
    while ((match = regex.exec(xml)) !== null) {
      const text = match[0].trim();
      if (!text) {
        continue;
      }
      const rawOffset = match.index;
      const isClosingTag = /^<\//.test(text);
      const isOpeningTag = /^<[^!?/][^>]*>$/.test(text) && !/\/>$/.test(text);
      const isSelfClosingTag = /\/>$/.test(text) || /^<\?/.test(text) || /^<!/.test(text);
      if (isClosingTag) {
        indent = Math.max(0, indent - 1);
      }
      lines.push(`${'\t'.repeat(indent)}${text}`);
      rawOffsets.push(rawOffset);
      if (isOpeningTag && !isSelfClosingTag) {
        indent += 1;
      }
    }
    return {
      prettyXml: lines.join('\n'),
      rawOffsets
    };
  }
  function buildXmlLineMap(xml) {
    const lineStarts = [0];
    for (let index = 0; index < xml.length; index += 1) {
      if (xml.charCodeAt(index) === 10) {
        lineStarts.push(index + 1);
      }
    }
    return {
      lineStarts
    };
  }
  function offsetToLine(offset, lineStarts) {
    if (lineStarts.length === 0) {
      return 1;
    }
    const normalizedOffset = Math.max(0, offset);
    let low = 0;
    let high = lineStarts.length - 1;
    while (low <= high) {
      const mid = Math.floor((low + high) / 2);
      if (lineStarts[mid] <= normalizedOffset) {
        low = mid + 1;
      } else {
        high = mid - 1;
      }
    }
    return Math.max(1, high + 1);
  }
  function buildNodeTree(items) {
    const byId = new Map();
    const roots = [];
    for (const item of items) {
      const label = formatNodeLabel(item);
      byId.set(item.nodeId, {
        ...item,
        label,
        children: [],
        lineStart: 0,
        lineEnd: 0
      });
    }
    for (const item of items) {
      const node = byId.get(item.nodeId);
      if (!node) {
        continue;
      }
      if (item.parentId && byId.has(item.parentId)) {
        byId.get(item.parentId).children.push(node);
      } else {
        roots.push(node);
      }
    }
    for (const item of items) {
      const node = byId.get(item.nodeId);
      if (!node) {
        continue;
      }
      node.children.push(...createAttributeNodes(item));
    }
    const sortTree = nodes => {
      nodes.sort((left, right) => {
        const leftKind = Number(Boolean(left.isAttributeGroup)) + Number(Boolean(left.isAttribute));
        const rightKind = Number(Boolean(right.isAttributeGroup)) + Number(Boolean(right.isAttribute));
        return leftKind - rightKind || left.seq - right.seq || left.depth - right.depth;
      });
      for (const node of nodes) {
        sortTree(node.children);
      }
    };
    sortTree(roots);
    return roots;
  }
  function flattenNodeTree(nodes) {
    return nodes.flatMap(node => [node, ...flattenNodeTree(node.children)]);
  }
  function filterNodeTree(nodes, predicate) {
    const result = [];
    for (const node of nodes) {
      const filteredChildren = filterNodeTree(node.children, predicate);
      if (predicate(node) || filteredChildren.length > 0) {
        result.push({
          ...node,
          children: filteredChildren
        });
      }
    }
    return result;
  }
  function applyNodeDiffStatus(nodes, statusBySemanticId) {
    return nodes.map(node => ({
      ...node,
      diffStatus: statusBySemanticId.get(node.semanticId),
      children: applyNodeDiffStatus(node.children, statusBySemanticId)
    }));
  }
  function buildLineHighlightMap(nodes) {
    const lineHighlights = new Map();
    const highlightedNodes = flattenNodeTree(nodes).filter(node => node.highlight && node.highlight !== 'None').sort((left, right) => right.depth - left.depth);
    for (const node of highlightedNodes) {
      const start = node.lineStart || 0;
      const end = node.lineEnd || start;
      if (start <= 0) {
        continue;
      }
      for (let line = start; line <= end; line += 1) {
        if (!lineHighlights.has(line)) {
          lineHighlights.set(line, node.highlight);
        }
      }
    }
    return lineHighlights;
  }
  function buildLineIndexFromXml(xml) {
    const lineStarts = [0];
    for (let index = 0; index < xml.length; index += 1) {
      if (xml[index] === '\n') {
        lineStarts.push(index + 1);
      }
    }
    return lineStarts;
  }
  var __exports = {
    __esModule: true
  };
  __exports.prettyPrintXml = prettyPrintXml;
  __exports.buildXmlLineMap = buildXmlLineMap;
  __exports.offsetToLine = offsetToLine;
  __exports.buildNodeTree = buildNodeTree;
  __exports.flattenNodeTree = flattenNodeTree;
  __exports.filterNodeTree = filterNodeTree;
  __exports.applyNodeDiffStatus = applyNodeDiffStatus;
  __exports.buildLineHighlightMap = buildLineHighlightMap;
  __exports.buildLineIndexFromXml = buildLineIndexFromXml;
  return __exports;
});
//# sourceMappingURL=XmlNodeUtils-dbg.js.map
