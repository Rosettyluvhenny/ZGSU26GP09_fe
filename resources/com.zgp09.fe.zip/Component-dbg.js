sap.ui.define(["sap/ui/core/UIComponent", "sap/ui/Device", "sap/ui/core/Messaging", "sap/ui/core/Theming", "./services/SessionStorage", "./services/DetailService", "./services/ErrorHandler", "./services/JobService", "./services/LogService", "./services/RegistryService", "./services/VersionService", "./model/models"], function (UIComponent, Device, Messaging, Theming, ___services_SessionStorage, __DetailService, __ErrorHandler, __JobService, __LogService, __RegistryService, __VersionService, __models) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const readThemePreference = ___services_SessionStorage["readThemePreference"];
  const DetailService = _interopRequireDefault(__DetailService);
  const ErrorHandler = _interopRequireDefault(__ErrorHandler);
  const JobService = _interopRequireDefault(__JobService);
  const LogService = _interopRequireDefault(__LogService);
  const RegistryService = _interopRequireDefault(__RegistryService);
  const VersionService = _interopRequireDefault(__VersionService);
  const models = _interopRequireDefault(__models);
  /**
   * @namespace com.zgp09.fe
   */
  const Component = UIComponent.extend("com.zgp09.fe.Component", {
    metadata: {
      manifest: 'json',
      interfaces: ['sap.ui.core.IAsyncContentCreation']
    },
    init: function _init() {
      UIComponent.prototype.init.call(this);
      const model = this.getModel();
      this.detailService = new DetailService(model);
      this.registryService = new RegistryService(model);
      this.versionService = new VersionService(this.detailService, model);
      this.jobService = new JobService(model);
      this.logService = new LogService(model);
      this.applyStoredTheme();
      this.setModel(models.createDeviceModel(), 'device');
      this.setModel(models.createSessionModel(), 'session');
      this.setModel(models.createUiModel(), 'ui');
      this.setModel(Messaging.getMessageModel(), 'message');

      // this.injectAppStylesheet();
      this.errorHandler = new ErrorHandler(this.getRouter());
      this.registerViewportWidthTracking();
      this.getRouter().initialize();
    },
    // Keep a viewport-width flag on the ui model so layouts (e.g. the split-view
    // Splitters) can switch to a stacked orientation on narrow screens. Unlike
    // device>/system/phone, this reacts to desktop window resizing and browser zoom.
    registerViewportWidthTracking: function _registerViewportWidthTracking() {
      const ui = this.getModel('ui');
      // matchMedia reflects the CSS viewport width, so it fires reliably on window
      // resize and also when the user zooms the browser (unlike Device.resize, which
      // is throttled and can miss programmatic/emulated resizes).
      // isPhoneWidth (<600px) drives the shell nav overlay; isNarrowWidth (<1024px)
      // drives the split-view panes (tree â€– XML) so they stack vertically whenever
      // there isn't enough room to show them side by side comfortably.
      const phoneMql = window.matchMedia('(max-width: 599px)');
      const narrowMql = window.matchMedia('(max-width: 1023px)');
      const update = () => {
        ui.setProperty('/isPhoneWidth', phoneMql.matches);
        ui.setProperty('/isNarrowWidth', narrowMql.matches);
      };
      update();
      phoneMql.addEventListener('change', update);
      narrowMql.addEventListener('change', update);
      window.addEventListener('resize', update);
    },
    applyStoredTheme: function _applyStoredTheme() {
      const storedTheme = readThemePreference();
      if (storedTheme && storedTheme !== Theming.getTheme()) {
        Theming.setTheme(storedTheme);
      }
    },
    getContentDensityClass: function _getContentDensityClass() {
      if (this.contentDensityClass === undefined) {
        if (document.body.classList.contains('sapUiSizeCozy') || document.body.classList.contains('sapUiSizeCompact')) {
          this.contentDensityClass = '';
        } else if (!Device.support.touch) {
          this.contentDensityClass = 'sapUiSizeCompact';
        } else {
          this.contentDensityClass = 'sapUiSizeCozy';
        }
      }
      return this.contentDensityClass;
    },
    getRegistryService: function _getRegistryService() {
      return this.registryService;
    },
    getVersionService: function _getVersionService() {
      return this.versionService;
    },
    getDetailService: function _getDetailService() {
      return this.detailService;
    },
    getJobService: function _getJobService() {
      return this.jobService;
    },
    getLogService: function _getLogService() {
      return this.logService;
    },
    getErrorHandler: function _getErrorHandler() {
      return this.errorHandler;
    },
    getMessageManager: function _getMessageManager() {
      return Messaging;
    }
  });
  return Component;
});
//# sourceMappingURL=Component-dbg.js.map
