sap.ui.define(["sap/ui/core/UIComponent", "sap/ui/Device", "sap/ui/core/Messaging", "sap/ui/core/Theming", "./services/SessionStorage", "./services/AuthenticationService", "./services/DetailService", "./services/ErrorHandler", "./services/JobService", "./services/LogService", "./services/RegistryService", "./services/VersionService", "./model/models"], function (UIComponent, Device, Messaging, Theming, ___services_SessionStorage, __AuthenticationService, __DetailService, __ErrorHandler, __JobService, __LogService, __RegistryService, __VersionService, __models) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const readThemePreference = ___services_SessionStorage["readThemePreference"];
  const AuthenticationService = _interopRequireDefault(__AuthenticationService);
  const DetailService = _interopRequireDefault(__DetailService);
  const ErrorHandler = _interopRequireDefault(__ErrorHandler);
  const JobService = _interopRequireDefault(__JobService);
  const LogService = _interopRequireDefault(__LogService);
  const RegistryService = _interopRequireDefault(__RegistryService);
  const VersionService = _interopRequireDefault(__VersionService);
  const models = _interopRequireDefault(__models);
  /**
   * @namespace com.zgp9.fe
   */
  const Component = UIComponent.extend("com.zgp9.fe.Component", {
    constructor: function constructor() {
      UIComponent.prototype.constructor.apply(this, arguments);
      this.authenticationService = new AuthenticationService();
      this.detailService = new DetailService();
      this.registryService = new RegistryService();
      this.versionService = new VersionService(this.detailService);
      this.jobService = new JobService();
      this.logService = new LogService();
    },
    metadata: {
      manifest: 'json',
      interfaces: ['sap.ui.core.IAsyncContentCreation']
    },
    init: function _init() {
      UIComponent.prototype.init.call(this);
      this.applyStoredTheme();
      this.setModel(models.createDeviceModel(), 'device');
      this.setModel(models.createSessionModel(), 'session');
      this.setModel(models.createUiModel(), 'ui');
      this.setModel(Messaging.getMessageModel(), 'message');
      this.injectAppStylesheet();
      this.errorHandler = new ErrorHandler(this.getRouter());
      this.getRouter().initialize();
    },
    applyStoredTheme: function _applyStoredTheme() {
      const storedTheme = readThemePreference();
      if (storedTheme && storedTheme !== Theming.getTheme()) {
        Theming.setTheme(storedTheme);
      }
    },
    injectAppStylesheet: function _injectAppStylesheet() {
      if (document.head.querySelector('link[data-app-stylesheet="true"]')) {
        return;
      }
      const link = document.createElement('link');
      link.rel = 'stylesheet';
      link.href = new URL('css/style.css', document.baseURI).toString();
      link.setAttribute('data-app-stylesheet', 'true');
      document.head.appendChild(link);
    },
    getContentDensityClass: function _getContentDensityClass() {
      if (this.contentDensityClass === undefined) {
        if (document.body.classList.contains('sapUiSizeCozy') || document.body.classList.contains('sapUiSizeCompact')) {
          this.contentDensityClass = '';
        } else if (!Device.support.touch) {
          this.contentDensityClass = 'sapUiSizeCompact';
        } else {
          this.contentDensityClass = 'sapUiSizeCozy';
        }
      }
      return this.contentDensityClass;
    },
    getAuthenticationService: function _getAuthenticationService() {
      return this.authenticationService;
    },
    getRegistryService: function _getRegistryService() {
      return this.registryService;
    },
    getVersionService: function _getVersionService() {
      return this.versionService;
    },
    getDetailService: function _getDetailService() {
      return this.detailService;
    },
    getJobService: function _getJobService() {
      return this.jobService;
    },
    getLogService: function _getLogService() {
      return this.logService;
    },
    getErrorHandler: function _getErrorHandler() {
      return this.errorHandler;
    },
    getMessageManager: function _getMessageManager() {
      return Messaging;
    }
  });
  return Component;
});
//# sourceMappingURL=Component-dbg.js.map
