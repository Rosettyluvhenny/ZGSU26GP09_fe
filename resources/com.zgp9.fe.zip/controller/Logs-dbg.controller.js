sap.ui.define(["sap/ui/model/json/JSONModel", "sap/ui/core/Fragment", "sap/m/MessageToast", "./BaseController", "../services/LogService"], function (JSONModel, Fragment, MessageToast, __BaseController, ___services_LogService) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const BaseController = _interopRequireDefault(__BaseController);
  const LOG_PAGE_SIZE = ___services_LogService["LOG_PAGE_SIZE"];
  /**
   * @namespace com.zgp9.fe.controller
   */
  const Logs = BaseController.extend("com.zgp9.fe.controller.Logs", {
    constructor: function constructor() {
      BaseController.prototype.constructor.apply(this, arguments);
      this.dateFrom = null;
      this.dateTo = null;
      this.loadingMore = false;
      /** Distinct values seen from backend responses â€” never hard-coded. */
      this.knownActions = new Map();
      this.knownLogResults = new Set();
      this.knownObjectIdTypes = new Set();
    },
    onInit: function _onInit() {
      const model = new JSONModel({
        items: [],
        busy: false,
        loadingMore: false,
        search: '',
        actionType: 'All',
        logResult: 'All',
        objectIdType: 'All',
        // Filter options are built from values returned by the backend â€” never invented.
        actionTypeOptions: [{
          key: 'All',
          text: 'All'
        }],
        logResultOptions: [{
          key: 'All',
          text: 'All'
        }],
        objectIdTypeOptions: [{
          key: 'All',
          text: 'All'
        }],
        selectedLog: null,
        activeJobId: '',
        activeJobLabel: '',
        totalCount: 0,
        hasMore: false,
        countLabel: '0 entries'
      });
      // JSONModel default sizeLimit is 100 â€” without raising it, More can load 207
      // into the model while the table only renders the first 100 rows.
      model.setSizeLimit(5000);
      this.setModel(model, 'logList');
      this.getRouter().getRoute('logs').attachPatternMatched(event => {
        void this.onRouteMatched(event);
      });
    },
    onRouteMatched: async function _onRouteMatched(event) {
      const args = event.getParameter('arguments');
      const query = args['?query'];
      const jobId = query?.jobId ?? '';
      const model = this.getModel('logList');
      model.setProperty('/activeJobId', jobId);
      model.setProperty('/activeJobLabel', jobId || '');
      await this.loadLogs(true);
    },
    onGo: async function _onGo() {
      await this.loadLogs(true);
    },
    onRefresh: async function _onRefresh() {
      await this.loadLogs(true);
    },
    onClearFilters: async function _onClearFilters() {
      const model = this.getModel('logList');
      model.setProperty('/actionType', 'All');
      model.setProperty('/logResult', 'All');
      model.setProperty('/objectIdType', 'All');
      model.setProperty('/search', '');
      this.dateFrom = null;
      this.dateTo = null;
      await this.loadLogs(true);
    },
    onSearchLiveChange: function _onSearchLiveChange(event) {
      const source = event.getSource();
      this.getModel('logList').setProperty('/search', source.getValue());
    },
    onSearch: async function _onSearch(event) {
      const source = event.getSource();
      this.getModel('logList').setProperty('/search', source.getValue());
      await this.loadLogs(true);
    },
    onFilterChange: async function _onFilterChange() {
      await this.loadLogs(true);
    },
    onDateRangeChange: function _onDateRangeChange(event) {
      const source = event.getSource();
      this.dateFrom = source.getDateValue();
      this.dateTo = source.getSecondDateValue();
    },
    onLoadMore: async function _onLoadMore() {
      if (this.loadingMore) {
        return;
      }
      await this.loadLogs(false);
    },
    onRowPress: function _onRowPress(event) {
      const source = event.getSource();
      const log = source.getBindingContext('logList')?.getObject();
      if (!log) {
        return;
      }
      void this.openDetailDialog(log);
    },
    onNavigateToObject: async function _onNavigateToObject() {
      const log = this.getModel('logList').getProperty('/selectedLog');
      if (!log || !log.objectId) {
        return;
      }
      const objectType = (log.objectIdType || '').toUpperCase();
      if (objectType === 'REGISTRY') {
        this.closeDetailDialog();
        this.navTo('registryDetail', {
          registryId: log.objectId
        });
        return;
      }
      if (objectType === 'VERSION') {
        try {
          const version = await this.getOwnerComponent().getVersionService().getVersion(log.objectId);
          const registryId = version.groupId;
          if (!registryId) {
            MessageToast.show('Cannot open version: registry is missing.');
            return;
          }
          this.closeDetailDialog();
          this.navTo('versionDetail', {
            registryId,
            versionId: log.objectId
          });
        } catch (error) {
          await this.handleServiceError(error);
        }
        return;
      }
      if (objectType === 'DETAIL') {
        try {
          const detail = await this.getOwnerComponent().getDetailService().getDetail(log.objectId);
          if (!detail.groupId || !detail.versionId) {
            MessageToast.show('Cannot open detail: version or registry is missing.');
            return;
          }
          this.closeDetailDialog();
          this.navTo('versionDetail', {
            registryId: detail.groupId,
            versionId: detail.versionId,
            query: {
              detailId: log.objectId
            }
          });
        } catch (error) {
          await this.handleServiceError(error);
        }
      }
    },
    onCloseDetailDialog: function _onCloseDetailDialog() {
      this.closeDetailDialog();
    },
    onClearJobFilter: function _onClearJobFilter() {
      const model = this.getModel('logList');
      model.setProperty('/activeJobId', '');
      model.setProperty('/activeJobLabel', '');
      this.getRouter().navTo('logs', {}, undefined, true);
    },
    formatLogResultState: function _formatLogResultState(result) {
      const normalized = (result || '').toUpperCase();
      if (normalized === 'S' || normalized === 'SUCCESS') {
        return 'Success';
      }
      if (normalized === 'F' || normalized.startsWith('FAIL') || normalized === 'ERROR' || normalized === 'E') {
        return 'Error';
      }
      return 'None';
    },
    /** CREATE â†’ green, UPDATE â†’ yellow; other actions stay neutral. */formatLogActionState: function _formatLogActionState(action) {
      const normalized = (action || '').toUpperCase().trim();
      if (normalized === 'CREATE' || normalized === 'C') {
        return 'Success';
      }
      if (normalized === 'UPDATE' || normalized === 'U' || normalized === 'UP') {
        return 'Warning';
      }
      return 'Information';
    },
    formatShortId: function _formatShortId(id) {
      if (!id) {
        return 'â€”';
      }
      const normalized = id.replace(/[{}]/g, '');
      if (normalized.length <= 13) {
        return normalized;
      }
      return `${normalized.slice(0, 8)}â€¦${normalized.slice(-4)}`;
    },
    loadLogs: async function _loadLogs(reset) {
      const model = this.getModel('logList');
      const currentItems = model.getProperty('/items') ?? [];
      const skip = reset ? 0 : currentItems.length;
      if (!reset) {
        if (!model.getProperty('/hasMore') || this.loadingMore) {
          return;
        }
        this.loadingMore = true;
        model.setProperty('/loadingMore', true);
      } else {
        model.setProperty('/busy', true);
      }
      try {
        const filter = {
          ...this.buildQueryFilter(),
          top: LOG_PAGE_SIZE,
          skip
        };
        const page = await this.getOwnerComponent().getLogService().getLogs(filter);
        const items = reset ? page.items : currentItems.concat(page.items);
        const totalCount = page.totalCount;
        const hasMore = items.length < totalCount && page.items.length > 0;
        model.setProperty('/items', items);
        model.setProperty('/totalCount', totalCount);
        model.setProperty('/hasMore', hasMore);
        model.setProperty('/countLabel', this.buildCountLabel(items.length, totalCount));
        this.refreshFilterOptions(items);
      } catch (error) {
        await this.handleServiceError(error);
      } finally {
        model.setProperty('/busy', false);
        model.setProperty('/loadingMore', false);
        this.loadingMore = false;
      }
    },
    /** Accumulate distinct backend values and rebuild Select options (never invent codes). */refreshFilterOptions: function _refreshFilterOptions(items) {
      for (const item of items) {
        const actionType = (item.actionType || '').trim();
        const actionText = (item.actionText || '').trim() || actionType;
        const result = (item.logResult || '').trim();
        const objectType = (item.objectIdType || '').trim();
        if (actionType) {
          this.knownActions.set(actionType, actionText);
        }
        if (result) {
          this.knownLogResults.add(result);
        }
        if (objectType) {
          this.knownObjectIdTypes.add(objectType);
        }
      }
      const model = this.getModel('logList');
      model.setProperty('/actionTypeOptions', [{
        key: 'All',
        text: 'All'
      }, ...[...this.knownActions.entries()].sort((a, b) => a[1].localeCompare(b[1])).map(([key, text]) => ({
        key,
        text
      }))]);
      model.setProperty('/logResultOptions', this.buildOptionsFromSet(this.knownLogResults));
      model.setProperty('/objectIdTypeOptions', this.buildOptionsFromSet(this.knownObjectIdTypes));

      // If the current selection vanished from the option list, fall back to All.
      this.ensureSelectedFilterKey('/actionType', '/actionTypeOptions');
      this.ensureSelectedFilterKey('/logResult', '/logResultOptions');
      this.ensureSelectedFilterKey('/objectIdType', '/objectIdTypeOptions');
    },
    buildOptionsFromSet: function _buildOptionsFromSet(values) {
      const unique = [...values].sort((a, b) => a.localeCompare(b));
      return [{
        key: 'All',
        text: 'All'
      }, ...unique.map(value => ({
        key: value,
        text: value
      }))];
    },
    ensureSelectedFilterKey: function _ensureSelectedFilterKey(selectedPath, optionsPath) {
      const model = this.getModel('logList');
      const selected = model.getProperty(selectedPath) || 'All';
      const options = model.getProperty(optionsPath) ?? [];
      if (!options.some(option => option.key === selected)) {
        model.setProperty(selectedPath, 'All');
      }
    },
    buildCountLabel: function _buildCountLabel(shown, total) {
      if (total <= 0) {
        return '0 entries';
      }
      if (shown >= total) {
        return `${total} entries`;
      }
      return `Showing ${shown} of ${total}`;
    },
    buildQueryFilter: function _buildQueryFilter() {
      const model = this.getModel('logList');
      return {
        jobId: model.getProperty('/activeJobId') || undefined,
        actionType: model.getProperty('/actionType'),
        logResult: model.getProperty('/logResult'),
        objectIdType: model.getProperty('/objectIdType'),
        dateFrom: this.dateFrom,
        dateTo: this.dateTo,
        search: model.getProperty('/search') || undefined
      };
    },
    openDetailDialog: async function _openDetailDialog(log) {
      this.getModel('logList').setProperty('/selectedLog', log);
      if (!this.detailDialog) {
        this.detailDialog = await Fragment.load({
          id: this.getView().getId(),
          name: 'com.zgp9.fe.view.fragments.LogDetailDialog',
          controller: this
        });
        this.getView().addDependent(this.detailDialog);
      }
      this.detailDialog.open();
    },
    closeDetailDialog: function _closeDetailDialog() {
      this.detailDialog?.close();
    }
  });
  return Logs;
});
//# sourceMappingURL=Logs-dbg.controller.js.map
