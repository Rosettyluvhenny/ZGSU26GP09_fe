sap.ui.define(["sap/ui/model/json/JSONModel", "sap/ui/core/Fragment", "./BaseController", "../services/LogService"], function (JSONModel, Fragment, __BaseController, ___services_LogService) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const BaseController = _interopRequireDefault(__BaseController);
  const LOG_PAGE_SIZE = ___services_LogService["LOG_PAGE_SIZE"];
  const ACTION_TYPE_LABELS = {
    VI: 'View',
    CR: 'Create',
    UP: 'Update',
    DE: 'Delete',
    GE: 'Generate',
    CO: 'Compare',
    LO: 'Login',
    LG: 'Logout',
    SC: 'Scan',
    GN: 'Generate',
    CM: 'Compare'
  };
  const ACTION_TYPE_OPTIONS = [{
    key: 'All',
    text: 'All'
  }, {
    key: 'VI',
    text: 'View (VI)'
  }, {
    key: 'CR',
    text: 'Create (CR)'
  }, {
    key: 'UP',
    text: 'Update (UP)'
  }, {
    key: 'DE',
    text: 'Delete (DE)'
  }, {
    key: 'GE',
    text: 'Generate (GE)'
  }, {
    key: 'GN',
    text: 'Generate (GN)'
  }, {
    key: 'CO',
    text: 'Compare (CO)'
  }, {
    key: 'CM',
    text: 'Compare (CM)'
  }, {
    key: 'SC',
    text: 'Scan (SC)'
  }, {
    key: 'LO',
    text: 'Login (LO)'
  }, {
    key: 'LG',
    text: 'Logout (LG)'
  }];
  const LOG_RESULT_OPTIONS = [{
    key: 'All',
    text: 'All'
  }, {
    key: 'SUCCESS',
    text: 'Success'
  }, {
    key: 'FAIL',
    text: 'Fail'
  }, {
    key: 'FAILURE',
    text: 'Failure'
  }, {
    key: 'ERROR',
    text: 'Error'
  }];
  const OBJECT_TYPE_OPTIONS = [{
    key: 'All',
    text: 'All'
  }, {
    key: 'REGISTRY',
    text: 'Registry'
  }, {
    key: 'DETAIL',
    text: 'Detail'
  }, {
    key: 'VERSION',
    text: 'Version'
  }, {
    key: 'SCANJOB',
    text: 'Scan Job'
  }];

  /**
   * @namespace com.zgp9.fe.controller
   */
  const Logs = BaseController.extend("com.zgp9.fe.controller.Logs", {
    constructor: function constructor() {
      BaseController.prototype.constructor.apply(this, arguments);
      this.dateFrom = null;
      this.dateTo = null;
      this.loadingMore = false;
    },
    onInit: function _onInit() {
      this.setModel(new JSONModel({
        items: [],
        busy: false,
        loadingMore: false,
        search: '',
        actionType: 'All',
        logResult: 'All',
        objectIdType: 'All',
        actionTypeOptions: ACTION_TYPE_OPTIONS,
        logResultOptions: LOG_RESULT_OPTIONS,
        objectIdTypeOptions: OBJECT_TYPE_OPTIONS,
        selectedLog: null,
        activeJobId: '',
        activeJobLabel: '',
        totalCount: 0,
        hasMore: false,
        countLabel: '0 entries'
      }), 'logList');
      this.getRouter().getRoute('logs').attachPatternMatched(event => {
        void this.onRouteMatched(event);
      });
    },
    onRouteMatched: async function _onRouteMatched(event) {
      const args = event.getParameter('arguments');
      const query = args['?query'];
      const jobId = query?.jobId ?? '';
      const model = this.getModel('logList');
      model.setProperty('/activeJobId', jobId);
      model.setProperty('/activeJobLabel', jobId || '');
      await this.loadLogs(true);
    },
    onGo: async function _onGo() {
      await this.loadLogs(true);
    },
    onRefresh: async function _onRefresh() {
      await this.loadLogs(true);
    },
    onClearFilters: async function _onClearFilters() {
      const model = this.getModel('logList');
      model.setProperty('/actionType', 'All');
      model.setProperty('/logResult', 'All');
      model.setProperty('/objectIdType', 'All');
      model.setProperty('/search', '');
      this.dateFrom = null;
      this.dateTo = null;
      await this.loadLogs(true);
    },
    onSearchLiveChange: function _onSearchLiveChange(event) {
      const source = event.getSource();
      this.getModel('logList').setProperty('/search', source.getValue());
    },
    onSearch: async function _onSearch(event) {
      const source = event.getSource();
      this.getModel('logList').setProperty('/search', source.getValue());
      await this.loadLogs(true);
    },
    onFilterChange: function _onFilterChange() {
      // Applied on Go / Refresh (server-side).
    },
    onDateRangeChange: function _onDateRangeChange(event) {
      const source = event.getSource();
      this.dateFrom = source.getDateValue();
      this.dateTo = source.getSecondDateValue();
    },
    onLoadMore: async function _onLoadMore() {
      if (this.loadingMore) {
        return;
      }
      await this.loadLogs(false);
    },
    onRowPress: function _onRowPress(event) {
      const source = event.getSource();
      const log = source.getBindingContext('logList')?.getObject();
      if (!log) {
        return;
      }
      void this.openDetailDialog(log);
    },
    onNavigateToObject: function _onNavigateToObject() {
      const log = this.getModel('logList').getProperty('/selectedLog');
      if (!log || !log.objectId) {
        return;
      }
      this.closeDetailDialog();
      if (log.objectIdType === 'REGISTRY') {
        this.navTo('registryDetail', {
          registryId: log.objectId
        });
      }
    },
    onCloseDetailDialog: function _onCloseDetailDialog() {
      this.closeDetailDialog();
    },
    onClearJobFilter: async function _onClearJobFilter() {
      const model = this.getModel('logList');
      model.setProperty('/activeJobId', '');
      model.setProperty('/activeJobLabel', '');
      this.getRouter().navTo('logs', {}, undefined, true);
    },
    formatLogResultState: function _formatLogResultState(result) {
      const normalized = (result || '').toUpperCase();
      if (normalized === 'S' || normalized === 'SUCCESS') {
        return 'Success';
      }
      if (normalized === 'F' || normalized.startsWith('FAIL') || normalized === 'ERROR' || normalized === 'E') {
        return 'Error';
      }
      return 'None';
    },
    formatActionType: function _formatActionType(code) {
      if (!code) {
        return '';
      }
      return ACTION_TYPE_LABELS[code.toUpperCase()] ?? code;
    },
    formatShortId: function _formatShortId(id) {
      if (!id) {
        return '—';
      }
      const normalized = id.replace(/[{}]/g, '');
      if (normalized.length <= 13) {
        return normalized;
      }
      return `${normalized.slice(0, 8)}…${normalized.slice(-4)}`;
    },
    loadLogs: async function _loadLogs(reset) {
      const model = this.getModel('logList');
      const currentItems = model.getProperty('/items') ?? [];
      const skip = reset ? 0 : currentItems.length;
      if (!reset) {
        if (!model.getProperty('/hasMore') || this.loadingMore) {
          return;
        }
        this.loadingMore = true;
        model.setProperty('/loadingMore', true);
      } else {
        model.setProperty('/busy', true);
      }
      try {
        const filter = {
          ...this.buildQueryFilter(),
          top: LOG_PAGE_SIZE,
          skip
        };
        const page = await this.getOwnerComponent().getLogService().getLogs(filter);
        const items = reset ? page.items : currentItems.concat(page.items);
        const totalCount = page.totalCount;
        const hasMore = items.length < totalCount && page.items.length > 0;
        model.setProperty('/items', items);
        model.setProperty('/totalCount', totalCount);
        model.setProperty('/hasMore', hasMore);
        model.setProperty('/countLabel', this.buildCountLabel(items.length, totalCount));
      } catch (error) {
        await this.handleServiceError(error);
      } finally {
        model.setProperty('/busy', false);
        model.setProperty('/loadingMore', false);
        this.loadingMore = false;
      }
    },
    buildCountLabel: function _buildCountLabel(shown, total) {
      if (total <= 0) {
        return '0 entries';
      }
      if (shown >= total) {
        return `${total} entries`;
      }
      return `Showing ${shown} of ${total}`;
    },
    buildQueryFilter: function _buildQueryFilter() {
      const model = this.getModel('logList');
      return {
        jobId: model.getProperty('/activeJobId') || undefined,
        actionType: model.getProperty('/actionType'),
        logResult: model.getProperty('/logResult'),
        objectIdType: model.getProperty('/objectIdType'),
        dateFrom: this.dateFrom,
        dateTo: this.dateTo,
        search: model.getProperty('/search') || undefined
      };
    },
    openDetailDialog: async function _openDetailDialog(log) {
      this.getModel('logList').setProperty('/selectedLog', log);
      if (!this.detailDialog) {
        this.detailDialog = await Fragment.load({
          id: this.getView().getId(),
          name: 'com.zgp9.fe.view.fragments.LogDetailDialog',
          controller: this
        });
        this.getView().addDependent(this.detailDialog);
      }
      this.detailDialog.open();
    },
    closeDetailDialog: function _closeDetailDialog() {
      this.detailDialog?.close();
    }
  });
  return Logs;
});
//# sourceMappingURL=Logs-dbg.controller.js.map
