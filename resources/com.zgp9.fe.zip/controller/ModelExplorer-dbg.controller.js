sap.ui.define(["sap/ui/model/json/JSONModel", "sap/ui/core/BusyIndicator", "sap/ui/core/routing/History", "./BaseController", "../services/EdmxModel"], function (JSONModel, BusyIndicator, History, __BaseController, ___services_EdmxModel) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const BaseController = _interopRequireDefault(__BaseController);
  const parseEdmx = ___services_EdmxModel["parseEdmx"];
  /**
   * @namespace com.zgp9.fe.controller
   */
  const ModelExplorer = BaseController.extend("com.zgp9.fe.controller.ModelExplorer", {
    constructor: function constructor() {
      BaseController.prototype.constructor.apply(this, arguments);
      this.registryId = null;
      this.versionId = null;
      this.detailId = null;
      this.edm = null;
      this.rawXml = '';
    },
    onInit: function _onInit() {
      this.setModel(new JSONModel({
        busy: false,
        serviceName: '',
        version: '',
        parseError: '',
        details: [],
        selectedDetailId: '',
        search: '',
        counts: {
          entityTypes: 0,
          entitySets: 0,
          complexTypes: 0,
          enumTypes: 0,
          operations: 0
        },
        entityTypes: [],
        entitySets: [],
        complexTypes: [],
        enumTypes: [],
        operations: [],
        selectedKind: '',
        selected: null,
        selectedKeysText: ''
      }), 'model');
      this.getRouter().getRoute('modelExplorer').attachPatternMatched(event => {
        void this.onRouteMatched(event);
      });
    },
    onRouteMatched: async function _onRouteMatched(event) {
      const args = event.getParameter('arguments');
      this.registryId = args.registryId ?? null;
      this.versionId = args.versionId ?? null;
      this.detailId = args['?query']?.detailId ?? null;
      if (!this.registryId || !this.versionId) {
        return;
      }
      await this.load();
    },
    onRefresh: async function _onRefresh() {
      await this.load();
    },
    getAiChatContext: function _getAiChatContext() {
      if (!this.rawXml) {
        return null;
      }
      const model = this.getModel('model');
      return {
        label: model.getProperty('/serviceName') || 'Service metadata model',
        xml: this.rawXml,
        suggestions: ['Summarize this model', 'List entity types and their keys', 'Any design issues?'],
        storageKey: this.detailId ? `model.${this.detailId}` : undefined
      };
    },
    onNavBack: function _onNavBack() {
      const previousHash = History.getInstance().getPreviousHash();
      if (previousHash !== undefined && previousHash !== '') {
        window.history.go(-1);
      } else if (this.registryId && this.versionId) {
        this.navToXml();
      } else {
        this.getRouter().navTo('home', {}, undefined, true);
      }
    },
    /** Jump to the raw-XML / node-tree view for the same service definition. */navToXml: function _navToXml() {
      if (!this.registryId || !this.versionId) {
        return;
      }
      this.getRouter().navTo('versionDetail', {
        registryId: this.registryId,
        versionId: this.versionId,
        query: this.detailId ? {
          detailId: this.detailId
        } : {}
      });
    },
    onDetailChange: async function _onDetailChange(event) {
      const source = event.getSource();
      const nextId = source.getSelectedKey();
      if (!nextId || nextId === this.detailId) {
        return;
      }
      this.detailId = nextId;
      await this.load();
    },
    onSearch: function _onSearch(event) {
      const source = event.getSource();
      this.applySearch(source.getValue() || '');
    },
    onSelectEntityType: function _onSelectEntityType(event) {
      this.selectFromEvent(event, 'entityType');
    },
    onSelectEntitySet: function _onSelectEntitySet(event) {
      this.selectFromEvent(event, 'entitySet');
    },
    onSelectComplexType: function _onSelectComplexType(event) {
      this.selectFromEvent(event, 'complexType');
    },
    onSelectEnumType: function _onSelectEnumType(event) {
      this.selectFromEvent(event, 'enumType');
    },
    onSelectOperation: function _onSelectOperation(event) {
      this.selectFromEvent(event, 'operation');
    },
    selectFromEvent: function _selectFromEvent(event, kind) {
      // Driven by each List's `selectionChange` event (SingleSelectMaster), which
      // reliably fires on tap and exposes the selected row as `listItem`.
      const item = event.getParameter('listItem');
      const element = item?.getBindingContext('model')?.getObject();
      if (element) {
        this.selectElement(kind, element);
      }
    },
    selectElement: function _selectElement(kind, element) {
      const model = this.getModel('model');
      model.setProperty('/selectedKind', kind);
      model.setProperty('/selected', element);
      const keys = element.keys;
      model.setProperty('/selectedKeysText', Array.isArray(keys) && keys.length > 0 ? keys.join(', ') : '');
    },
    load: async function _load() {
      if (!this.versionId) {
        return;
      }
      const model = this.getModel('model');
      model.setProperty('/busy', true);
      model.setProperty('/parseError', '');
      BusyIndicator.show(0);
      try {
        const details = await this.getOwnerComponent().getDetailService().getDetails(this.versionId);
        model.setProperty('/details', details);
        let target = this.detailId ? details.find(detail => detail.detailId === this.detailId) : undefined;
        target = target ?? details[0];
        if (!target) {
          this.edm = null;
          this.rawXml = '';
          this.resetModelData();
          model.setProperty('/parseError', 'This version has no service definition to explore.');
          return;
        }
        this.detailId = target.detailId;
        model.setProperty('/selectedDetailId', target.detailId);
        model.setProperty('/serviceName', target.serviceDefId || target.detailId);
        const parsed = await this.getOwnerComponent().getDetailService().getParsedDetail(target.detailId);
        this.rawXml = (parsed.metadataXml || target.metadataXml || '').replace(/<\?xml[^>]*\?>\s*/gi, '');
        this.edm = parseEdmx(this.rawXml);
        this.populateModelData(this.edm);
      } catch (error) {
        await this.handleServiceError(error);
      } finally {
        model.setProperty('/busy', false);
        BusyIndicator.hide();
      }
    },
    resetModelData: function _resetModelData() {
      const model = this.getModel('model');
      model.setProperty('/entityTypes', []);
      model.setProperty('/entitySets', []);
      model.setProperty('/complexTypes', []);
      model.setProperty('/enumTypes', []);
      model.setProperty('/operations', []);
      model.setProperty('/counts', {
        entityTypes: 0,
        entitySets: 0,
        complexTypes: 0,
        enumTypes: 0,
        operations: 0
      });
      model.setProperty('/selectedKind', '');
      model.setProperty('/selected', null);
      model.setProperty('/selectedKeysText', '');
      model.setProperty('/version', '');
    },
    populateModelData: function _populateModelData(edm) {
      const model = this.getModel('model');
      model.setProperty('/version', edm.version.toUpperCase());
      model.setProperty('/parseError', edm.error);
      model.setProperty('/search', '');
      this.applySearch('');

      // Auto-select the first available element so the detail pane isn't empty.
      if (edm.entityTypes.length > 0) {
        this.selectElement('entityType', edm.entityTypes[0]);
      } else if (edm.entitySets.length > 0) {
        this.selectElement('entitySet', edm.entitySets[0]);
      } else if (edm.complexTypes.length > 0) {
        this.selectElement('complexType', edm.complexTypes[0]);
      } else if (edm.enumTypes.length > 0) {
        this.selectElement('enumType', edm.enumTypes[0]);
      } else if (edm.operations.length > 0) {
        this.selectElement('operation', edm.operations[0]);
      } else {
        model.setProperty('/selectedKind', '');
        model.setProperty('/selected', null);
      }
    },
    applySearch: function _applySearch(query) {
      const model = this.getModel('model');
      const edm = this.edm;
      if (!edm) {
        return;
      }
      const q = query.trim().toLowerCase();
      const filter = items => q ? items.filter(item => item.name.toLowerCase().includes(q)) : items;
      const entityTypes = filter(edm.entityTypes);
      const entitySets = filter(edm.entitySets);
      const complexTypes = filter(edm.complexTypes);
      const enumTypes = filter(edm.enumTypes);
      const operations = filter(edm.operations);
      model.setProperty('/entityTypes', entityTypes);
      model.setProperty('/entitySets', entitySets);
      model.setProperty('/complexTypes', complexTypes);
      model.setProperty('/enumTypes', enumTypes);
      model.setProperty('/operations', operations);
      model.setProperty('/counts', {
        entityTypes: entityTypes.length,
        entitySets: entitySets.length,
        complexTypes: complexTypes.length,
        enumTypes: enumTypes.length,
        operations: operations.length
      });
    }
  });
  return ModelExplorer;
});
//# sourceMappingURL=ModelExplorer-dbg.controller.js.map
