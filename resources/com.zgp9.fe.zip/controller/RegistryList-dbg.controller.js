sap.ui.define(["sap/ui/core/BusyIndicator", "sap/ui/core/Fragment", "sap/ui/model/json/JSONModel", "sap/m/MessageToast", "sap/ui/model/Sorter", "./BaseController"], function (BusyIndicator, Fragment, JSONModel, MessageToast, Sorter, __BaseController) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const BaseController = _interopRequireDefault(__BaseController);
  /**
   * @namespace com.zgp9.fe.controller
   */
  const RegistryList = BaseController.extend("com.zgp9.fe.controller.RegistryList", {
    constructor: function constructor() {
      BaseController.prototype.constructor.apply(this, arguments);
      this.dialogMode = 'create';
      this.currentRegistryId = null;
    },
    onInit: function _onInit() {
      this.setModel(new JSONModel({
        items: [],
        busy: false,
        search: '',
        searchField: 'all',
        status: 'All',
        groupType: 'All',
        groupName: '',
        registeredBy: '',
        groupTypes: [],
        statuses: []
      }), 'registryList');
      this.getRouter().getRoute('registryList').attachPatternMatched(event => {
        void this.onRouteMatched(event);
      });
      this.applyStatusFromCurrentHash();
      void this.refreshRegistryPage();
    },
    onRouteMatched: async function _onRouteMatched(event) {
      const args = event.getParameter('arguments');
      const statusFromQuery = args['?query']?.status;
      if (statusFromQuery) {
        this.getModel('registryList').setProperty('/status', statusFromQuery);
      }
      await this.refreshRegistryPage();
    },
    applyStatusFromCurrentHash: function _applyStatusFromCurrentHash() {
      const queryIndex = window.location.hash.indexOf('?');
      if (queryIndex === -1) {
        return;
      }
      const status = new URLSearchParams(window.location.hash.substring(queryIndex + 1)).get('status');
      if (status) {
        this.getModel('registryList').setProperty('/status', status);
      }
    },
    onRefresh: async function _onRefresh() {
      await this.refreshRegistryPage();
    },
    onFilterChange: async function _onFilterChange() {
      await this.loadRegistries();
    },
    onSortPress: async function _onSortPress() {
      const view = this.getView();
      if (!view.byId('registryListSortDialog')) {
        const fragment = await Fragment.load({
          id: view.getId(),
          name: 'com.zgp9.fe.view.fragments.RegistryListSortDialog',
          controller: this
        });
        view.addDependent(fragment);
      }
      const dialog = view.byId('registryListSortDialog');
      dialog.open();
    },
    onSortConfirm: function _onSortConfirm(event) {
      const sortItem = event.getParameter('sortItem');
      const sortDescending = event.getParameter('sortDescending');
      const table = this.getView().byId('registryTable');
      const binding = table.getBinding('items');
      if (sortItem && binding) {
        const path = sortItem.getKey();
        const sorter = new Sorter(path, sortDescending);
        binding.sort(sorter);
      }
    },
    onGroupTypeChange: function _onGroupTypeChange(event) {
      const source = event.getSource();
      const groupType = source.getSelectedKey();
      const dialogModel = this.getModel('registryDialog');
      if (!dialogModel) {
        return;
      }
      dialogModel.setProperty('/showVersionNo', groupType !== '002');
      if (groupType === '002') {
        dialogModel.setProperty('/versionNo', '');
      } else if (!dialogModel.getProperty('/versionNo')) {
        dialogModel.setProperty('/versionNo', '001');
      }
    },
    onRowPress: function _onRowPress(event) {
      const registry = this.getRegistryFromEvent(event);
      if (!registry) {
        return;
      }
      this.navTo('registryDetail', {
        registryId: registry.groupId
      });
    },
    onCreateRegistry: async function _onCreateRegistry() {
      this.dialogMode = 'create';
      this.currentRegistryId = null;
      await this.openRegistryDialog({
        groupName: '',
        groupType: '001',
        versionNo: ''
      });
    },
    onEditRegistry: async function _onEditRegistry(event) {
      const registry = this.getRegistryFromEvent(event);
      if (!registry) {
        return;
      }
      this.dialogMode = 'edit';
      this.currentRegistryId = registry.groupId;
      await this.openRegistryDialog({
        groupName: registry.groupName,
        groupType: this.getGroupTypeIdFromRegistry(registry),
        versionNo: this.getVersionNoFromRegistry(registry),
        status: this.getStatusKeyFromRegistry(registry)
      });
    },
    onSaveRegistryDialog: async function _onSaveRegistryDialog() {
      const model = this.getView().getModel('registryDialog');
      const data = model.getData();
      BusyIndicator.show(0);
      model.setProperty('/busy', true);
      try {
        if (this.dialogMode === 'create') {
          await this.getOwnerComponent().getRegistryService().createRegistry({
            groupName: data.groupName ?? '',
            groupType: data.groupType ?? '',
            versionNo: data.groupType === '002' ? '' : data.versionNo ?? ''
          });
          MessageToast.show('Registry created.');
        } else if (this.currentRegistryId) {
          await this.getOwnerComponent().getRegistryService().updateRegistry(this.currentRegistryId, {
            status: data.status ?? ''
          });
          MessageToast.show('Registry updated.');
        }
        await this.loadRegistries();
        await this.closeRegistryDialog();
      } catch (error) {
        await this.handleServiceError(error);
      } finally {
        model.setProperty('/busy', false);
        BusyIndicator.hide();
      }
    },
    onCancelRegistryDialog: async function _onCancelRegistryDialog() {
      await this.closeRegistryDialog();
    },
    refreshRegistryPage: async function _refreshRegistryPage() {
      this.getModel('registryList').setProperty('/busy', true);
      await this.loadFilterValueHelps();
      await this.loadRegistries();
    },
    loadFilterValueHelps: async function _loadFilterValueHelps() {
      const model = this.getModel('registryList');
      if (model.getProperty('/groupTypes').length > 0) {
        return; // Already loaded
      }
      try {
        const [groupTypes, statuses] = await Promise.all([this.getOwnerComponent().getRegistryService().getGroupTypes(), this.getOwnerComponent().getRegistryService().getStatuses()]);
        model.setProperty('/groupTypes', [{
          key: 'All',
          text: 'All Service Types'
        }, ...groupTypes]);
        model.setProperty('/statuses', [{
          key: 'All',
          text: 'All Statuses'
        }, ...statuses]);
      } catch {
        // Silently fail if value helps cannot be loaded
      }
    },
    loadRegistries: async function _loadRegistries() {
      const model = this.getModel('registryList');
      model.setProperty('/busy', true);
      try {
        const filterState = {
          search: model.getProperty('/search'),
          searchField: model.getProperty('/searchField'),
          status: model.getProperty('/status'),
          groupType: model.getProperty('/groupType'),
          groupName: model.getProperty('/groupName'),
          registeredBy: model.getProperty('/registeredBy')
        };
        const data = await this.getOwnerComponent().getRegistryService().getRegistries(filterState);
        model.setProperty('/items', data);
      } catch (error) {
        await this.handleServiceError(error);
      } finally {
        model.setProperty('/busy', false);
      }
    },
    openRegistryDialog: async function _openRegistryDialog(initialData) {
      const dialogModel = new JSONModel({
        mode: this.dialogMode,
        title: this.dialogMode === 'create' ? 'Create Registry' : 'Update Registry',
        busy: false,
        groupName: initialData.groupName,
        groupType: initialData.groupType,
        versionNo: initialData.versionNo,
        status: initialData.status ?? '',
        showVersionNo: initialData.groupType !== '002',
        groupTypes: [],
        statuses: []
      });
      dialogModel.setDefaultBindingMode('TwoWay');
      this.setModel(dialogModel, 'registryDialog');
      await this.loadRegistryDialogValueHelp(dialogModel);
      if (this.dialogMode === 'create' && !dialogModel.getProperty('/groupType')) {
        const groupTypes = dialogModel.getProperty('/groupTypes');
        dialogModel.setProperty('/groupType', groupTypes[0]?.key ?? '001');
      }
      if (this.dialogMode === 'edit' && !dialogModel.getProperty('/status')) {
        const statuses = dialogModel.getProperty('/statuses');
        dialogModel.setProperty('/status', statuses[0]?.key ?? 'P');
      }
      dialogModel.setProperty('/showVersionNo', dialogModel.getProperty('/groupType') !== '002');
      if (this.dialogMode === 'create' && dialogModel.getProperty('/groupType') === '002') {
        dialogModel.setProperty('/versionNo', '');
      }
      if (this.dialogMode === 'create' && !dialogModel.getProperty('/versionNo') && dialogModel.getProperty('/groupType') === '001') {
        dialogModel.setProperty('/versionNo', '001');
      }
      if (this.registryDialogPromise === undefined) {
        this.registryDialogPromise = Fragment.load({
          id: this.getView().getId(),
          name: 'com.zgp9.fe.view.fragments.RegistryDialog',
          controller: this
        }).then(dialog => {
          this.getView().addDependent(dialog);
          return dialog;
        });
      }
      const dialog = await this.registryDialogPromise;
      dialog.setModel(dialogModel, 'registryDialog');
      dialog.open();
    },
    loadRegistryDialogValueHelp: async function _loadRegistryDialogValueHelp(model) {
      model.setProperty('/busy', true);
      try {
        const [groupTypes, statuses] = await Promise.all([this.getOwnerComponent().getRegistryService().getGroupTypes(), this.getOwnerComponent().getRegistryService().getStatuses()]);
        model.setProperty('/groupTypes', groupTypes);
        model.setProperty('/statuses', statuses);
      } finally {
        model.setProperty('/busy', false);
      }
    },
    closeRegistryDialog: async function _closeRegistryDialog() {
      if (this.registryDialogPromise === undefined) {
        return;
      }
      const dialog = await this.registryDialogPromise;
      dialog.close();
    },
    getRegistryFromEvent: function _getRegistryFromEvent(event) {
      const source = event.getSource();
      const context = source.getBindingContext('registryList');
      return context?.getObject() ?? null;
    },
    getStatusKeyFromRegistry: function _getStatusKeyFromRegistry(registry) {
      const currentStatus = `${registry.statusText ?? registry.status}`.trim().toLowerCase();
      switch (currentStatus) {
        case 'publish':
          return 'P';
        case 'unpublish':
          return 'U';
        case 'archive':
          return 'A';
        default:
          {
            const options = this.getModel('registryDialog')?.getProperty('/statuses');
            const matched = options?.find(item => item.text.toLowerCase() === currentStatus);
            return matched?.key ?? '';
          }
      }
    },
    getGroupTypeIdFromRegistry: function _getGroupTypeIdFromRegistry(registry) {
      const options = this.getModel('registryDialog')?.getProperty('/groupTypes');
      const matched = options?.find(item => item.text.toLowerCase() === registry.groupType.toLowerCase());
      return matched?.key ?? '';
    },
    getVersionNoFromRegistry: function _getVersionNoFromRegistry(registry) {
      const latestVersion = registry.versions[registry.versions.length - 1];
      return latestVersion?.versionNo ?? '';
    }
  });
  return RegistryList;
});
//# sourceMappingURL=RegistryList-dbg.controller.js.map
