sap.ui.define(["sap/ui/model/json/JSONModel", "sap/m/MessageToast", "sap/m/MessageBox", "sap/ui/core/BusyIndicator", "sap/ui/core/Fragment", "./BaseController", "../services/XmlNodeUtils"], function (JSONModel, MessageToast, MessageBox, BusyIndicator, Fragment, __BaseController, ___services_XmlNodeUtils) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const BaseController = _interopRequireDefault(__BaseController);
  const buildNodeTree = ___services_XmlNodeUtils["buildNodeTree"];
  const filterNodeTree = ___services_XmlNodeUtils["filterNodeTree"];
  const flattenNodeTree = ___services_XmlNodeUtils["flattenNodeTree"];
  const highlightXmlLine = ___services_XmlNodeUtils["highlightXmlLine"];
  const offsetToLine = ___services_XmlNodeUtils["offsetToLine"];
  const prettyPrintXml = ___services_XmlNodeUtils["prettyPrintXml"];
  /**
   * @namespace com.zgp9.fe.controller
   */
  const VersionDetail = BaseController.extend("com.zgp9.fe.controller.VersionDetail", {
    constructor: function constructor() {
      BaseController.prototype.constructor.apply(this, arguments);
      this.registryId = null;
      this.versionId = null;
      this.fullTree = [];
      this._sendMailDialog = null;
      this._exportSchemaDialog = null;
      this.highlightClearTimer = null;
    },
    onInit: function _onInit() {
      this.setModel(new JSONModel({
        busy: false,
        version: null,
        details: [],
        selectedDetail: null,
        selectedDetailXml: '',
        selectedDetailBusy: false,
        selectedNodeLine: 1,
        selectedDetailLineStarts: [],
        selectedDetailLines: [],
        treeSearch: '',
        treeSearchMatchCount: 0
      }), 'versionDetail');
      this.setModel(new JSONModel([]), 'treeModel');
      this.getRouter().getRoute("versionDetail").attachPatternMatched(event => {
        void this.onRouteMatched(event);
      });
    },
    onRouteMatched: async function _onRouteMatched(event) {
      const args = event.getParameter('arguments');
      this.registryId = args.registryId ?? null;
      this.versionId = args.versionId ?? null;
      const queryDetailId = args['?query']?.detailId ?? null;
      if (!this.registryId || !this.versionId) {
        return;
      }
      await this.loadVersion(queryDetailId);
    },
    onRefresh: async function _onRefresh() {
      await this.loadVersion();
    },
    onOpenModelExplorer: function _onOpenModelExplorer() {
      if (!this.registryId || !this.versionId) {
        return;
      }
      const detail = this.getModel('versionDetail').getProperty('/selectedDetail');
      this.getRouter().navTo('modelExplorer', {
        registryId: this.registryId,
        versionId: this.versionId,
        query: detail ? {
          detailId: detail.detailId
        } : {}
      });
    },
    onDetailChange: async function _onDetailChange(event) {
      const source = event.getSource();
      const selectedItem = source.getSelectedItem();
      const context = selectedItem?.getBindingContext('versionDetail');
      const detail = context?.getObject();
      if (!detail) {
        return;
      }
      await this.loadDetailWorkspace(detail);
    },
    onNodeSelectionChange: function _onNodeSelectionChange(event) {
      const listItem = event.getParameter('listItem');
      const context = listItem?.getBindingContext('treeModel');
      const node = context?.getObject();
      if (!node) {
        return;
      }
      this.selectXmlLine(node.lineStart || offsetToLine(node.offsetStart, this.getModel('versionDetail').getProperty('/selectedDetailLineStarts')));
      // Clear selection so clicking the same node again re-fires selectionChange + flash.
      const tree = event.getSource();
      window.setTimeout(() => tree.removeSelections?.(true), 0);
    },
    onTreeSearch: function _onTreeSearch(event) {
      const source = event.getSource();
      const query = (source.getValue() || '').trim().toLowerCase();
      const model = this.getModel('versionDetail');
      const treeModel = this.getModel('treeModel');
      if (!query) {
        model.setProperty('/treeSearchMatchCount', 0);
        treeModel.setData(this.fullTree);
        return;
      }
      const matchesQuery = node => node.nodeName.toLowerCase().includes(query) || node.nodeType.toLowerCase().includes(query);
      const filteredTree = filterNodeTree(this.fullTree, matchesQuery);
      const matchCount = flattenNodeTree(filteredTree).filter(matchesQuery).length;
      model.setProperty('/treeSearchMatchCount', matchCount);
      treeModel.setData(filteredTree);
      this.expandAllTreeNodes('versionDetailTree');
    },
    getAiChatContext: function _getAiChatContext() {
      const model = this.getModel('versionDetail');
      const xml = model.getProperty('/selectedDetailXml') ?? '';
      if (!xml) {
        return null;
      }
      const detail = model.getProperty('/selectedDetail');
      return {
        label: detail?.serviceDefId || 'Version metadata XML',
        xml,
        storageKey: detail ? `detail.${detail.detailId}` : undefined
      };
    },
    onCopyXml: async function _onCopyXml() {
      const model = this.getModel('versionDetail');
      const xml = model.getProperty('/selectedDetailXml');
      if (!xml) {
        MessageToast.show('No XML content to copy.');
        return;
      }
      const copied = await this.copyTextToClipboard(xml);
      MessageToast.show(copied ? 'XML copied to clipboard.' : 'Unable to copy XML.');
    },
    onDownloadXml: function _onDownloadXml() {
      const model = this.getModel('versionDetail');
      const xml = model.getProperty('/selectedDetailXml');
      if (!xml) {
        MessageToast.show('No XML content to download.');
        return;
      }
      const detail = model.getProperty('/selectedDetail');
      const baseName = (detail?.serviceDefId || detail?.detailId || 'metadata').replace(/[^a-zA-Z0-9_.-]+/g, '_');
      this.downloadFile(`${baseName}.xml`, new Blob([xml], {
        type: 'application/xml'
      }));
      MessageToast.show('XML downloaded successfully.');
    },
    onXmlLineSelectionChange: function _onXmlLineSelectionChange(event) {
      const source = event.getSource();
      const selectedItem = source.getSelectedItem();
      const context = selectedItem?.getBindingContext('versionDetail');
      const line = context?.getObject();
      if (!line) {
        return;
      }
      const model = this.getModel('versionDetail');
      model.setProperty('/selectedNodeLine', line.lineNo);
    },
    // ─── Send Mail ───────────────────────────────────────────────────────────
    onSendMail: function _onSendMail() {
      const model = this.getModel('versionDetail');
      const detail = model.getProperty('/selectedDetail');
      const defaultSubject = detail?.serviceDefId ? `Version XML: ${detail.serviceDefId}` : 'Version XML Report';
      this.setModel(new JSONModel({
        busy: false,
        recipients: '',
        subject: defaultSubject,
        recipientsState: 'None',
        recipientsStateText: '',
        subjectState: 'None',
        subjectStateText: ''
      }), 'sendMail');
      const loadDialog = async () => {
        if (!this._sendMailDialog) {
          this._sendMailDialog = await Fragment.load({
            id: this.getView()?.getId(),
            name: 'com.zgp9.fe.view.fragments.SendVersionMailDialog',
            controller: this
          });
          this.getView()?.addDependent(this._sendMailDialog);
        }
        this._sendMailDialog.open();
      };
      void loadDialog();
    },
    onRecipientsLiveChange: function _onRecipientsLiveChange() {
      const model = this.getModel('sendMail');
      const val = (model.getProperty('/recipients') ?? '').trim();
      if (val) {
        const {
          valid,
          invalid
        } = this.validateEmails(val);
        if (invalid.length > 0) {
          model.setProperty('/recipientsState', 'Warning');
          model.setProperty('/recipientsStateText', `Invalid: ${invalid.join(', ')}`);
        } else {
          model.setProperty('/recipientsState', 'Success');
          model.setProperty('/recipientsStateText', `${valid.length} recipient(s) valid`);
        }
      } else {
        model.setProperty('/recipientsState', 'None');
        model.setProperty('/recipientsStateText', '');
      }
    },
    onConfirmSendMail: async function _onConfirmSendMail() {
      const sendMailModel = this.getModel('sendMail');
      const recipients = (sendMailModel.getProperty('/recipients') ?? '').trim();
      const subject = (sendMailModel.getProperty('/subject') ?? '').trim();
      let hasError = false;
      if (!recipients) {
        sendMailModel.setProperty('/recipientsState', 'Error');
        sendMailModel.setProperty('/recipientsStateText', 'Recipients is required.');
        hasError = true;
      } else {
        const {
          invalid
        } = this.validateEmails(recipients);
        if (invalid.length > 0) {
          sendMailModel.setProperty('/recipientsState', 'Error');
          sendMailModel.setProperty('/recipientsStateText', `Invalid email address(es): ${invalid.join(', ')}`);
          hasError = true;
        }
      }
      if (!subject) {
        sendMailModel.setProperty('/subjectState', 'Error');
        sendMailModel.setProperty('/subjectStateText', 'Subject is required.');
        hasError = true;
      } else {
        sendMailModel.setProperty('/subjectState', 'None');
        sendMailModel.setProperty('/subjectStateText', '');
      }
      if (hasError) return;
      const model = this.getModel('versionDetail');
      const prettyXml = model.getProperty('/selectedDetailXml') ?? '';
      const detail = model.getProperty('/selectedDetail');
      if (!prettyXml) {
        MessageBox.error('XML data is not loaded yet. Please wait and try again.');
        return;
      }
      const htmlContent = this.buildVersionHtml(prettyXml, subject, detail);
      const htmlSizeKb = Math.round(htmlContent.length / 1024);
      console.log(`[SendVersionMail] HTML size: ${htmlSizeKb} KB, recipients: "${recipients}"`);
      sendMailModel.setProperty('/busy', true);
      BusyIndicator.show(0);
      try {
        await this.getOwnerComponent().getDetailService().sendEmail({
          htmlContent,
          recipients,
          subject
        });
        this._sendMailDialog?.close();
        MessageBox.success('Email sent successfully.');
      } catch (error) {
        await this.handleServiceError(error);
      } finally {
        sendMailModel.setProperty('/busy', false);
        BusyIndicator.hide();
      }
    },
    onCancelSendMail: function _onCancelSendMail() {
      this._sendMailDialog?.close();
    },
    // ─── Export Schema ───────────────────────────────────────────────────────
    onExportSchema: function _onExportSchema() {
      this.setModel(new JSONModel({
        busy: false,
        selectedFormatIndex: 0
      }), 'exportSchema');
      const loadDialog = async () => {
        if (!this._exportSchemaDialog) {
          this._exportSchemaDialog = await Fragment.load({
            id: this.getView()?.getId(),
            name: 'com.zgp9.fe.view.fragments.ExportSchemaDialog',
            controller: this
          });
          this.getView()?.addDependent(this._exportSchemaDialog);
        }
        this._exportSchemaDialog.open();
      };
      void loadDialog();
    },
    onConfirmExportSchema: async function _onConfirmExportSchema() {
      const exportModel = this.getModel('exportSchema');
      const selectedIndex = exportModel.getProperty('/selectedFormatIndex');
      const formats = ['openapi', 'dart', 'kotlin', 'swift', 'json-schema', 'ts'];
      const extensions = ['json', 'dart', 'kt', 'swift', 'json', 'zip'];
      const format = formats[selectedIndex];
      const ext = extensions[selectedIndex];
      const versionDetailModel = this.getModel('versionDetail');
      const xml = versionDetailModel.getProperty('/selectedDetailXml');
      if (!xml) {
        MessageBox.error('No XML content available to export.');
        return;
      }
      const detail = versionDetailModel.getProperty('/selectedDetail');
      const defaultBaseName = (detail?.serviceDefId || detail?.detailId || 'schema').replace(/[^a-zA-Z0-9_.-]+/g, '_');
      exportModel.setProperty('/busy', true);
      BusyIndicator.show(0);
      try {
        const {
          blob,
          isZip
        } = await this.getOwnerComponent().getDetailService().exportSchema(xml, format);
        const finalExt = isZip ? 'zip' : ext;
        this.downloadFile(`${defaultBaseName}.${finalExt}`, blob);
        this._exportSchemaDialog?.close();
        MessageToast.show('Schema exported successfully.');
      } catch (error) {
        await this.handleServiceError(error);
      } finally {
        exportModel.setProperty('/busy', false);
        BusyIndicator.hide();
      }
    },
    onCancelExportSchema: function _onCancelExportSchema() {
      this._exportSchemaDialog?.close();
    },
    validateEmails: function _validateEmails(raw) {
      const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      const list = raw.split(/[;,]/).map(s => s.trim()).filter(Boolean);
      const valid = [];
      const invalid = [];
      for (const addr of list) {
        (EMAIL_RE.test(addr) ? valid : invalid).push(addr);
      }
      return {
        valid,
        invalid
      };
    },
    highlightForEmail: function _highlightForEmail(line) {
      const indent = /^( +)/.exec(line)?.[1] ?? '';
      const indentHtml = indent.replace(/ /g, '&nbsp;');
      let html = indentHtml + highlightXmlLine(line.slice(indent.length));
      html = html.replace(/class="xmlTokPunct"/g, 'style="color:#00C"').replace(/class="xmlTokTag"/g, 'style="color:#00008B"').replace(/class="xmlTokAttr"/g, 'style="color:#7D0045"').replace(/class="xmlTokVal"/g, 'style="color:#006400"').replace(/class="xmlTokCmt"/g, 'style="color:#6a9955"');
      return html;
    },
    buildVersionHtml: function _buildVersionHtml(prettyXml, title, detail) {
      const escHtml = s => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
      const lines = prettyXml.split('\n');
      const metaRows = detail ? `<tr><td>Service Definition</td><td>${escHtml(detail.serviceDefId || '-')}</td></tr>` + `<tr><td>Version Id</td><td>${escHtml(detail.versionId || '-')}</td></tr>` + `<tr><td>Service Hash</td><td>${escHtml(detail.serviceHash || '-')}</td></tr>` : '';
      const S_NUM = 'style="padding:2px 4px;border:1px solid #eee;color:#aaa;text-align:right;font-family:monospace;font-size:11px;white-space:nowrap;width:4%"';
      const S_XML = 'style="padding:2px 8px;border:1px solid #eee;white-space:pre-wrap;overflow-wrap:break-word;font-family:monospace;font-size:11px;vertical-align:top"';
      const TH = 'style="padding:4px 6px;border:1px solid #ddd;background:#f5f5f5;text-align:left;font-family:sans-serif;font-size:11px"';
      const styledRows = lines.map((line, idx) => `<tr><td ${S_NUM}>${idx + 1}</td><td ${S_XML}>${this.highlightForEmail(line)}</td></tr>`).join('');
      const metaStyle = 'style="padding:2px 12px 2px 0;font-family:sans-serif;font-size:12px"';
      const metaLabelStyle = 'style="padding:2px 12px 2px 0;font-family:sans-serif;font-size:12px;color:#666;white-space:nowrap"';
      const metaTable = metaRows ? `<table style="border-collapse:collapse;margin-bottom:16px"><tbody>` + metaRows.replace(/<td>/g, `<td ${metaStyle}>`).replace(/<td class="[^"]*">/g, `<td ${metaLabelStyle}>`) + `</tbody></table>` : '';
      return `<!DOCTYPE html><html><head><meta charset="utf-8"/></head><body style="margin:8px;font-family:sans-serif;color:#333">` + `<h2 style="margin-bottom:4px">${escHtml(title)}</h2>` + metaTable + `<table style="border-collapse:collapse;width:100%;table-layout:fixed">` + `<colgroup><col style="width:4%"/><col style="width:96%"/></colgroup>` + `<thead><tr><th ${TH}>#</th><th ${TH}>XML Content</th></tr></thead>` + `<tbody>${styledRows}</tbody>` + `</table></body></html>`;
    },
    // ─────────────────────────────────────────────────────────────────────────
    loadVersion: async function _loadVersion(queryDetailId = null) {
      if (!this.registryId || !this.versionId) {
        return;
      }
      const model = this.getModel('versionDetail');
      model.setProperty('/busy', true);
      try {
        const [version, details] = await Promise.all([this.getOwnerComponent().getVersionService().getVersion(this.versionId), this.getOwnerComponent().getDetailService().getDetails(this.versionId)]);
        model.setData({
          busy: false,
          version,
          details,
          selectedDetail: null,
          selectedDetailXml: '',
          selectedDetailBusy: false,
          selectedNodeLine: 1,
          selectedDetailLineStarts: [],
          selectedDetailLines: [],
          treeSearch: '',
          treeSearchMatchCount: 0
        });
        this.fullTree = [];
        this.getModel('treeModel').setData([]);
        if (details.length > 0) {
          const detailToLoad = queryDetailId ? details.find(d => d.detailId === queryDetailId) || details[0] : details[0];
          await this.loadDetailWorkspace(detailToLoad);
        }
      } catch (error) {
        await this.handleServiceError(error);
      } finally {
        model.setProperty('/busy', false);
      }
    },
    loadDetailWorkspace: async function _loadDetailWorkspace(detail) {
      const model = this.getModel('versionDetail');
      model.setProperty('/selectedDetailBusy', true);
      model.setProperty('/selectedDetail', detail);
      model.setProperty('/selectedDetailXml', '');
      model.setProperty('/treeSearch', '');
      model.setProperty('/treeSearchMatchCount', 0);
      this.fullTree = [];
      this.getModel('treeModel').setData([]);
      model.setProperty('/selectedDetailLineStarts', []);
      model.setProperty('/selectedDetailLines', []);
      try {
        const [loadedDetail, parsedDetail, nodeTree] = await Promise.all([this.getOwnerComponent().getDetailService().getDetail(detail.detailId), this.getOwnerComponent().getDetailService().getParsedDetail(detail.detailId), this.getOwnerComponent().getDetailService().getNodeTree(detail.detailId)]);
        let rawXml = parsedDetail.metadataXml || loadedDetail.metadataXml || '';
        // Filter out XML declaration because the backend offsets do not include it
        rawXml = rawXml.replace(/<\?xml[^>]*\?>\s*/gi, '');
        const {
          prettyXml,
          rawOffsets
        } = prettyPrintXml(rawXml);
        const tree = buildNodeTree(nodeTree);
        const root = tree.length > 0 ? tree : this.createFallbackNodeTree(loadedDetail);
        this.applyLineNumbers(root, rawOffsets, prettyXml);
        this.fullTree = root;
        model.setProperty('/selectedDetailXml', prettyXml);
        this.getModel('treeModel').setData(root);
        model.setProperty('/selectedDetailLineStarts', rawOffsets);
        model.setProperty('/selectedDetailLines', this.buildXmlLines(prettyXml));
        model.setProperty('/selectedNodeLine', 1);
        this.selectXmlLine(1);
        this.expandTreeToLevel('versionDetailTree', 1);
      } catch (error) {
        await this.handleServiceError(error);
      } finally {
        model.setProperty('/selectedDetailBusy', false);
      }
    },
    expandAllTreeNodes: function _expandAllTreeNodes(treeId) {
      const tree = this.byId(treeId);
      if (!tree) {
        return;
      }
      tree.attachEventOnce('updateFinished', () => {
        const binding = tree.getBinding('items');
        if (!binding || typeof binding.expand !== 'function') {
          return;
        }
        let index = 0;
        let iterations = 0;
        while (index < binding.getLength() && iterations < 100000) {
          iterations += 1;
          if (typeof binding.isExpanded === 'function' && !binding.isExpanded(index)) {
            binding.expand(index);
          }
          index += 1;
        }
      });
    },
    expandTreeToLevel: function _expandTreeToLevel(treeId, level) {
      const tree = this.byId(treeId);
      if (!tree) {
        return;
      }
      tree.attachEventOnce('updateFinished', () => {
        if (typeof tree.expandToLevel === 'function') {
          tree.expandToLevel(level);
        }
      });
    },
    copyTextToClipboard: async function _copyTextToClipboard(text) {
      if (navigator.clipboard && window.isSecureContext) {
        try {
          await navigator.clipboard.writeText(text);
          return true;
        } catch {
          // fall through to the legacy fallback below
        }
      }
      try {
        const textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.focus();
        textarea.select();
        const success = document.execCommand('copy');
        document.body.removeChild(textarea);
        return success;
      } catch {
        return false;
      }
    },
    downloadFile: function _downloadFile(fileName, blob) {
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    },
    createFallbackNodeTree: function _createFallbackNodeTree(detail) {
      return buildNodeTree([{
        nodeId: detail.detailId,
        semanticId: detail.serviceDefId || detail.detailId,
        parentId: '',
        nodePath: '1',
        nodeType: 'Detail',
        nodeName: detail.serviceDefId || 'Detail',
        nodeAlias: '',
        offsetStart: 0,
        offsetEnd: detail.metadataXml.length,
        seq: 1,
        depth: 0,
        attributes: []
      }]);
    },
    applyLineNumbers: function _applyLineNumbers(nodes, lineStarts, xml) {
      for (const node of nodes) {
        node.lineStart = offsetToLine(node.offsetStart, lineStarts);
        node.lineEnd = offsetToLine(node.offsetEnd, lineStarts);
        if (node.lineStart <= 1 && xml.length > 0) {
          node.lineStart = 1;
        }
        if (node.children.length > 0) {
          this.applyLineNumbers(node.children, lineStarts, xml);
        }
      }
    },
    buildXmlLines: function _buildXmlLines(xml) {
      return xml.split('\n').map((text, index) => ({
        lineNo: index + 1,
        text,
        isWhitespace: text.trim().length === 0
      }));
    },
    selectXmlLine: function _selectXmlLine(lineNo) {
      const model = this.getModel('versionDetail');
      model.setProperty('/selectedNodeLine', lineNo);
      const table = this.byId('selectedDetailXmlTable');
      if (!table) {
        return;
      }
      const triggerGrowToLine = () => {
        const growingTable = table;
        const growingInfo = growingTable.getGrowingInfo?.();
        const currentActual = growingInfo?.actual || 0;
        if (lineNo > currentActual) {
          const delegate = growingTable._oGrowingDelegate;
          if (delegate && typeof delegate.requestNewPage === 'function') {
            const onUpdateFinished = () => {
              table.detachEvent('updateFinished', onUpdateFinished);
              triggerGrowToLine();
            };
            table.attachEvent('updateFinished', onUpdateFinished);
            delegate.requestNewPage();
            return;
          }
        }

        // Item should be rendered now, give it a tiny bit of time for DOM layout
        setTimeout(() => {
          this.scrollToItem(table, lineNo);
        }, 100);
      };
      triggerGrowToLine();
    },
    // private scrollXmlToLine(line: number): void {
    // 	this.selectXmlLine(line);
    // }
    scrollToItem: function _scrollToItem(table, lineNo) {
      table.getItems().forEach(item => {
        item.removeStyleClass('versionDetailXmlHighlighted');
      });
      const item = table.getItems().find(listItem => {
        const context = listItem.getBindingContext('versionDetail');
        return context?.getObject()?.lineNo === lineNo;
      });
      if (item) {
        item.addStyleClass('versionDetailXmlHighlighted');
        item.getDomRef()?.scrollIntoView({
          block: 'center',
          inline: 'nearest'
        });
        if (this.highlightClearTimer !== null) {
          window.clearTimeout(this.highlightClearTimer);
        }
        this.highlightClearTimer = window.setTimeout(() => {
          table.getItems().forEach(row => row.removeStyleClass('versionDetailXmlHighlighted'));
          this.highlightClearTimer = null;
        }, 1400);
      }
    }
  });
  return VersionDetail;
});
//# sourceMappingURL=VersionDetail-dbg.controller.js.map
