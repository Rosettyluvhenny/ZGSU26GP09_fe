sap.ui.define(["./SessionStorage", "./ODataClient"], function (___SessionStorage, __ODataClient) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const readSessionStorage = ___SessionStorage["readSessionStorage"];
  const ODataClient = _interopRequireDefault(__ODataClient);
  const EMPTY_SESSION = {
    authenticated: false,
    userName: '',
    csrfToken: '',
    loginAt: null
  };
  function delay(value, ms = 250) {
    return new Promise(resolve => {
      setTimeout(() => resolve(value), ms);
    });
  }
  class AuthenticationService {
    constructor(model) {
      this.model = model;
    }
    async getSession() {
      return delay(readSessionStorage(EMPTY_SESSION), 50);
    }
    async fetchCsrfToken() {
      return ODataClient.refreshCsrfToken();
    }
  }
  return AuthenticationService;
});
//# sourceMappingURL=AuthenticationService-dbg.js.map
