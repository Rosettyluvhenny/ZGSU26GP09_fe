sap.ui.define(["./ODataClient", "./ServiceError", "./ODataParsers"], function (___ODataClient, __ServiceError, ___ODataParsers) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const createODataClient = ___ODataClient["createODataClient"];
  const ServiceError = _interopRequireDefault(__ServiceError);
  const mapDetailEntity = ___ODataParsers["mapDetailEntity"];
  function normalizeGuid(value) {
    return value.replace(/[{}]/g, '').trim();
  }
  function formatGuidLiteral(value) {
    return normalizeGuid(value);
  }
  function asString(value) {
    if (value === null || value === undefined) {
      return '';
    }
    const primitive = value;
    return String(primitive);
  }
  function asNumber(value) {
    const numeric = Number(value);
    return Number.isFinite(numeric) ? numeric : 0;
  }
  function mapNodeTreeItem(item) {
    return {
      nodeId: asString(item.NODE_ID),
      semanticId: asString(item.SEMANTIC_ID),
      parentId: asString(item.PARENT_ID),
      nodePath: asString(item.NODE_PATH),
      nodeType: asString(item.NODE_TYPE),
      nodeName: asString(item.NODE_NAME),
      nodeAlias: asString(item.NODE_ALIAS),
      offsetStart: asNumber(item.OFFSET_START),
      offsetEnd: asNumber(item.OFFSET_END),
      seq: asNumber(item.SEQ),
      depth: asNumber(item.DEPTH),
      attributes: Array.isArray(item.ATTRIBUTES) ? item.ATTRIBUTES.map(attribute => ({
        name: asString(attribute.NAME),
        value: asString(attribute.VALUE)
      })) : []
    };
  }
  function mapNodeDiffItem(item) {
    return {
      semanticId: asString(item.SEMANTIC_ID),
      status: asString(item.STATUS),
      attributeDiff: Array.isArray(item.ATTRIBUTEDIFF) ? item.ATTRIBUTEDIFF.map(attribute => ({
        semanticId: asString(attribute.SEMANTIC_ID),
        name: asString(attribute.NAME),
        status: asString(attribute.STATUS),
        oldValue: asString(attribute.OLD_VALUE),
        newValue: asString(attribute.NEW_VALUE)
      })) : []
    };
  }
  class DetailService {
    constructor(model) {
      this.odata = createODataClient(model);
    }
    async getDetails(versionId) {
      return this.loadDetailsFromBackend(versionId);
    }
    async getDetail(detailId) {
      const backendDetail = await this.loadDetailFromBackend(detailId);
      if (!backendDetail) {
        throw new ServiceError(404, 'Detail not found.');
      }
      return backendDetail;
    }
    async getParsedDetail(detailId) {
      const parsedDetail = await this.loadParsedMetadataFromBackend(detailId);
      if (parsedDetail) {
        return parsedDetail;
      }
      const detail = await this.getDetail(detailId);
      return {
        detailId: detail.detailId,
        metadataXml: detail.metadataXml
      };
    }
    async getNodeTree(detailId) {
      const payload = await this.odata.callAction('com.sap.gateway.srvd_a2x.zsr_registry.v0001.getNodeTree(...)', {
        context: this.odata.getHeaderContext('/Detail'),
        parameters: {
          DetailId: detailId
        }
      });
      const results = payload?.value || payload?.NODETREE || payload?.NodeTree || payload?.nodeTree || payload;
      if (Array.isArray(results)) {
        return results.map(mapNodeTreeItem);
      }
      return [];
    }
    async compareNodeTree(baseDetailId, compareDetailId) {
      const payload = await this.odata.callAction('com.sap.gateway.srvd_a2x.zsr_registry.v0001.compareNodeTree(...)', {
        context: this.odata.getHeaderContext('/Detail'),
        parameters: {
          BaseDetailId: baseDetailId,
          CompareDetailId: compareDetailId
        }
      });
      const results = payload?.value || payload?.NODEDIFF || payload?.NodeDiff || payload?.nodeDiff || payload;
      if (Array.isArray(results)) {
        return results.map(mapNodeDiffItem);
      }
      return [];
    }
    async loadDetailsFromBackend(versionId) {
      const entities = await this.odata.readList(`/Version(VersionId=${formatGuidLiteral(versionId)})/_Detail`);
      return entities.map(entity => mapDetailEntity(entity));
    }
    async loadDetailFromBackend(detailId) {
      const entity = await this.odata.readOne(`/Detail/${formatGuidLiteral(detailId)}`);
      if (!entity) {
        return null;
      }
      return mapDetailEntity(entity);
    }
    async loadParsedMetadataFromBackend(detailId) {
      const entity = await this.odata.callAction('com.sap.gateway.srvd_a2x.zsr_registry.v0001.getParseMetadata(...)', {
        context: this.odata.getHeaderContext('/Detail'),
        parameters: {
          DetailId: detailId
        }
      });
      if (!entity || !Object.keys(entity).length) {
        return null;
      }
      return {
        detailId: asString(entity.DetailId) || detailId,
        metadataXml: asString(entity.MetadataXml) || asString(entity.metadataXml)
      };
    }
    async sendEmail(params) {
      const entity = await this.odata.callAction('com.sap.gateway.srvd_a2x.zsr_registry.v0001.sendEmail(...)', {
        context: this.odata.getHeaderContext('/Detail'),
        parameters: {
          HtmlContent: params.htmlContent,
          Recipients: params.recipients,
          Subject: params.subject
        }
      });
      // Backend returns PascalCase per ZI_EMAIL_SEND_RESULT complex type
      return {
        success: !!(entity.Success ?? entity.success),
        message: asString(entity.Message ?? entity.message),
        failedRecip: asString(entity.FailedRecip ?? entity.failedRecip),
        recipientDetail: asString(entity.RecipientDetail ?? entity.recipientDetail)
      };
    }
    async exportSchema(xml, format) {
      console.log(`[ExportSchema] Sending XML payload of length ${xml.length} for format: ${format}`);
      const response = await fetch(`/convert/${format}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/xml'
        },
        body: xml
      });
      if (!response.ok) {
        const text = await response.text();
        throw new Error(`Export failed: ${response.status} ${text}`);
      }
      const contentType = response.headers.get('Content-Type') || '';
      const isZip = contentType.includes('zip') || format === 'ts';
      const rawBlob = await response.blob();
      return {
        blob: isZip ? new Blob([rawBlob], {
          type: 'application/zip'
        }) : rawBlob,
        isZip
      };
    }
  }
  return DetailService;
});
//# sourceMappingURL=DetailService-dbg.js.map
