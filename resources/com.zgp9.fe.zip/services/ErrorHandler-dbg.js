sap.ui.define(["sap/m/MessageBox", "./ServiceError", "./ODataClient"], function (MessageBox, __ServiceError, __ODataClient) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const ServiceError = _interopRequireDefault(__ServiceError);
  const ODataClient = _interopRequireDefault(__ODataClient);
  class ErrorHandler {
    handlingAuthError = false;
    constructor(router) {
      this.router = router;
    }
    async handle(error) {
      if (error instanceof ServiceError) {
        if (error.status === 401 || error.status === 403) {
          if (this.handlingAuthError) {
            return;
          }
          this.handlingAuthError = true;
          if (error.status === 403) {
            try {
              await ODataClient.refreshCsrfToken();
              this.handlingAuthError = false;
              return; // Recovered from 403 — retry on next request
            } catch {
              // Fall through to navigate to login
            }
          }
          ODataClient.clearSecurityState();
          this.router.navTo("login", undefined, undefined, true);
          const message = error.status === 403 ? "Your session expired. Please sign in again." : "Your session expired. Please sign in again.";
          MessageBox.error(message, {
            onClose: () => {
              this.handlingAuthError = false;
            }
          });
          return;
        }
        if (error.status === 500) {
          MessageBox.error(error.message || "An internal server error occurred.");
          return;
        }
        if (error.details.length > 0) {
          MessageBox.error([error.message, ...error.details].join("\n"));
          return;
        }
        MessageBox.error(error.message || "The operation could not be completed.");
        return;
      }
      MessageBox.error("An unexpected error occurred.");
    }
  }
  return ErrorHandler;
});
//# sourceMappingURL=ErrorHandler-dbg.js.map
