sap.ui.define(["sap/ui/model/Sorter", "./ServiceError", "./ODataClient", "./ODataParsers"], function (Sorter, __ServiceError, ___ODataClient, ___ODataParsers) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const ServiceError = _interopRequireDefault(__ServiceError);
  const createODataClient = ___ODataClient["createODataClient"];
  const mapJobEntity = ___ODataParsers["mapJobEntity"];
  function delay(value, ms = 250) {
    return new Promise(resolve => {
      setTimeout(() => resolve(value), ms);
    });
  }
  function normalizeGuid(value) {
    return value.replace(/[{}]/g, '').trim();
  }
  class JobService {
    constructor(model) {
      this.odata = createODataClient(model);
    }
    async getJobs(search = '') {
      const backendJobs = await this.loadJobsFromBackend();
      return delay(this.filterJobs(backendJobs, search));
    }
    async getJob(jobId) {
      const backendJob = await this.loadJobFromBackend(jobId);
      if (!backendJob) {
        throw new ServiceError(404, 'Job not found.');
      }
      return delay(backendJob);
    }
    async runScanJob() {
      // runScan is bound to the ScanJob collection (no key in the path) ->
      // bind the action to the list binding's header context.
      const oHeaderContext = this.odata.getHeaderContext('/ScanJob');
      const entity = await this.odata.callAction('com.sap.gateway.srvd_a2x.zsr_registry.v0001.runScan(...)', {
        context: oHeaderContext
      });
      if (!entity || !Object.keys(entity).length) {
        throw new ServiceError(500, 'Invalid response from runScan action.');
      }
      return delay(mapJobEntity(entity));
    }
    filterJobs(jobs, search) {
      const normalized = search.trim().toLowerCase();
      const filtered = jobs.filter(jobItem => {
        if (!normalized) {
          return true;
        }
        return [jobItem.scanJobId, jobItem.triggerType, jobItem.status, jobItem.triggeredBy, jobItem.summary].join(' ').toLowerCase().includes(normalized);
      });
      return filtered;
    }
    async loadJobsFromBackend() {
      const entities = await this.odata.readList('/ScanJob', {
        sorters: [new Sorter('StartedAt', true)]
      });
      return entities.map(entity => mapJobEntity(entity));
    }
    async loadJobFromBackend(jobId) {
      const entity = await this.odata.readOne(`/ScanJob(guid'${normalizeGuid(jobId)}')`);
      if (!entity) {
        return null;
      }
      return mapJobEntity(entity);
    }
  }
  return JobService;
});
//# sourceMappingURL=JobService-dbg.js.map
