sap.ui.define(["sap/ui/model/Filter", "sap/ui/model/FilterOperator", "./ODataClient", "./ODataParsers"], function (Filter, FilterOperator, ___ODataClient, ___ODataParsers) {
  "use strict";

  const createODataClient = ___ODataClient["createODataClient"];
  const mapLogEntity = ___ODataParsers["mapLogEntity"];
  const LOG_PAGE_SIZE = 50;
  function delay(value, ms = 250) {
    return new Promise(resolve => {
      setTimeout(() => resolve(value), ms);
    });
  }
  function normalizeGuid(value) {
    return value.replace(/[{}]/g, '').trim();
  }
  function toODataDateTime(date) {
    return date.toISOString().replace(/\.\d{3}Z$/, 'Z');
  }
  class LogService {
    constructor(model) {
      this.odata = createODataClient(model);
    }
    async getLogs(filter = {}) {
      const top = filter.top ?? LOG_PAGE_SIZE;
      const skip = filter.skip ?? 0;
      const {
        items: entities,
        count
      } = await this.odata.readListWithCount('/Log', {
        filters: this.buildLogFilters(filter),
        parameters: {
          '$orderby': 'ActionAt desc'
        },
        top,
        skip
      });
      const items = entities.map(entity => mapLogEntity(entity));
      const totalCount = Number.isFinite(count) ? count : skip + items.length;
      return delay({
        items,
        totalCount,
        hasMore: skip + items.length < totalCount && items.length > 0
      });
    }

    /** @deprecated Use getLogs({ jobId }) instead */
    async getLogsByJobId(jobId) {
      return this.getLogs({
        jobId
      });
    }
    buildLogFilters(filter) {
      const filters = [];
      if (filter.jobId) {
        filters.push(new Filter('JobId', FilterOperator.EQ, normalizeGuid(filter.jobId)));
      }
      if (filter.actionType && filter.actionType !== 'All') {
        filters.push(new Filter('ActionType', FilterOperator.EQ, filter.actionType));
      }
      if (filter.logResult && filter.logResult !== 'All') {
        filters.push(new Filter('LogResult', FilterOperator.EQ, filter.logResult));
      }
      if (filter.objectIdType && filter.objectIdType !== 'All') {
        filters.push(new Filter('objectIdType', FilterOperator.EQ, filter.objectIdType));
      }
      if (filter.dateFrom) {
        const from = new Date(filter.dateFrom);
        from.setHours(0, 0, 0, 0);
        filters.push(new Filter('ActionAt', FilterOperator.GE, toODataDateTime(from)));
      }
      if (filter.dateTo) {
        const to = new Date(filter.dateTo);
        to.setHours(23, 59, 59, 999);
        filters.push(new Filter('ActionAt', FilterOperator.LE, toODataDateTime(to)));
      }
      if (filter.search?.trim()) {
        const raw = filter.search.trim();
        const normalizedGuid = raw.replace(/[{}]/g, '');
        const looksLikeGuid = /^[0-9a-fA-F]{8}-?[0-9a-fA-F]{4}-?[0-9a-fA-F]{4}-?[0-9a-fA-F]{4}-?[0-9a-fA-F]{12}$/.test(normalizedGuid);
        const objectTypeTerm = raw.toUpperCase();
        const knownObjectTypes = ['REGISTRY', 'DETAIL', 'VERSION', 'SCANJOB'];
        if (looksLikeGuid) {
          filters.push(new Filter('ObjectId', FilterOperator.EQ, normalizedGuid));
        } else if (knownObjectTypes.includes(objectTypeTerm)) {
          // Avoid duplicating objectIdType filter when the dropdown already selected the same value.
          if (!filter.objectIdType || filter.objectIdType === 'All' || filter.objectIdType.toUpperCase() !== objectTypeTerm) {
            filters.push(new Filter('objectIdType', FilterOperator.EQ, objectTypeTerm));
          }
        } else {
          filters.push(new Filter({
            filters: [new Filter('Remarks', FilterOperator.Contains, raw), new Filter('Actor', FilterOperator.Contains, raw)],
            and: false
          }));
        }
      }
      return filters;
    }
  }
  LogService.LOG_PAGE_SIZE = LOG_PAGE_SIZE;
  return LogService;
});
//# sourceMappingURL=LogService-dbg.js.map
