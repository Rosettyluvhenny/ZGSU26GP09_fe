sap.ui.define(["./ServiceError"], function (__ServiceError) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const ServiceError = _interopRequireDefault(__ServiceError); // ---------------------------------------------------------------------------
  // NOTE: No CSRF token / auth-header handling here.
  // Authentication is done via principal propagation (reverse proxy / SSO),
  // and CSRF tokens for mutating requests are managed internally by
  // sap.ui.model.odata.v4.ODataModel. There is nothing to fetch, cache, or
  // refresh manually — every call below is a direct, synchronous-looking
  // wrapper around the model's own request queue.
  // ---------------------------------------------------------------------------
  function toServiceError(error, context) {
    const err = error;
    const message = err?.error?.message || err?.cause?.message || err?.message || `${context} failed.`;
    return new ServiceError(err?.status ?? 500, message);
  }

  /**
   * True when a rejection looks like a CSRF-token failure that survived the
   * model's own internal fetch-and-retry. At this point retrying the exact
   * same request again won't help on its own — the session/token needs to be
   * re-established first (see withCsrfRetry below).
   */
  function isCsrfFailure(error) {
    const err = error;
    return err?.status === 403 && /csrf/i.test(err?.message ?? '');
  }

  /**
   * Wraps a write/action operation so that, if it fails with a CSRF error
   * (the model already retried once internally and still failed), we force a
   * model refresh to re-establish a fresh CSRF token/session and retry the
   * operation exactly once more before giving up.
   */
  async function withCsrfRetry(model, operation) {
    try {
      return await operation();
    } catch (error) {
      if (!isCsrfFailure(error)) {
        throw error;
      }
      model.refresh();
      return operation();
    }
  }

  /**
   * Creates a lightweight functional wrapper around an existing ODataModel v4
   * instance. No shared/static state, no CSRF handling — just domain-shaped
   * read/write/action helpers translated to the model's bindList/bindContext API.
   */
  function createODataClient(model) {
    function bindContextAt(path) {
      return model.bindContext(path).getBoundContext();
    }
    async function readList(path, options = {}) {
      try {
        const oListBinding = model.bindList(path, undefined, options.sorters, options.filters, options.parameters);
        const aContexts = await oListBinding.requestContexts(options.skip, options.top);
        return aContexts.map(oContext => oContext.getObject());
      } catch (error) {
        throw toServiceError(error, `readList ${path}`);
      }
    }

    /**
     * Same as readList, but also requests the server-side total count
     * (equivalent to $count=true). Use this for paged lists where you need
     * to know "how many more" beyond the current page.
     */
    async function readListWithCount(path, options = {}) {
      try {
        const oListBinding = model.bindList(path, undefined, options.sorters, options.filters, {
          ...options.parameters,
          '$count': 'true'
        });
        const aContexts = await oListBinding.requestContexts(options.skip, options.top);
        const items = aContexts.map(oContext => oContext.getObject());
        const count = oListBinding.getCount() ?? items.length;
        return {
          items,
          count
        };
      } catch (error) {
        throw toServiceError(error, `readListWithCount ${path}`);
      }
    }
    async function readOne(path) {
      try {
        const oContext = bindContextAt(path);
        const entity = await oContext.requestObject();
        if (!entity || !Object.keys(entity).length) {
          return null;
        }
        return entity;
      } catch (error) {
        throw toServiceError(error, `readOne ${path}`);
      }
    }
    async function create(collectionPath, payload) {
      try {
        return await withCsrfRetry(model, async () => {
          const oListBinding = model.bindList(collectionPath);
          const oContext = oListBinding.create(payload);
          await oContext.created();
          return oContext.getObject();
        });
      } catch (error) {
        throw toServiceError(error, `create ${collectionPath}`);
      }
    }
    async function update(entityPath, patch, groupId = '$auto') {
      try {
        return await withCsrfRetry(model, async () => {
          const oContext = bindContextAt(entityPath);
          for (const [field, value] of Object.entries(patch)) {
            await oContext.setProperty(field, value);
          }
          await model.submitBatch(groupId);
          return oContext.getObject();
        });
      } catch (error) {
        throw toServiceError(error, `update ${entityPath}`);
      }
    }
    async function updateContext(context, patch, groupId = '$auto') {
      try {
        return await withCsrfRetry(model, async () => {
          for (const [field, value] of Object.entries(patch)) {
            await context.setProperty(field, value);
          }
          await model.submitBatch(groupId);
          return context.getObject();
        });
      } catch (error) {
        throw toServiceError(error, 'update context');
      }
    }
    async function remove(entityPath) {
      try {
        await withCsrfRetry(model, async () => {
          const oContext = bindContextAt(entityPath);
          await oContext.delete();
        });
      } catch (error) {
        throw toServiceError(error, `remove ${entityPath}`);
      }
    }
    async function removeContext(context) {
      try {
        await withCsrfRetry(model, () => context.delete());
      } catch (error) {
        throw toServiceError(error, 'remove context');
      }
    }

    /**
     * Calls a bound or unbound action/function.
     * - Unbound: pass an operation path like "/actionName(...)" with no context.
     * - Entity-bound: pass "namespace.actionName(...)" plus the entity's Context.
     * - Collection-bound: pass "namespace.actionName(...)" plus a list binding's
     *   header context (listBinding.getHeaderContext()).
     */
    async function callAction(operationPath, options = {}) {
      try {
        return await withCsrfRetry(model, async () => {
          const oOperation = model.bindContext(operationPath, options.context);
          if (options.parameters) {
            for (const [name, value] of Object.entries(options.parameters)) {
              oOperation.setParameter(name, value);
            }
          }
          await oOperation.execute();
          return oOperation.getBoundContext()?.getObject();
        });
      } catch (error) {
        throw toServiceError(error, `callAction ${operationPath}`);
      }
    }
    function getHeaderContext(collectionPath) {
      const oListBinding = model.bindList(collectionPath);
      return oListBinding.getHeaderContext();
    }
    function bindEntity(entityPath) {
      return bindContextAt(entityPath);
    }
    function refresh(context) {
      if (context) {
        context.refresh();
      } else {
        model.refresh();
      }
    }
    return {
      readList,
      readListWithCount,
      readOne,
      create,
      update,
      updateContext,
      remove,
      removeContext,
      callAction,
      getHeaderContext,
      bindEntity,
      refresh
    };
  }
  var __exports = {
    __esModule: true
  };
  __exports.createODataClient = createODataClient;
  return __exports;
});
//# sourceMappingURL=ODataClient-dbg.js.map
