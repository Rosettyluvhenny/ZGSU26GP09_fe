sap.ui.define(["./ServiceError"], function (__ServiceError) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const ServiceError = _interopRequireDefault(__ServiceError);
  const SERVICE_ORIGIN = '/sap/opu/odata4/sap/zsb_gsugp9/srvd_a2x/sap/zsr_registry/0001';
  const SERVICE_BASE_URL = `${SERVICE_ORIGIN}/`;
  const SERVICE_METADATA_URL = `${SERVICE_ORIGIN}/$metadata`;
  class ODataClient {
    static csrfToken = '';
    static etag = '*';
    static authPromise = null;
    static setSecurityState(csrfToken, etag) {
      if (csrfToken) ODataClient.csrfToken = csrfToken;
      if (etag) ODataClient.etag = etag;
    }
    static clearSecurityState() {
      ODataClient.csrfToken = '';
      ODataClient.etag = '*';
      ODataClient.authPromise = null;
    }
    static async refreshCsrfToken() {
      if (ODataClient.authPromise !== null) {
        return ODataClient.authPromise;
      }
      ODataClient.authPromise = (async () => {
        const response = await fetch(SERVICE_BASE_URL, {
          method: 'GET',
          credentials: 'include',
          headers: {
            Accept: 'application/json',
            'X-CSRF-Token': 'Fetch'
          }
        });
        if (!response.ok) {
          ODataClient.authPromise = null;
          throw new ServiceError(response.status, `CSRF fetch failed (${response.status})`);
        }
        const token = response.headers.get('x-csrf-token') ?? response.headers.get('X-CSRF-Token') ?? '';
        const etag = response.headers.get('etag');
        ODataClient.setSecurityState(token, etag || undefined);
        return ODataClient.csrfToken;
      })();
      try {
        await ODataClient.authPromise;
      } catch (error) {
        ODataClient.authPromise = null;
        throw error;
      }
      return ODataClient.authPromise;
    }
    static async ensureAuth() {
      if (ODataClient.csrfToken) {
        return;
      }
      await ODataClient.refreshCsrfToken();
    }
    buildUrl(path, query) {
      const normalizedPath = path.startsWith('http://') || path.startsWith('https://') || path.startsWith(SERVICE_ORIGIN) ? path : `${SERVICE_ORIGIN}${path.startsWith('/') ? path : `/${path}`}`;
      const url = new URL(normalizedPath, window.location.origin);
      const mergedQuery = {
        ...DEFAULT_QUERY,
        ...(query ?? {})
      };
      for (const [key, value] of Object.entries(mergedQuery)) {
        if (value === null || value === undefined || value === '') {
          continue;
        }
        url.searchParams.set(key, String(value));
      }
      return url.toString();
    }
    async requestJson(path, options = {}) {
      await ODataClient.ensureAuth();
      const response = await fetch(this.buildUrl(path, options.query), {
        method: 'GET',
        credentials: 'include',
        cache: 'no-store',
        headers: {
          Accept: 'application/json',
          'Cache-Control': 'no-cache',
          Pragma: 'no-cache',
          ...options.headers
        }
      });
      if (!response.ok) {
        throw new ServiceError(response.status, `GET ${path} failed (${response.status})`);
      }
      const text = await response.text();
      if (!text) {
        return {};
      }
      try {
        return JSON.parse(text);
      } catch {
        return {};
      }
    }
    async requestText(path, options = {}) {
      await ODataClient.ensureAuth();
      const response = await fetch(this.buildUrl(path, options.query), {
        method: 'GET',
        credentials: 'include',
        headers: {
          Accept: 'application/xml, text/xml, application/json',
          ...options.headers
        }
      });
      if (!response.ok) {
        throw new ServiceError(response.status, `GET ${path} failed (${response.status})`);
      }
      return response.text();
    }
    async requestWriteJson(path, method, body, options = {}) {
      await ODataClient.ensureAuth();
      const response = await fetch(this.buildUrl(path, options.query), {
        method,
        credentials: 'include',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
          ...options.headers
        },
        body: body === undefined ? undefined : JSON.stringify(body)
      });
      if (!response.ok) {
        throw new ServiceError(response.status, `${method} ${path} failed (${response.status})`);
      }
      const text = await response.text();
      if (!text) {
        return {};
      }
      try {
        return JSON.parse(text);
      } catch {
        return {};
      }
    }
    async readJson(path, options = {}) {
      return this.requestJson(path, options);
    }
    async readText(path, options = {}) {
      return this.requestText(path, options);
    }
    async postJson(path, body, options = {}) {
      return this.requestWriteJson(path, 'POST', body, options);
    }
    async refreshCsrfToken() {
      return ODataClient.refreshCsrfToken();
    }
    clearSecurityState() {
      ODataClient.clearSecurityState();
    }
    async fetchCsrfToken() {
      if (ODataClient.csrfToken) {
        return ODataClient.csrfToken;
      }
      return await this.refreshCsrfToken();
    }
    async ensureWriteHeaders(method, etag) {
      const csrfToken = await this.fetchCsrfToken();
      const headers = {
        'X-CSRF-Token': csrfToken
      };
      if (method === 'PATCH' || method === 'DELETE') {
        headers['If-Match'] = etag ?? ODataClient.etag ?? '*';
      }
      return headers;
    }
  }
  ODataClient.SERVICE_ORIGIN = SERVICE_ORIGIN;
  ODataClient.SERVICE_BASE_URL = SERVICE_BASE_URL;
  ODataClient.SERVICE_METADATA_URL = SERVICE_METADATA_URL;
  return ODataClient;
});
//# sourceMappingURL=ODataClient-dbg.js.map
