sap.ui.define(["sap/ui/model/Filter", "sap/ui/model/FilterOperator", "sap/ui/model/Sorter", "./ServiceError", "./ODataParsers"], function (Filter, FilterOperator, Sorter, __ServiceError, ___ODataParsers) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const ServiceError = _interopRequireDefault(__ServiceError);
  const mapRegistryEntity = ___ODataParsers["mapRegistryEntity"];
  function delay(value, ms = 250) {
    return new Promise(resolve => {
      setTimeout(() => resolve(value), ms);
    });
  }
  function asString(value) {
    if (value === null || value === undefined) {
      return '';
    }
    const primitive = value;
    return String(primitive);
  }
  function extractServiceError(error, context) {
    // v4 ODataModel operation/binding rejections carry .cause / .message / status varies by version
    const err = error;
    const message = err?.error?.message || err?.cause?.message || err?.message || `${context} failed.`;
    return new ServiceError(err?.status ?? 500, message);
  }
  class RegistryService {
    constructor(model) {
      this.model = model;
    }

    // ---------------------------------------------------------------------
    // Value helps / read-only lookups
    // ---------------------------------------------------------------------

    async getPermissions() {
      try {
        // Action bound to the Registry collection (no specific key) -> bind on the
        // list binding's header context.
        const oListBinding = this.model.bindList('/Registry');
        const oHeaderContext = oListBinding.getHeaderContext();
        const oOperation = this.model.bindContext('com.sap.gateway.srvd_a2x.zsr_registry.v0001.getPermissions(...)', oHeaderContext);
        await oOperation.execute();
        const result = oOperation.getBoundContext()?.getObject();
        const permissions = this.mapPermissionNames(result);
        if (permissions.length === 0) {
          throw new ServiceError(500, 'Permission response did not contain any permissions.');
        }
        return delay(permissions);
      } catch (error) {
        if (error instanceof ServiceError) {
          throw error;
        }
        throw extractServiceError(error, 'getPermissions');
      }
    }
    async getGroupTypes() {
      const items = await this.readValueHelpList('/ZI_GRP_TYPE_VH', ['TypeId']);
      return delay(items);
    }
    async getStatuses() {
      const items = await this.readValueHelpList('/ZI_GRP_STAT_VH', ['StatusId']);
      return delay(items);
    }

    // ---------------------------------------------------------------------
    // Registry CRUD
    // ---------------------------------------------------------------------

    async getRegistries(filter) {
      const backendRegistries = await this.loadRegistriesFromBackend(filter);
      return delay(this.filterRegistries(backendRegistries, filter));
    }
    async getRegistry(registryId) {
      const backendRegistry = await this.loadRegistryFromBackend(registryId);
      if (!backendRegistry) {
        throw new ServiceError(404, 'Registry not found.');
      }
      return delay(backendRegistry);
    }
    async createRegistry(input) {
      const validationMessages = this.validateCreateInput(input);
      if (validationMessages.length > 0) {
        throw new ServiceError(400, 'Registry validation failed.', validationMessages);
      }
      const payload = {
        GroupName: input.groupName.trim(),
        GroupType: input.groupType.trim()
      };
      if (input.versionNo.trim()) {
        payload.VersionNo = input.versionNo.trim();
      }
      try {
        const oListBinding = this.model.bindList('/Registry');
        const oContext = oListBinding.create(payload);
        await oContext.created();
        const entity = oContext.getObject();
        return delay(mapRegistryEntity(entity, {
          serviceDefinition: ''
        }));
      } catch (error) {
        throw extractServiceError(error, 'createRegistry');
      }
    }
    async updateRegistry(registryId, input) {
      const validationMessages = this.validateUpdateInput(input);
      if (validationMessages.length > 0) {
        throw new ServiceError(400, 'Registry validation failed.', validationMessages);
      }
      return this.changeStatus(registryId, input.status.trim());
    }
    async deleteRegistry(registryId) {
      try {
        const oContext = this.getRegistryContext(registryId);
        await oContext.delete();
        await delay(undefined);
      } catch (error) {
        throw extractServiceError(error, 'deleteRegistry');
      }
    }
    async activateRegistry(registryId) {
      return this.changeStatus(registryId, 'Published');
    }
    async deactivateRegistry(registryId) {
      return this.changeStatus(registryId, 'Unpublished');
    }
    async generateVersion(registryId) {
      try {
        const oRegistryContext = this.getRegistryContext(registryId);
        const oOperation = this.model.bindContext('com.sap.gateway.srvd_a2x.zsr_registry.v0001.generateVersion(...)', oRegistryContext);
        await oOperation.execute();
        const result = oOperation.getBoundContext()?.getObject();
        return delay(result, 350);
      } catch (error) {
        throw extractServiceError(error, 'generateVersion');
      }
    }

    // ---------------------------------------------------------------------
    // Internal helpers
    // ---------------------------------------------------------------------

    getRegistryContext(registryId) {
      const path = `/Registry(${registryId})`;
      return this.model.bindContext(path).getBoundContext();
    }
    async readValueHelpList(path, keyFields) {
      try {
        const oListBinding = this.model.bindList(path);
        const aContexts = await oListBinding.requestContexts();
        const entities = aContexts.map(oContext => oContext.getObject());
        return this.toValueHelpItems(entities, keyFields);
      } catch (error) {
        throw extractServiceError(error, `read ${path}`);
      }
    }
    toValueHelpItems(entities, keyFields) {
      return entities.map(entity => {
        const key = keyFields.map(field => asString(entity[field])).find(value => Boolean(value)) ?? '';
        const text = asString(entity.Description) || asString(entity.Text) || key;
        return {
          key,
          text
        };
      }).filter(item => Boolean(item.key));
    }
    mapPermissionNames(payload) {
      const record = payload;
      const collection = record?.value ?? record?.Set ?? [];
      const values = collection.map(entity => asString(entity.Permission) || asString(entity.permission) || asString(entity.Name) || asString(entity.name)).filter(value => Boolean(value));
      if (values.length > 0) {
        return values;
      }
      if (Array.isArray(payload)) {
        return payload.map(item => asString(item)).filter(value => Boolean(value));
      }
      return [];
    }
    filterRegistries(registries, filter) {
      const normalizedSearch = filter.search.trim().toLowerCase();
      return registries.filter(registryItem => {
        const matchesSearch = !normalizedSearch || [registryItem.groupId, registryItem.groupName, registryItem.serviceName, registryItem.groupType, registryItem.versionNo, registryItem.status, registryItem.statusText, registryItem.description, registryItem.registeredBy, registryItem.registeredAt, registryItem.lastChangedBy, registryItem.lastChangeAt].join(' ').toLowerCase().includes(normalizedSearch);
        return matchesSearch;
      });
    }
    async loadRegistriesFromBackend(filter) {
      const aFilters = [];
      if (filter) {
        if (filter.status && filter.status.toLowerCase() !== 'all') {
          aFilters.push(new Filter('Status', FilterOperator.EQ, filter.status));
        }
        if (filter.groupType && filter.groupType.toLowerCase() !== 'all') {
          aFilters.push(new Filter('GroupType', FilterOperator.EQ, filter.groupType));
        }
        if (filter.registryName) {
          aFilters.push(new Filter('GroupName', FilterOperator.Contains, filter.registryName));
        }
        if (filter.createdBy) {
          aFilters.push(new Filter('RegisteredBy', FilterOperator.Contains, filter.createdBy));
        }
        if (filter.search) {
          const term = filter.search.trim();
          const isGuid = /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/.test(term);
          if (filter.searchField === 'registryName') {
            aFilters.push(new Filter('GroupName', FilterOperator.Contains, term));
          } else if (filter.searchField === 'registryId') {
            aFilters.push(new Filter('GroupId', FilterOperator.EQ, isGuid ? term : '00000000-0000-0000-0000-000000000000'));
          } else if (isGuid) {
            aFilters.push(new Filter({
              filters: [new Filter('GroupName', FilterOperator.Contains, term), new Filter('GroupId', FilterOperator.EQ, term)],
              and: false
            }));
          } else {
            aFilters.push(new Filter('GroupName', FilterOperator.Contains, term));
          }
        }
      }
      try {
        const oListBinding = this.model.bindList('/Registry', undefined, [new Sorter('LastChangeAt', true)], aFilters.length > 0 ? aFilters : undefined);
        const aContexts = await oListBinding.requestContexts();
        const entities = aContexts.map(oContext => oContext.getObject());
        return entities.map(entity => mapRegistryEntity(entity, {
          serviceDefinition: ''
        }));
      } catch (error) {
        throw extractServiceError(error, 'loadRegistriesFromBackend');
      }
    }
    async loadRegistryFromBackend(registryId) {
      try {
        const oContext = this.getRegistryContext(registryId);
        const entity = await oContext.requestObject();
        if (!entity || !Object.keys(entity).length) {
          return null;
        }
        return mapRegistryEntity(entity, {
          serviceDefinition: ''
        });
      } catch (error) {
        throw extractServiceError(error, 'loadRegistryFromBackend');
      }
    }
    async changeStatus(registryId, status) {
      try {
        const oContext = this.getRegistryContext(registryId);
        await oContext.setProperty('Status', status);
        await this.model.submitBatch('$auto');
        const entity = oContext.getObject();
        return delay(mapRegistryEntity(entity, {
          serviceDefinition: ''
        }));
      } catch (error) {
        throw extractServiceError(error, 'changeStatus');
      }
    }
    validateCreateInput(input) {
      const messages = [];
      if (!input.groupName.trim()) {
        messages.push('Group Name is required.');
      }
      if (!input.groupType.trim()) {
        messages.push('Group Type is required.');
      }
      if (input.groupType.trim() === '001' && !input.versionNo.trim()) {
        messages.push('Version No is required for group type 001.');
      }
      return messages;
    }
    validateUpdateInput(input) {
      const messages = [];
      if (!input.status.trim()) {
        messages.push('Status is required.');
      }
      return messages;
    }
  }
  return RegistryService;
});
//# sourceMappingURL=RegistryService-dbg.js.map
