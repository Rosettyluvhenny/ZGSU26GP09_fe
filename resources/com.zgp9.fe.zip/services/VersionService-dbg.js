sap.ui.define(["sap/ui/model/Sorter", "./ServiceError", "./ODataClient", "./ODataParsers"], function (Sorter, __ServiceError, ___ODataClient, ___ODataParsers) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const ServiceError = _interopRequireDefault(__ServiceError);
  const createODataClient = ___ODataClient["createODataClient"];
  const mapVersionEntity = ___ODataParsers["mapVersionEntity"];
  function delay(value, ms = 250) {
    return new Promise(resolve => {
      setTimeout(() => resolve(value), ms);
    });
  }
  function normalizeGuid(value) {
    return value.replace(/[{}]/g, '').trim();
  }
  function formatGuidLiteral(value) {
    return normalizeGuid(value);
  }
  function asString(value) {
    if (value === null || value === undefined) {
      return '';
    }
    const primitive = value;
    return String(primitive);
  }
  function mapCompareEntry(entry) {
    return {
      serviceDefId: asString(entry.SERVICEDEFID),
      baseDetailId: asString(entry.BASEDETAILID),
      compareDetailId: asString(entry.COMPAREDETAILID),
      changeType: asString(entry.CHANGETYPE).toUpperCase() || 'UNCHANGED'
    };
  }
  function mapCompareResult(payload) {
    return {
      baseVersionId: asString(payload.BASEVERSIONID),
      compareVersionId: asString(payload.COMPAREVERSIONID),
      change: Array.isArray(payload.CHANGE) ? payload.CHANGE.map(mapCompareEntry) : [],
      differ: Array.isArray(payload.DIFFER) ? payload.DIFFER.map(mapCompareEntry) : [],
      unchange: Array.isArray(payload.UNCHANGE) ? payload.UNCHANGE.map(mapCompareEntry) : []
    };
  }
  class VersionService {
    constructor(detailService, model) {
      this.detailService = detailService;
      this.odata = createODataClient(model);
    }
    async getVersions(registryId) {
      const backendVersions = await this.loadVersionsFromBackend(registryId);
      return delay(backendVersions);
    }
    async getVersion(versionId) {
      const backendVersion = await this.loadVersionFromBackend(versionId);
      if (!backendVersion) {
        throw new ServiceError(404, 'Version not found.');
      }
      return delay(backendVersion);
    }
    async compareVersions(leftVersionId, rightVersionId) {
      const oHeaderContext = this.odata.getHeaderContext('/Version');
      const result = await this.odata.callAction('com.sap.gateway.srvd_a2x.zsr_registry.v0001.compareVersion(...)', {
        context: oHeaderContext,
        parameters: {
          BaseVrsId: leftVersionId,
          CompareVrsId: rightVersionId
        }
      });
      return delay(mapCompareResult(result));
    }

    // ---------------------------------------------------------------------
    // Internal helpers
    // ---------------------------------------------------------------------

    versionPath(versionId) {
      return `/Version(${formatGuidLiteral(versionId)})`;
    }
    async loadVersionsFromBackend(registryId) {
      const entities = await this.odata.readList(`/Registry(${formatGuidLiteral(registryId)})/_Version`, {
        sorters: [new Sorter('CreatedAt', true)]
      });
      return entities.map(entity => this.loadVersionFromEntity(entity));
    }
    async loadVersionFromBackend(versionId) {
      const entity = await this.odata.readOne(this.versionPath(versionId));
      if (!entity) {
        return null;
      }
      return this.loadVersionFromEntity(entity);
    }
    loadVersionFromEntity(entity) {
      let parsedDetail;
      return mapVersionEntity(entity, parsedDetail);
    }
  }
  return VersionService;
});
//# sourceMappingURL=VersionService-dbg.js.map
