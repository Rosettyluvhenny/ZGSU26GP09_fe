sap.ui.define([], function () {
  "use strict";

  var __exports = {
    name: "QUnit test suite for the UI5 Application: com.zgp9.fe",
    defaults: {
      page: "ui5://test-resources/com/zgp9/fe/Test.qunit.html?testsuite={suite}&test={name}",
      qunit: {
        version: 2
      },
      sinon: {
        version: 4
      },
      ui5: {
        language: "EN",
        theme: "sap_horizon"
      },
      coverage: {
        only: ["com/zgp9/fe/"],
        never: ["test-resources/com/zgp9/fe/"]
      },
      loader: {
        paths: {
          "com/zgp9/fe": "../"
        }
      }
    },
    tests: {
      "unit/unitTests": {
        title: "Unit tests for com.zgp9.fe"
      }
    }
  };
  return __exports;
});
//# sourceMappingURL=testsuite.qunit-dbg.js.map
