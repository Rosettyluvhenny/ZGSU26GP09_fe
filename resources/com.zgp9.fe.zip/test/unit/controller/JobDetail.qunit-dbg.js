sap.ui.define(["com/zgp9/fe/controller/JobDetail.controller", "sap/ui/core/BusyIndicator"], function (__JobDetail, BusyIndicator) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  /**
   * QUnit tests for JobDetail controller
   */
  const JobDetail = _interopRequireDefault(__JobDetail);
  let sandbox;
  const SAMPLE_JOB = {
    id: "job-42",
    status: "Completed",
    executedBy: "alice",
    startedAt: "2024-01-01T08:00:00Z",
    finishedAt: "2024-01-01T08:05:00Z",
    durationMs: 300000,
    triggerType: "MANUAL",
    triggerText: "Manual",
    totalRegistry: 5,
    changeCount: 2,
    newVersionCount: 1,
    logs: [],
    errorMessage: "",
    summary: "Done"
  };
  function buildFixture() {
    const ctrl = new JobDetail("test");
    const modelData = {
      "/busy": false,
      "/job": null
    };
    const modelStub = {
      setProperty: sinon.stub().callsFake((p, v) => {
        modelData[p] = v;
      }),
      getProperty: sinon.stub().callsFake(p => modelData[p]),
      setData: sinon.stub().callsFake(data => {
        Object.keys(data).forEach(k => {
          modelData[`/${k}`] = data[k];
        });
      })
    };
    const jobService = {
      getJob: sinon.stub().resolves(SAMPLE_JOB)
    };
    sandbox.stub(ctrl, "getModel").callsFake(name => name === "jobDetail" ? modelStub : null);
    sandbox.stub(ctrl, "getRouter").returns({
      getRoute: sinon.stub().returns({
        attachPatternMatched: sinon.stub()
      }),
      navTo: sinon.stub()
    });
    sandbox.stub(ctrl, "handleServiceError").resolves();
    sandbox.stub(ctrl, "getOwnerComponent").returns({
      getJobService: () => jobService
    });
    sandbox.stub(BusyIndicator, "show");
    sandbox.stub(BusyIndicator, "hide");
    return {
      ctrl,
      modelData,
      jobService
    };
  }
  function routeEvent(jobId) {
    return {
      getParameter: sinon.stub().withArgs("arguments").returns(jobId ? {
        jobId
      } : {})
    };
  }
  QUnit.module("JobDetail – onInit", {
    beforeEach() {
      sandbox = sinon.sandbox.create();
    },
    afterEach() {
      sandbox.restore();
    }
  });
  QUnit.test("registers jobDetail model with defaults", function (assert) {
    const ctrl = new JobDetail("test");
    const setModelSpy = sandbox.stub(ctrl, "setModel").returns(ctrl);
    sandbox.stub(ctrl, "getRouter").returns({
      getRoute: sinon.stub().returns({
        attachPatternMatched: sinon.stub()
      })
    });
    ctrl.onInit();
    assert.strictEqual(setModelSpy.firstCall.args[1], "jobDetail");
    const data = setModelSpy.firstCall.args[0].getData();
    assert.strictEqual(data.busy, false);
    assert.strictEqual(data.job, null);
  });
  QUnit.module("JobDetail – onRouteMatched", {
    beforeEach() {
      sandbox = sinon.sandbox.create();
    },
    afterEach() {
      sandbox.restore();
    }
  });
  QUnit.test("loads job when jobId is present", async function (assert) {
    const {
      ctrl,
      modelData,
      jobService
    } = buildFixture();
    await ctrl.onRouteMatched(routeEvent("job-42"));
    assert.ok(jobService.getJob.calledOnceWithExactly("job-42"));
    assert.deepEqual(modelData["/job"], SAMPLE_JOB);
    assert.strictEqual(modelData["/busy"], false);
  });
  QUnit.test("skips load when jobId is missing", async function (assert) {
    const {
      ctrl,
      jobService
    } = buildFixture();
    await ctrl.onRouteMatched(routeEvent());
    assert.ok(!jobService.getJob.called);
  });
  QUnit.test("handles getJob errors and resets busy", async function (assert) {
    const {
      ctrl,
      modelData,
      jobService
    } = buildFixture();
    jobService.getJob.rejects(new Error("boom"));
    await ctrl.onRouteMatched(routeEvent("job-42"));
    assert.ok(ctrl.handleServiceError.calledOnce);
    assert.strictEqual(modelData["/busy"], false);
  });
});
//# sourceMappingURL=JobDetail.qunit-dbg.js.map
