sap.ui.define(["com/zgp9/fe/controller/Login.controller", "sap/m/MessageBox", "sap/m/MessageToast"], function (__Login, MessageBox, MessageToast) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  /**
   * QUnit tests for Login controller
   * SAP UI5 flat-module form + sinon.sandbox pattern (sinon 1.x/4.x compatible).
   */
  const Login = _interopRequireDefault(__Login);
  // sinon: typed via webapp/test/sinon-global.d.ts (uses @types/sinon)

  let sandbox;

  // ─────────────────────────────────────────────────────────────────────────────
  //  Test-fixture builder
  // ─────────────────────────────────────────────────────────────────────────────

  function buildLoginFixture(overrides = {}) {
    const ctrl = new Login("test");
    const loginModelData = {
      userName: overrides.userName !== undefined ? overrides.userName : "",
      password: overrides.password !== undefined ? overrides.password : ""
    };
    const loginModelStub = {
      getData: sinon.stub().callsFake(() => ({
        ...loginModelData
      })),
      setData: sinon.stub().callsFake(d => Object.assign(loginModelData, d))
    };
    const uiModelData = {};
    const uiModelStub = {
      setProperty: sinon.stub().callsFake((p, v) => {
        uiModelData[p] = v;
      }),
      getProperty: sinon.stub().callsFake(p => uiModelData[p])
    };
    const sessionModelStub = {
      setData: sinon.stub()
    };
    const authService = {
      login: sinon.stub()
    };
    const navToStub = sinon.stub();
    sandbox.stub(ctrl, "getModel").callsFake(name => name === "login" ? loginModelStub : null);
    sandbox.stub(ctrl, "getUiModel").returns(uiModelStub);
    sandbox.stub(ctrl, "getSessionModel").returns(sessionModelStub);
    sandbox.stub(ctrl, "getRouter").returns({
      navTo: navToStub
    });
    sandbox.stub(ctrl, "handleServiceError").resolves();
    sandbox.stub(ctrl, "getOwnerComponent").returns({
      getAuthenticationService: () => authService
    });
    return {
      ctrl,
      loginModelData,
      loginModelStub,
      uiModelData,
      uiModelStub,
      sessionModelStub,
      authService,
      navToStub
    };
  }

  // ═════════════════════════════════════════════════════════════════════════════
  //  onInit
  // ═════════════════════════════════════════════════════════════════════════════
  let onInitCtrl;
  let onInitSetModelSpy;
  QUnit.module("Login – onInit", {
    beforeEach() {
      sandbox = sinon.sandbox.create();
      onInitCtrl = new Login("test");
      onInitSetModelSpy = sandbox.stub(onInitCtrl, "setModel").returns(onInitCtrl);
    },
    afterEach() {
      sandbox.restore();
    }
  });
  QUnit.test("calls setModel once", function (assert) {
    onInitCtrl.onInit();
    assert.ok(onInitSetModelSpy.calledOnce, "setModel must be called exactly once");
  });
  QUnit.test("registers model under the name 'login'", function (assert) {
    onInitCtrl.onInit();
    assert.strictEqual(onInitSetModelSpy.firstCall.args[1], "login", "Model name must be 'login'");
  });
  QUnit.test("initial model data has empty userName", function (assert) {
    onInitCtrl.onInit();
    const model = onInitSetModelSpy.firstCall.args[0];
    assert.strictEqual(model.getData().userName, "", "userName must be empty");
  });
  QUnit.test("initial model data has empty password", function (assert) {
    onInitCtrl.onInit();
    const model = onInitSetModelSpy.firstCall.args[0];
    assert.strictEqual(model.getData().password, "", "password must be empty");
  });

  // ═════════════════════════════════════════════════════════════════════════════
  //  onLogin – input validation
  // ═════════════════════════════════════════════════════════════════════════════
  let validationMsgBoxErrorStub;
  QUnit.module("Login – onLogin – validation", {
    beforeEach() {
      sandbox = sinon.sandbox.create();
      validationMsgBoxErrorStub = sandbox.stub(MessageBox, "error");
    },
    afterEach() {
      sandbox.restore();
    }
  });
  QUnit.test("shows error when userName is empty", async function (assert) {
    const {
      ctrl
    } = buildLoginFixture({
      userName: "",
      password: "secret"
    });
    await ctrl.onLogin();
    assert.ok(validationMsgBoxErrorStub.calledOnce, "MessageBox.error must be called");
    assert.ok(validationMsgBoxErrorStub.firstCall.args[0].includes("required"), "Error message mentions 'required'");
  });
  QUnit.test("shows error when password is empty", async function (assert) {
    const {
      ctrl
    } = buildLoginFixture({
      userName: "admin",
      password: ""
    });
    await ctrl.onLogin();
    assert.ok(validationMsgBoxErrorStub.calledOnce, "MessageBox.error must be called");
  });
  QUnit.test("shows error when userName is whitespace-only", async function (assert) {
    const {
      ctrl
    } = buildLoginFixture({
      userName: "   ",
      password: "secret"
    });
    await ctrl.onLogin();
    assert.ok(validationMsgBoxErrorStub.calledOnce, "MessageBox.error must be called");
  });
  QUnit.test("shows error when password is whitespace-only", async function (assert) {
    const {
      ctrl
    } = buildLoginFixture({
      userName: "admin",
      password: "   "
    });
    await ctrl.onLogin();
    assert.ok(validationMsgBoxErrorStub.calledOnce, "MessageBox.error must be called");
  });
  QUnit.test("does NOT call auth service when credentials are invalid", async function (assert) {
    const {
      ctrl,
      authService
    } = buildLoginFixture({
      userName: "",
      password: ""
    });
    await ctrl.onLogin();
    assert.ok(!authService.login.called, "auth.login must NOT be called with invalid credentials");
  });

  // ═════════════════════════════════════════════════════════════════════════════
  //  onLogin – success
  // ═════════════════════════════════════════════════════════════════════════════
  const SESSION_DATA = {
    authenticated: true,
    userName: "alice",
    csrfToken: "tok",
    loginAt: "2024-01-01"
  };
  let successMsgToastStub;
  QUnit.module("Login – onLogin – success flow", {
    beforeEach() {
      sandbox = sinon.sandbox.create();
      successMsgToastStub = sandbox.stub(MessageToast, "show");
    },
    afterEach() {
      sandbox.restore();
    }
  });
  QUnit.test("calls auth.login with trimmed credentials", async function (assert) {
    const {
      ctrl,
      authService
    } = buildLoginFixture({
      userName: " alice ",
      password: "pass"
    });
    authService.login.resolves(SESSION_DATA);
    await ctrl.onLogin();
    assert.ok(authService.login.calledOnce, "auth.login must be called once");
    assert.strictEqual(authService.login.firstCall.args[0], "alice", "Username must be trimmed");
    assert.strictEqual(authService.login.firstCall.args[1], "pass", "Password is passed as-is");
  });
  QUnit.test("stores session data in sessionModel on success", async function (assert) {
    const {
      ctrl,
      authService,
      sessionModelStub
    } = buildLoginFixture({
      userName: "alice",
      password: "pass"
    });
    authService.login.resolves(SESSION_DATA);
    await ctrl.onLogin();
    assert.ok(sessionModelStub.setData.calledOnceWith(SESSION_DATA), "Session data must be stored");
  });
  QUnit.test("shows MessageToast with welcome message on success", async function (assert) {
    const {
      ctrl,
      authService
    } = buildLoginFixture({
      userName: "alice",
      password: "pass"
    });
    authService.login.resolves(SESSION_DATA);
    await ctrl.onLogin();
    assert.ok(successMsgToastStub.calledOnce, "MessageToast.show must be called");
    assert.ok(successMsgToastStub.firstCall.args[0].includes("alice"), "Toast must include user name");
  });
  QUnit.test("navigates to 'home' on success", async function (assert) {
    const {
      ctrl,
      authService,
      navToStub
    } = buildLoginFixture({
      userName: "alice",
      password: "pass"
    });
    authService.login.resolves(SESSION_DATA);
    await ctrl.onLogin();
    assert.ok(navToStub.calledOnce, "navTo must be called");
    assert.strictEqual(navToStub.firstCall.args[0], "home", "Must navigate to 'home'");
  });
  QUnit.test("clears login model data after success", async function (assert) {
    const {
      ctrl,
      authService,
      loginModelStub
    } = buildLoginFixture({
      userName: "alice",
      password: "pass"
    });
    authService.login.resolves(SESSION_DATA);
    await ctrl.onLogin();
    assert.ok(loginModelStub.setData.calledOnce, "loginModel.setData must be called to reset fields");
    const resetData = loginModelStub.setData.firstCall.args[0];
    assert.strictEqual(resetData.userName, "", "userName must be cleared");
    assert.strictEqual(resetData.password, "", "password must be cleared");
  });
  QUnit.test("sets loginBusy=false in finally after success", async function (assert) {
    const {
      ctrl,
      authService,
      uiModelData
    } = buildLoginFixture({
      userName: "alice",
      password: "pass"
    });
    authService.login.resolves(SESSION_DATA);
    await ctrl.onLogin();
    assert.strictEqual(uiModelData["/loginBusy"], false, "loginBusy must be false after completion");
  });

  // ═════════════════════════════════════════════════════════════════════════════
  //  onLogin – error
  // ═════════════════════════════════════════════════════════════════════════════
  QUnit.module("Login – onLogin – error handling", {
    beforeEach() {
      sandbox = sinon.sandbox.create();
    },
    afterEach() {
      sandbox.restore();
    }
  });
  QUnit.test("calls handleServiceError when auth.login rejects", async function (assert) {
    const {
      ctrl,
      authService
    } = buildLoginFixture({
      userName: "alice",
      password: "pass"
    });
    const serviceError = new Error("Unauthorized");
    authService.login.rejects(serviceError);
    await ctrl.onLogin();
    assert.ok(ctrl.handleServiceError.calledOnceWith(serviceError), "handleServiceError must be called with the error");
  });
  QUnit.test("resets loginBusy to false even when an error occurs", async function (assert) {
    const {
      ctrl,
      authService,
      uiModelData
    } = buildLoginFixture({
      userName: "alice",
      password: "pass"
    });
    authService.login.rejects(new Error("Network error"));
    await ctrl.onLogin();
    assert.strictEqual(uiModelData["/loginBusy"], false, "loginBusy must be false in the finally block");
  });
  QUnit.test("does NOT navigate when auth.login rejects", async function (assert) {
    const {
      ctrl,
      authService,
      navToStub
    } = buildLoginFixture({
      userName: "alice",
      password: "pass"
    });
    authService.login.rejects(new Error("Unauthorized"));
    await ctrl.onLogin();
    assert.ok(!navToStub.called, "navTo must NOT be called on error");
  });
});
//# sourceMappingURL=Login.qunit-dbg.js.map
