sap.ui.define(["com/zgp9/fe/controller/Logs.controller"], function (__Logs) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  /**
   * QUnit tests for Logs controller
   * SAP UI5 flat-module form + sinon.sandbox pattern (sinon 1.x/4.x compatible).
   */
  const Logs = _interopRequireDefault(__Logs);
  // sinon: typed via webapp/test/sinon-global.d.ts (uses @types/sinon)

  let sandbox;

  // ─────────────────────────────────────────────────────────────────────────────
  //  Sample data
  // ─────────────────────────────────────────────────────────────────────────────
  function makeLog(overrides = {}) {
    return {
      id: "log-1",
      actionType: "LOGIN",
      actor: "alice",
      actionAt: "2024-06-01T10:00:00.000Z",
      ipAddress: "10.0.0.1",
      remarks: "",
      logResult: "SUCCESS",
      objectId: "reg-1",
      objectIdType: "REGISTRY",
      ...overrides
    };
  }
  const SAMPLE_LOGS = [makeLog({
    id: "log-1",
    actionType: "LOGIN",
    logResult: "SUCCESS",
    objectIdType: "REGISTRY",
    actionAt: "2024-06-01T10:00:00.000Z"
  }), makeLog({
    id: "log-2",
    actionType: "UPDATE",
    logResult: "FAILURE",
    objectIdType: "VERSION",
    objectId: "ver-1",
    actionAt: "2024-06-02T12:00:00.000Z"
  }), makeLog({
    id: "log-3",
    actionType: "DELETE",
    logResult: "SUCCESS",
    objectIdType: "REGISTRY",
    objectId: "reg-2",
    actionAt: "2024-06-03T15:00:00.000Z",
    actor: "bob"
  })];

  // ─────────────────────────────────────────────────────────────────────────────
  //  Fixture builder
  // ─────────────────────────────────────────────────────────────────────────────

  function buildLogsFixture() {
    const ctrl = new Logs("test");
    const modelData = {
      "/items": [],
      "/busy": false,
      "/search": "",
      "/actionType": "All",
      "/logResult": "All",
      "/objectIdType": "All",
      "/actionTypeOptions": [],
      "/logResultOptions": [],
      "/objectIdTypeOptions": [],
      "/selectedLog": null
    };
    const modelStub = {
      setProperty: sinon.stub().callsFake((p, v) => {
        modelData[p] = v;
      }),
      getProperty: sinon.stub().callsFake(p => modelData[p])
    };
    const logService = {
      getLogs: sinon.stub().resolves(SAMPLE_LOGS)
    };
    const navToStub = sinon.stub();
    sandbox.stub(ctrl, "getModel").callsFake(name => name === "logList" ? modelStub : null);
    sandbox.stub(ctrl, "getRouter").returns({
      navTo: navToStub,
      getRoute: sinon.stub().returns({
        attachPatternMatched: sinon.stub()
      })
    });
    sandbox.stub(ctrl, "navTo").callsFake(navToStub);
    sandbox.stub(ctrl, "handleServiceError").resolves();
    sandbox.stub(ctrl, "getOwnerComponent").returns({
      getLogService: () => logService
    });
    return {
      ctrl,
      modelData,
      modelStub,
      logService,
      navToStub
    };
  }

  // ═════════════════════════════════════════════════════════════════════════════
  //  onInit
  // ═════════════════════════════════════════════════════════════════════════════
  let onInitCtrl;
  let onInitSetModelSpy;
  QUnit.module("Logs – onInit", {
    beforeEach() {
      sandbox = sinon.sandbox.create();
      onInitCtrl = new Logs("test");
      onInitSetModelSpy = sandbox.stub(onInitCtrl, "setModel").returns(onInitCtrl);
      sandbox.stub(onInitCtrl, "getRouter").returns({
        getRoute: sinon.stub().returns({
          attachPatternMatched: sinon.stub()
        })
      });
    },
    afterEach() {
      sandbox.restore();
    }
  });
  QUnit.test("registers model under the name 'logList'", function (assert) {
    onInitCtrl.onInit();
    assert.ok(onInitSetModelSpy.calledOnce);
    assert.strictEqual(onInitSetModelSpy.firstCall.args[1], "logList");
  });
  QUnit.test("initial model has items=[], busy=false, search=''", function (assert) {
    onInitCtrl.onInit();
    const data = onInitSetModelSpy.firstCall.args[0].getData();
    assert.deepEqual(data.items, []);
    assert.strictEqual(data.busy, false);
    assert.strictEqual(data.search, "");
  });
  QUnit.test("initial filter states are all 'All'", function (assert) {
    onInitCtrl.onInit();
    const data = onInitSetModelSpy.firstCall.args[0].getData();
    assert.strictEqual(data.actionType, "All");
    assert.strictEqual(data.logResult, "All");
    assert.strictEqual(data.objectIdType, "All");
  });

  // ═════════════════════════════════════════════════════════════════════════════
  //  onRefresh
  // ═════════════════════════════════════════════════════════════════════════════
  QUnit.module("Logs – onRefresh", {
    beforeEach() {
      sandbox = sinon.sandbox.create();
    },
    afterEach() {
      sandbox.restore();
    }
  });
  QUnit.test("triggers getLogs on the log service", async function (assert) {
    const {
      ctrl,
      logService
    } = buildLogsFixture();
    await ctrl.onRefresh();
    assert.ok(logService.getLogs.calledOnce, "getLogs must be called on refresh");
  });
  QUnit.test("sets /busy=false after completion", async function (assert) {
    const {
      ctrl,
      modelData
    } = buildLogsFixture();
    await ctrl.onRefresh();
    assert.strictEqual(modelData["/busy"], false);
  });

  // ═════════════════════════════════════════════════════════════════════════════
  //  onSearchLiveChange
  // ═════════════════════════════════════════════════════════════════════════════
  QUnit.module("Logs – onSearchLiveChange", {
    beforeEach() {
      sandbox = sinon.sandbox.create();
    },
    afterEach() {
      sandbox.restore();
    }
  });
  QUnit.test("updates /search in the model", async function (assert) {
    const {
      ctrl,
      modelData,
      logService
    } = buildLogsFixture();
    await ctrl.onRefresh();
    logService.getLogs.resetHistory();
    const event = {
      getSource: sinon.stub().returns({
        getValue: sinon.stub().returns("alice")
      })
    };
    ctrl.onSearchLiveChange(event);
    assert.strictEqual(modelData["/search"], "alice");
  });
  QUnit.test("filters /items to entries matching the search text", async function (assert) {
    const {
      ctrl,
      modelData
    } = buildLogsFixture();
    await ctrl.onRefresh();
    const event = {
      getSource: sinon.stub().returns({
        getValue: sinon.stub().returns("bob")
      })
    };
    ctrl.onSearchLiveChange(event);
    const items = modelData["/items"];
    assert.ok(items.every(l => l.actor === "bob" || JSON.stringify(l).toLowerCase().includes("bob")), "Filtered items must match the search text");
  });
  QUnit.test("clearing search restores all items", async function (assert) {
    const {
      ctrl,
      modelData
    } = buildLogsFixture();
    await ctrl.onRefresh();
    const totalCount = modelData["/items"].length;
    ctrl.onSearchLiveChange({
      getSource: sinon.stub().returns({
        getValue: sinon.stub().returns("bob")
      })
    });
    ctrl.onSearchLiveChange({
      getSource: sinon.stub().returns({
        getValue: sinon.stub().returns("")
      })
    });
    assert.strictEqual(modelData["/items"].length, totalCount, "Clearing search must restore all items");
  });

  // ═════════════════════════════════════════════════════════════════════════════
  //  onFilterChange
  // ═════════════════════════════════════════════════════════════════════════════
  QUnit.module("Logs – onFilterChange", {
    beforeEach() {
      sandbox = sinon.sandbox.create();
    },
    afterEach() {
      sandbox.restore();
    }
  });
  QUnit.test("filters by actionType correctly", async function (assert) {
    const {
      ctrl,
      modelData
    } = buildLogsFixture();
    await ctrl.onRefresh();
    modelData["/actionType"] = "UPDATE";
    ctrl.onFilterChange();
    const items = modelData["/items"];
    assert.ok(items.every(l => l.actionType === "UPDATE"), "All items must have actionType=UPDATE");
  });
  QUnit.test("filters by logResult correctly", async function (assert) {
    const {
      ctrl,
      modelData
    } = buildLogsFixture();
    await ctrl.onRefresh();
    modelData["/logResult"] = "FAILURE";
    ctrl.onFilterChange();
    const items = modelData["/items"];
    assert.ok(items.every(l => l.logResult === "FAILURE"), "All items must have logResult=FAILURE");
  });
  QUnit.test("filters by objectIdType correctly", async function (assert) {
    const {
      ctrl,
      modelData
    } = buildLogsFixture();
    await ctrl.onRefresh();
    modelData["/objectIdType"] = "VERSION";
    ctrl.onFilterChange();
    const items = modelData["/items"];
    assert.ok(items.every(l => l.objectIdType === "VERSION"), "All items must have objectIdType=VERSION");
  });
  QUnit.test("'All' filter shows all items", async function (assert) {
    const {
      ctrl,
      modelData
    } = buildLogsFixture();
    await ctrl.onRefresh();
    modelData["/actionType"] = "DELETE";
    ctrl.onFilterChange();
    modelData["/actionType"] = "All";
    ctrl.onFilterChange();
    assert.strictEqual(modelData["/items"].length, SAMPLE_LOGS.length, "All items must show when filter is 'All'");
  });

  // ═════════════════════════════════════════════════════════════════════════════
  //  onDateRangeChange
  // ═════════════════════════════════════════════════════════════════════════════
  QUnit.module("Logs – onDateRangeChange", {
    beforeEach() {
      sandbox = sinon.sandbox.create();
    },
    afterEach() {
      sandbox.restore();
    }
  });
  QUnit.test("filters out logs before the dateFrom boundary", async function (assert) {
    const {
      ctrl,
      modelData
    } = buildLogsFixture();
    await ctrl.onRefresh();
    const from = new Date("2024-06-02T00:00:00.000Z");
    const event = {
      getSource: sinon.stub().returns({
        getDateValue: sinon.stub().returns(from),
        getSecondDateValue: sinon.stub().returns(null)
      })
    };
    ctrl.onDateRangeChange(event);
    const items = modelData["/items"];
    assert.ok(!items.find(l => l.id === "log-1"), "log-1 (2024-06-01) must be excluded");
  });
  QUnit.test("filters out logs after the dateTo boundary", async function (assert) {
    const {
      ctrl,
      modelData
    } = buildLogsFixture();
    await ctrl.onRefresh();
    const to = new Date("2024-06-01T00:00:00.000Z");
    const event = {
      getSource: sinon.stub().returns({
        getDateValue: sinon.stub().returns(null),
        getSecondDateValue: sinon.stub().returns(to)
      })
    };
    ctrl.onDateRangeChange(event);
    const items = modelData["/items"];
    assert.ok(items.every(l => new Date(l.actionAt) <= new Date("2024-06-01T23:59:59.999Z")), "Items after dateTo must be excluded");
  });
  QUnit.test("no date filter when both dateFrom and dateTo are null", async function (assert) {
    const {
      ctrl,
      modelData
    } = buildLogsFixture();
    await ctrl.onRefresh();
    const event = {
      getSource: sinon.stub().returns({
        getDateValue: sinon.stub().returns(null),
        getSecondDateValue: sinon.stub().returns(null)
      })
    };
    ctrl.onDateRangeChange(event);
    assert.strictEqual(modelData["/items"].length, SAMPLE_LOGS.length);
  });

  // ═════════════════════════════════════════════════════════════════════════════
  //  onRowPress
  // ═════════════════════════════════════════════════════════════════════════════
  QUnit.module("Logs – onRowPress", {
    beforeEach() {
      sandbox = sinon.sandbox.create();
    },
    afterEach() {
      sandbox.restore();
    }
  });
  QUnit.test("sets /selectedLog and attempts to open the dialog when a log is present", function (assert) {
    const {
      ctrl,
      modelData
    } = buildLogsFixture();
    const log = makeLog();
    sandbox.stub(ctrl, "getView").returns({
      getId: sinon.stub().returns("view--"),
      addDependent: sinon.stub()
    });
    const event = {
      getSource: sinon.stub().returns({
        getBindingContext: sinon.stub().returns({
          getObject: sinon.stub().returns(log)
        })
      })
    };
    ctrl.onRowPress(event);
    assert.deepEqual(modelData["/selectedLog"], log, "/selectedLog must be set to the pressed log");
  });
  QUnit.test("does nothing when binding context is null", function (assert) {
    const {
      ctrl,
      modelData
    } = buildLogsFixture();
    const event = {
      getSource: sinon.stub().returns({
        getBindingContext: sinon.stub().returns(null)
      })
    };
    ctrl.onRowPress(event);
    assert.strictEqual(modelData["/selectedLog"], null, "/selectedLog must remain null");
  });

  // ═════════════════════════════════════════════════════════════════════════════
  //  onNavigateToObject
  // ═════════════════════════════════════════════════════════════════════════════
  QUnit.module("Logs – onNavigateToObject", {
    beforeEach() {
      sandbox = sinon.sandbox.create();
    },
    afterEach() {
      sandbox.restore();
    }
  });
  QUnit.test("navigates to registryDetail for objectIdType=REGISTRY", function (assert) {
    const {
      ctrl,
      modelData,
      navToStub
    } = buildLogsFixture();
    modelData["/selectedLog"] = makeLog({
      objectIdType: "REGISTRY",
      objectId: "reg-42"
    });
    ctrl.onNavigateToObject();
    assert.ok(navToStub.calledOnce, "navTo must be called");
    assert.strictEqual(navToStub.firstCall.args[0], "registryDetail");
    assert.deepEqual(navToStub.firstCall.args[1], {
      registryId: "reg-42"
    });
  });
  QUnit.test("does NOT navigate when selectedLog is null", function (assert) {
    const {
      ctrl,
      modelData,
      navToStub
    } = buildLogsFixture();
    modelData["/selectedLog"] = null;
    ctrl.onNavigateToObject();
    assert.ok(!navToStub.called, "navTo must NOT be called when selectedLog is null");
  });
  QUnit.test("does NOT navigate when objectId is empty", function (assert) {
    const {
      ctrl,
      modelData,
      navToStub
    } = buildLogsFixture();
    modelData["/selectedLog"] = makeLog({
      objectId: ""
    });
    ctrl.onNavigateToObject();
    assert.ok(!navToStub.called, "navTo must NOT be called when objectId is empty");
  });
  QUnit.test("does NOT navigate for unknown objectIdType", function (assert) {
    const {
      ctrl,
      modelData,
      navToStub
    } = buildLogsFixture();
    modelData["/selectedLog"] = makeLog({
      objectIdType: "JOB",
      objectId: "job-1"
    });
    ctrl.onNavigateToObject();
    assert.ok(!navToStub.called, "navTo must NOT be called for non-REGISTRY types");
  });

  // ═════════════════════════════════════════════════════════════════════════════
  //  onCloseDetailDialog
  // ═════════════════════════════════════════════════════════════════════════════
  QUnit.module("Logs – onCloseDetailDialog", {
    beforeEach() {
      sandbox = sinon.sandbox.create();
    },
    afterEach() {
      sandbox.restore();
    }
  });
  QUnit.test("calls dialog.close when dialog exists", function (assert) {
    const {
      ctrl
    } = buildLogsFixture();
    const closeStub = sinon.stub();
    ctrl.detailDialog = {
      close: closeStub
    };
    ctrl.onCloseDetailDialog();
    assert.ok(closeStub.calledOnce, "dialog.close must be called");
  });
  QUnit.test("does NOT throw when no dialog exists", function (assert) {
    const {
      ctrl
    } = buildLogsFixture();
    ctrl.detailDialog = undefined;
    let threw = false;
    try {
      ctrl.onCloseDetailDialog();
    } catch {
      threw = true;
    }
    assert.ok(!threw, "Must not throw when detailDialog is undefined");
  });

  // ═════════════════════════════════════════════════════════════════════════════
  //  formatLogResultState  (pure function)
  // ═════════════════════════════════════════════════════════════════════════════
  let fmtCtrl;
  QUnit.module("Logs – formatLogResultState", {
    beforeEach() {
      sandbox = sinon.sandbox.create();
      const {
        ctrl
      } = buildLogsFixture();
      fmtCtrl = ctrl;
    },
    afterEach() {
      sandbox.restore();
    }
  });
  QUnit.test("'SUCCESS' → 'Success'", function (assert) {
    assert.strictEqual(fmtCtrl.formatLogResultState("SUCCESS"), "Success");
  });
  QUnit.test("'success' (lowercase) → 'Success'", function (assert) {
    assert.strictEqual(fmtCtrl.formatLogResultState("success"), "Success");
  });
  QUnit.test("'FAILURE' → 'Error'", function (assert) {
    assert.strictEqual(fmtCtrl.formatLogResultState("FAILURE"), "Error");
  });
  QUnit.test("'ERROR' → 'Error'", function (assert) {
    assert.strictEqual(fmtCtrl.formatLogResultState("ERROR"), "Error");
  });
  QUnit.test("'failure' (lowercase) → 'Error'", function (assert) {
    assert.strictEqual(fmtCtrl.formatLogResultState("failure"), "Error");
  });
  QUnit.test("empty string → 'None'", function (assert) {
    assert.strictEqual(fmtCtrl.formatLogResultState(""), "None");
  });
  QUnit.test("unknown value 'PENDING' → 'None'", function (assert) {
    assert.strictEqual(fmtCtrl.formatLogResultState("PENDING"), "None");
  });
  QUnit.test("null (coerced) → 'None'", function (assert) {
    assert.strictEqual(fmtCtrl.formatLogResultState(null), "None");
  });

  // ═════════════════════════════════════════════════════════════════════════════
  //  Filter option building
  // ═════════════════════════════════════════════════════════════════════════════
  QUnit.module("Logs – filter option building", {
    beforeEach() {
      sandbox = sinon.sandbox.create();
    },
    afterEach() {
      sandbox.restore();
    }
  });
  QUnit.test("builds actionTypeOptions from loaded logs", async function (assert) {
    const {
      ctrl,
      modelData
    } = buildLogsFixture();
    await ctrl.onRefresh();
    const opts = modelData["/actionTypeOptions"];
    assert.ok(opts.length > 0, "actionTypeOptions must be populated");
    assert.ok(opts.find(o => o.key === "All"), "Must include an 'All' option");
    assert.ok(opts.find(o => o.key === "LOGIN"), "Must include LOGIN");
    assert.ok(opts.find(o => o.key === "UPDATE"), "Must include UPDATE");
    assert.ok(opts.find(o => o.key === "DELETE"), "Must include DELETE");
  });
  QUnit.test("builds logResultOptions from loaded logs", async function (assert) {
    const {
      ctrl,
      modelData
    } = buildLogsFixture();
    await ctrl.onRefresh();
    const opts = modelData["/logResultOptions"];
    assert.ok(opts.find(o => o.key === "SUCCESS"), "Must include SUCCESS");
    assert.ok(opts.find(o => o.key === "FAILURE"), "Must include FAILURE");
  });
  QUnit.test("builds objectIdTypeOptions from loaded logs", async function (assert) {
    const {
      ctrl,
      modelData
    } = buildLogsFixture();
    await ctrl.onRefresh();
    const opts = modelData["/objectIdTypeOptions"];
    assert.ok(opts.find(o => o.key === "REGISTRY"), "Must include REGISTRY");
    assert.ok(opts.find(o => o.key === "VERSION"), "Must include VERSION");
  });
  QUnit.test("option values are sorted alphabetically (excluding 'All')", async function (assert) {
    const {
      ctrl,
      modelData
    } = buildLogsFixture();
    await ctrl.onRefresh();
    const opts = modelData["/actionTypeOptions"];
    const valueKeys = opts.filter(o => o.key !== "All").map(o => o.key);
    const sorted = [...valueKeys].sort();
    assert.deepEqual(valueKeys, sorted, "Options must be sorted alphabetically");
  });
});
//# sourceMappingURL=Logs.qunit-dbg.js.map
