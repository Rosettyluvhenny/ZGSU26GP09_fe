sap.ui.define(["com/zgp9/fe/controller/Main.controller", "sap/m/MessageBox"], function (__Main, MessageBox) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  /**
   * QUnit tests for Main controller
   * SAP UI5 flat-module form + sinon.sandbox pattern (sinon 1.x/4.x compatible).
   */
  const Main = _interopRequireDefault(__Main);
  // sinon: typed via webapp/test/sinon-global.d.ts (uses @types/sinon)

  let sandbox;
  QUnit.module("Main – sayHello", {
    beforeEach() {
      sandbox = sinon.sandbox.create();
    },
    afterEach() {
      sandbox.restore();
    }
  });
  QUnit.test("sayHello is a function on the prototype", function (assert) {
    assert.strictEqual(typeof Main.prototype.sayHello, "function");
  });
  QUnit.test("sayHello calls MessageBox.show", function (assert) {
    const showStub = sandbox.stub(MessageBox, "show");
    const ctrl = new Main("test");
    ctrl.sayHello();
    assert.ok(showStub.calledOnce, "MessageBox.show must be called once");
  });
  QUnit.test("sayHello calls MessageBox.show with 'Hello World!'", function (assert) {
    const showStub = sandbox.stub(MessageBox, "show");
    const ctrl = new Main("test");
    ctrl.sayHello();
    assert.strictEqual(showStub.firstCall.args[0], "Hello World!", "Must show 'Hello World!'");
  });
  QUnit.test("sayHello does not throw", function (assert) {
    sandbox.stub(MessageBox, "show");
    const ctrl = new Main("test");
    assert.ok(() => ctrl.sayHello(), "sayHello must not throw an exception");
  });
});
//# sourceMappingURL=Main.qunit-dbg.js.map
