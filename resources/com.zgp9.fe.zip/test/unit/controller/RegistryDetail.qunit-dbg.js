sap.ui.define(["com/zgp9/fe/controller/RegistryDetail.controller"], function (__RegistryDetail) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  /**
   * QUnit tests for RegistryDetail controller (selection + compare navigation).
   */
  const RegistryDetail = _interopRequireDefault(__RegistryDetail);
  let sandbox;
  const VERSIONS = [{
    id: "v-old",
    groupId: "reg-1",
    versionNumber: "001",
    createdBy: "alice",
    createdAt: "2024-01-01T00:00:00.000Z",
    comment: "",
    metadata: {
      entityTypes: [],
      entitySets: [],
      properties: [],
      navigationProperties: [],
      functionImports: [],
      actions: [],
      complexTypes: []
    },
    xml: ""
  }, {
    id: "v-new",
    groupId: "reg-1",
    versionNumber: "002",
    createdBy: "bob",
    createdAt: "2024-06-01T00:00:00.000Z",
    comment: "",
    metadata: {
      entityTypes: [],
      entitySets: [],
      properties: [],
      navigationProperties: [],
      functionImports: [],
      actions: [],
      complexTypes: []
    },
    xml: ""
  }];
  function buildFixture() {
    const ctrl = new RegistryDetail("test");
    const modelData = {
      "/versions": VERSIONS,
      "/selectedVersionIds": [],
      "/selectionCountLabel": "0/2",
      "/canCompare": false,
      "/busy": false
    };
    const modelStub = {
      setProperty: sinon.stub().callsFake((p, v) => {
        modelData[p] = v;
      }),
      getProperty: sinon.stub().callsFake(p => modelData[p]),
      setData: sinon.stub()
    };
    const navToStub = sinon.stub();
    sandbox.stub(ctrl, "getModel").callsFake(name => name === "registryDetail" ? modelStub : null);
    sandbox.stub(ctrl, "getRouter").returns({
      getRoute: sinon.stub().returns({
        attachPatternMatched: sinon.stub()
      }),
      navTo: navToStub
    });
    sandbox.stub(ctrl, "navTo").callsFake(navToStub);
    sandbox.stub(ctrl, "handleServiceError").resolves();
    sandbox.stub(ctrl, "getOwnerComponent").returns({
      getRegistryService: () => ({
        getRegistry: sinon.stub().resolves({
          id: "reg-1"
        })
      }),
      getVersionService: () => ({
        getVersions: sinon.stub().resolves(VERSIONS)
      })
    });
    ctrl.registryId = "reg-1";
    return {
      ctrl,
      modelData,
      navToStub
    };
  }
  QUnit.module("RegistryDetail – onComparePress", {
    beforeEach() {
      sandbox = sinon.sandbox.create();
    },
    afterEach() {
      sandbox.restore();
    }
  });
  QUnit.test("navigates to versionCompare with older version as Base (left)", function (assert) {
    const {
      ctrl,
      modelData,
      navToStub
    } = buildFixture();
    // Intentionally select newer first — sort must still put older on the left.
    modelData["/selectedVersionIds"] = ["v-new", "v-old"];
    ctrl.onComparePress();
    assert.ok(navToStub.calledOnce);
    assert.strictEqual(navToStub.firstCall.args[0], "versionCompare");
    assert.deepEqual(navToStub.firstCall.args[1], {
      registryId: "reg-1",
      leftVersionId: "v-old",
      rightVersionId: "v-new"
    });
  });
  QUnit.test("does NOT navigate when fewer than 2 versions are selected", function (assert) {
    const {
      ctrl,
      modelData,
      navToStub
    } = buildFixture();
    modelData["/selectedVersionIds"] = ["v-old"];
    ctrl.onComparePress();
    assert.ok(!navToStub.called);
  });
  QUnit.test("does NOT navigate when registryId is missing", function (assert) {
    const {
      ctrl,
      modelData,
      navToStub
    } = buildFixture();
    ctrl.registryId = null;
    modelData["/selectedVersionIds"] = ["v-old", "v-new"];
    ctrl.onComparePress();
    assert.ok(!navToStub.called);
  });
  QUnit.module("RegistryDetail – onVersionPress", {
    beforeEach() {
      sandbox = sinon.sandbox.create();
    },
    afterEach() {
      sandbox.restore();
    }
  });
  QUnit.test("navigates to versionDetail with registryId and versionId", function (assert) {
    const {
      ctrl,
      navToStub
    } = buildFixture();
    const event = {
      getSource: sinon.stub().returns({
        getBindingContext: sinon.stub().returns({
          getObject: () => VERSIONS[1]
        })
      })
    };
    ctrl.onVersionPress(event);
    assert.ok(navToStub.calledOnce);
    assert.strictEqual(navToStub.firstCall.args[0], "versionDetail");
    assert.deepEqual(navToStub.firstCall.args[1], {
      registryId: "reg-1",
      versionId: "v-new"
    });
  });
  QUnit.test("does NOT navigate when binding context is null", function (assert) {
    const {
      ctrl,
      navToStub
    } = buildFixture();
    const event = {
      getSource: sinon.stub().returns({
        getBindingContext: sinon.stub().returns(null)
      })
    };
    ctrl.onVersionPress(event);
    assert.ok(!navToStub.called);
  });
});
//# sourceMappingURL=RegistryDetail.qunit-dbg.js.map
