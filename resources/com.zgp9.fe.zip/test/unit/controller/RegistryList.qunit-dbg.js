sap.ui.define(["com/zgp9/fe/controller/RegistryList.controller", "sap/m/MessageToast", "sap/ui/core/BusyIndicator"], function (__RegistryList, MessageToast, BusyIndicator) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  /**
   * QUnit tests for RegistryList controller
   */
  const RegistryList = _interopRequireDefault(__RegistryList);
  let sandbox;
  const SAMPLE_REGISTRIES = [{
    id: "reg-1",
    registryName: "ServiceA",
    serviceName: "svc-a",
    serviceType: "OData V4",
    status: "Published",
    statusText: "Published",
    description: "",
    createdBy: "alice",
    createdAt: "2024-01-01T00:00:00Z",
    lastChangedBy: "alice",
    lastChangedAt: "2024-01-01T00:00:00Z",
    serviceDefinition: "",
    versions: [{
      versionNumber: "001"
    }]
  }];
  const VALUE_HELPS = {
    groupTypes: [{
      key: "001",
      text: "OData V4"
    }, {
      key: "002",
      text: "REST"
    }],
    statuses: [{
      key: "P",
      text: "publish"
    }, {
      key: "U",
      text: "unpublish"
    }, {
      key: "A",
      text: "archive"
    }]
  };
  function buildRegistryListFixture() {
    const ctrl = new RegistryList("test");
    const modelData = {
      "/items": [],
      "/busy": false,
      "/search": "",
      "/searchField": "all",
      "/status": "All",
      "/groupType": "All",
      "/registryName": "",
      "/createdBy": "",
      "/groupTypes": [],
      "/statuses": []
    };
    const modelStub = {
      setProperty: sinon.stub().callsFake((p, v) => {
        modelData[p] = v;
      }),
      getProperty: sinon.stub().callsFake(p => modelData[p]),
      getData: sinon.stub().callsFake(() => {
        const d = {};
        Object.keys(modelData).forEach(k => {
          d[k.slice(1)] = modelData[k];
        });
        return d;
      })
    };
    const registryService = {
      getRegistries: sinon.stub().resolves(SAMPLE_REGISTRIES),
      getPermissions: sinon.stub().resolves(["Registry.Create", "Registry.Update"]),
      getGroupTypes: sinon.stub().resolves(VALUE_HELPS.groupTypes),
      getStatuses: sinon.stub().resolves(VALUE_HELPS.statuses),
      createRegistry: sinon.stub().resolves(),
      updateRegistry: sinon.stub().resolves()
    };
    const navToStub = sinon.stub();
    sandbox.stub(ctrl, "getModel").callsFake(name => name === "registryList" ? modelStub : null);
    sandbox.stub(ctrl, "getRouter").returns({
      navTo: navToStub,
      getRoute: sinon.stub().returns({
        attachPatternMatched: sinon.stub()
      })
    });
    sandbox.stub(ctrl, "handleServiceError").resolves();
    sandbox.stub(ctrl, "getOwnerComponent").returns({
      getRegistryService: () => registryService
    });
    return {
      ctrl,
      modelData,
      registryService,
      navToStub
    };
  }
  function buildRowEvent(registry) {
    const ctx = registry ? {
      getObject: sinon.stub().returns(registry)
    } : null;
    return {
      getSource: sinon.stub().returns({
        getBindingContext: sinon.stub().returns(ctx)
      })
    };
  }
  function buildDialogModelStub(overrides = {}) {
    const data = {
      groupName: "ServiceA",
      groupType: "001",
      versionNo: "001",
      status: "P",
      showVersionNo: true,
      busy: false,
      ...overrides
    };
    return {
      getData: sinon.stub().returns({
        ...data
      }),
      setProperty: sinon.stub().callsFake((p, v) => {
        data[p] = v;
      }),
      getProperty: sinon.stub().callsFake(p => data[p.startsWith("/") ? p.slice(1) : p])
    };
  }
  QUnit.module("RegistryList – onInit", {
    beforeEach() {
      sandbox = sinon.sandbox.create();
    },
    afterEach() {
      sandbox.restore();
    }
  });
  QUnit.test("registers registryList model with empty defaults", function (assert) {
    const ctrl = new RegistryList("test");
    const setModelSpy = sandbox.stub(ctrl, "setModel").returns(ctrl);
    sandbox.stub(ctrl, "getRouter").returns({
      getRoute: sinon.stub().returns({
        attachPatternMatched: sinon.stub()
      })
    });
    sandbox.stub(ctrl, "getModel").returns({
      setProperty: sinon.stub(),
      getProperty: sinon.stub().returns([])
    });
    sandbox.stub(ctrl, "getOwnerComponent").returns({
      getRegistryService: () => ({
        getPermissions: sinon.stub().resolves([]),
        getGroupTypes: sinon.stub().resolves([]),
        getStatuses: sinon.stub().resolves([]),
        getRegistries: sinon.stub().resolves([])
      })
    });
    sandbox.stub(ctrl, "handleServiceError").resolves();
    ctrl.onInit();
    assert.strictEqual(setModelSpy.firstCall.args[1], "registryList");
    const data = setModelSpy.firstCall.args[0].getData();
    assert.deepEqual(data.items, []);
    assert.strictEqual(data.busy, false);
    assert.strictEqual(data.status, "All");
  });
  QUnit.module("RegistryList – loadRegistries", {
    beforeEach() {
      sandbox = sinon.sandbox.create();
    },
    afterEach() {
      sandbox.restore();
    }
  });
  QUnit.test("fetches with filters and toggles busy", async function (assert) {
    let busyDuringFetch = false;
    const {
      ctrl,
      registryService,
      modelData
    } = buildRegistryListFixture();
    modelData["/search"] = "query";
    modelData["/status"] = "Published";
    registryService.getRegistries.callsFake(() => {
      busyDuringFetch = modelData["/busy"];
      return Promise.resolve(SAMPLE_REGISTRIES);
    });
    await ctrl.loadRegistries();
    assert.ok(busyDuringFetch);
    assert.strictEqual(registryService.getRegistries.firstCall.args[0].search, "query");
    assert.strictEqual(registryService.getRegistries.firstCall.args[0].status, "Published");
    assert.deepEqual(modelData["/items"], SAMPLE_REGISTRIES);
    assert.strictEqual(modelData["/busy"], false);
  });
  QUnit.test("handles errors and resets busy", async function (assert) {
    const {
      ctrl,
      registryService,
      modelData
    } = buildRegistryListFixture();
    registryService.getRegistries.rejects(new Error("Server error"));
    await ctrl.loadRegistries();
    assert.ok(ctrl.handleServiceError.calledOnce);
    assert.strictEqual(modelData["/busy"], false);
  });
  QUnit.module("RegistryList – onFilterChange", {
    beforeEach() {
      sandbox = sinon.sandbox.create();
    },
    afterEach() {
      sandbox.restore();
    }
  });
  QUnit.test("reloads registries on filter change", async function (assert) {
    const {
      ctrl,
      registryService
    } = buildRegistryListFixture();
    await ctrl.onFilterChange();
    assert.ok(registryService.getRegistries.calledOnce);
  });
  QUnit.module("RegistryList – onGroupTypeChange", {
    beforeEach() {
      sandbox = sinon.sandbox.create();
    },
    afterEach() {
      sandbox.restore();
    }
  });
  QUnit.test("toggles versionNo visibility by group type", function (assert) {
    const ctrl = new RegistryList("test");
    const dialog002 = buildDialogModelStub({
      versionNo: "001"
    });
    sandbox.stub(ctrl, "getModel").callsFake(name => name === "registryDialog" ? dialog002 : null);
    ctrl.onGroupTypeChange({
      getSource: sinon.stub().returns({
        getSelectedKey: sinon.stub().returns("002")
      })
    });
    assert.ok(dialog002.setProperty.calledWith("/showVersionNo", false));
    assert.ok(dialog002.setProperty.calledWith("/versionNo", ""));
    sandbox.restore();
    sandbox = sinon.sandbox.create();
    const dialog001 = buildDialogModelStub({
      versionNo: ""
    });
    sandbox.stub(ctrl, "getModel").callsFake(name => name === "registryDialog" ? dialog001 : null);
    ctrl.onGroupTypeChange({
      getSource: sinon.stub().returns({
        getSelectedKey: sinon.stub().returns("001")
      })
    });
    assert.ok(dialog001.setProperty.calledWith("/showVersionNo", true));
    assert.ok(dialog001.setProperty.calledWith("/versionNo", "001"));
  });
  QUnit.module("RegistryList – onRowPress", {
    beforeEach() {
      sandbox = sinon.sandbox.create();
    },
    afterEach() {
      sandbox.restore();
    }
  });
  QUnit.test("navigates to registryDetail or skips null context", function (assert) {
    const {
      ctrl,
      navToStub
    } = buildRegistryListFixture();
    ctrl.onRowPress(buildRowEvent(SAMPLE_REGISTRIES[0]));
    assert.strictEqual(navToStub.firstCall.args[0], "registryDetail");
    assert.deepEqual(navToStub.firstCall.args[1], {
      registryId: "reg-1"
    });
    navToStub.resetHistory();
    ctrl.onRowPress(buildRowEvent(null));
    assert.ok(!navToStub.called);
  });
  QUnit.module("RegistryList – onSortConfirm", {
    beforeEach() {
      sandbox = sinon.sandbox.create();
    },
    afterEach() {
      sandbox.restore();
    }
  });
  QUnit.test("applies sorter when sortItem is present", function (assert) {
    const {
      ctrl
    } = buildRegistryListFixture();
    const sortStub = sinon.stub();
    sandbox.stub(ctrl, "getView").returns({
      byId: sinon.stub().returns({
        getBinding: sinon.stub().returns({
          sort: sortStub
        })
      })
    });
    const sortItem = {
      getKey: sinon.stub().returns("registryName")
    };
    ctrl.onSortConfirm({
      getParameter: sinon.stub().callsFake(p => p === "sortItem" ? sortItem : false)
    });
    assert.ok(sortStub.calledOnce);
    assert.strictEqual(sortStub.firstCall.args[0].sPath, "registryName");
  });
  QUnit.module("RegistryList – onSaveRegistryDialog", {
    beforeEach() {
      sandbox = sinon.sandbox.create();
      sandbox.stub(BusyIndicator, "show");
      sandbox.stub(BusyIndicator, "hide");
      sandbox.stub(MessageToast, "show");
    },
    afterEach() {
      sandbox.restore();
    }
  });
  QUnit.test("creates registry successfully", async function (assert) {
    const {
      ctrl,
      registryService
    } = buildRegistryListFixture();
    ctrl.dialogMode = "create";
    ctrl.currentRegistryId = null;
    ctrl.registryDialogPromise = Promise.resolve({
      close: sinon.stub()
    });
    sandbox.stub(ctrl, "getView").returns({
      getModel: sinon.stub().returns(buildDialogModelStub({
        groupName: "NewSvc",
        groupType: "001",
        versionNo: "001"
      }))
    });
    await ctrl.onSaveRegistryDialog();
    assert.ok(registryService.createRegistry.calledOnce);
    assert.ok(BusyIndicator.show.calledOnce);
    assert.ok(BusyIndicator.hide.calledOnce);
    assert.ok(MessageToast.show.firstCall.args[0].toLowerCase().includes("created"));
  });
  QUnit.test("updates registry successfully", async function (assert) {
    const {
      ctrl,
      registryService
    } = buildRegistryListFixture();
    ctrl.dialogMode = "edit";
    ctrl.currentRegistryId = "reg-1";
    ctrl.registryDialogPromise = Promise.resolve({
      close: sinon.stub()
    });
    sandbox.stub(ctrl, "getView").returns({
      getModel: sinon.stub().returns(buildDialogModelStub({
        status: "P"
      }))
    });
    await ctrl.onSaveRegistryDialog();
    assert.ok(registryService.updateRegistry.calledOnce);
    assert.strictEqual(registryService.updateRegistry.firstCall.args[0], "reg-1");
    assert.ok(MessageToast.show.firstCall.args[0].toLowerCase().includes("updated"));
  });
  QUnit.test("handles create errors and hides busy", async function (assert) {
    const {
      ctrl,
      registryService
    } = buildRegistryListFixture();
    ctrl.dialogMode = "create";
    ctrl.currentRegistryId = null;
    ctrl.registryDialogPromise = Promise.resolve({
      close: sinon.stub()
    });
    sandbox.stub(ctrl, "getView").returns({
      getModel: sinon.stub().returns(buildDialogModelStub())
    });
    registryService.createRegistry.rejects(new Error("Conflict"));
    await ctrl.onSaveRegistryDialog();
    assert.ok(ctrl.handleServiceError.calledOnce);
    assert.ok(BusyIndicator.hide.calledOnce);
  });
  QUnit.module("RegistryList – onCancelRegistryDialog", {
    beforeEach() {
      sandbox = sinon.sandbox.create();
    },
    afterEach() {
      sandbox.restore();
    }
  });
  QUnit.test("closes dialog when open, otherwise no-op", async function (assert) {
    const {
      ctrl
    } = buildRegistryListFixture();
    const closeStub = sinon.stub();
    ctrl.registryDialogPromise = Promise.resolve({
      close: closeStub
    });
    await ctrl.onCancelRegistryDialog();
    assert.ok(closeStub.calledOnce);
    ctrl.registryDialogPromise = undefined;
    let threw = false;
    try {
      await ctrl.onCancelRegistryDialog();
    } catch {
      threw = true;
    }
    assert.ok(!threw);
  });
});
//# sourceMappingURL=RegistryList.qunit-dbg.js.map
