sap.ui.define(["./controller/BaseController.qunit", "./controller/Login.qunit", "./controller/Main.qunit", "./controller/MainShell.qunit", "./controller/JobList.qunit", "./controller/RegistryList.qunit", "./controller/Logs.qunit"], function (___controller_BaseControllerqunit, ___controller_Loginqunit, ___controller_Mainqunit, ___controller_MainShellqunit, ___controller_JobListqunit, ___controller_RegistryListqunit, ___controller_Logsqunit) {
  "use strict";
});
//# sourceMappingURL=unitTests.qunit-dbg.js.map
