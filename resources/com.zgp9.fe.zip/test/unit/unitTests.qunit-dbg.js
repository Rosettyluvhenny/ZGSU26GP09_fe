sap.ui.define(["./controller/BaseController.qunit", "./controller/Home.qunit", "./controller/MainShell.qunit", "./controller/JobList.qunit", "./controller/JobDetail.qunit", "./controller/RegistryList.qunit", "./controller/RegistryDetail.qunit", "./controller/Logs.qunit", "./services/XmlNodeUtils.qunit", "./services/ODataParsers.qunit"], function (___controller_BaseControllerqunit, ___controller_Homequnit, ___controller_MainShellqunit, ___controller_JobListqunit, ___controller_JobDetailqunit, ___controller_RegistryListqunit, ___controller_RegistryDetailqunit, ___controller_Logsqunit, ___services_XmlNodeUtilsqunit, ___services_ODataParsersqunit) {
  "use strict";
});
//# sourceMappingURL=unitTests.qunit-dbg.js.map
